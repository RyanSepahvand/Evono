// header state on scroll
const header=document.getElementById('siteHeader');
const toTop=document.getElementById('toTop');
addEventListener('scroll',()=>{
  const y=scrollY;
  header.classList.toggle('on',y>10);
  toTop.classList.toggle('show',y>600);
},{passive:true});

// mobile nav
const burger=document.getElementById('burgerBtn'),mnav=document.getElementById('mobileNav'),closeNav=document.getElementById('closeNav');
burger.onclick=()=>mnav.classList.add('open');
closeNav.onclick=()=>mnav.classList.remove('open');
mnav.querySelectorAll('a').forEach(a=>a.addEventListener('click',()=>mnav.classList.remove('open')));

// scroll-to-top
toTop.onclick=()=>scrollTo({top:0,behavior:'smooth'});

// scroll reveal
const io=new IntersectionObserver(entries=>{
  entries.forEach(e=>{
    if(e.isIntersecting){
      const els=e.target.matches('.reveal')?[e.target]:e.target.querySelectorAll('.reveal');
      (els.length?els:[e.target]).forEach((el,i)=>{el.style.transitionDelay=(i*70)+'ms';el.classList.add('show')});
      if(e.target.id==='stepsRow')e.target.classList.add('on');
    }
  });
},{threshold:.15});
document.querySelectorAll('.reveal').forEach(el=>io.observe(el));

// faq accordion
document.querySelectorAll('.faq-item').forEach(item=>{
  item.querySelector('.faq-q').addEventListener('click',()=>{
    const wasOpen=item.classList.contains('open');
    item.closest('.faq').querySelectorAll('.faq-item').forEach(i=>i.classList.remove('open'));
    if(!wasOpen)item.classList.add('open');
  });
});

// gentle 3d tilt on feature cards
document.querySelectorAll('.feat').forEach(card=>{
  card.addEventListener('mousemove',e=>{
    const r=card.getBoundingClientRect();
    const px=(e.clientX-r.left)/r.width-.5, py=(e.clientY-r.top)/r.height-.5;
    card.style.transform=`perspective(700px) rotateY(${px*6}deg) rotateX(${-py*6}deg) translateY(-4px)`;
  });
  card.addEventListener('mouseleave',()=>{card.style.transform=''});
});

// cursor-follow spotlight in hero
const hero=document.querySelector('.hero');
hero.addEventListener('mousemove',e=>{
  const r=hero.getBoundingClientRect();
  hero.style.setProperty('--mx',((e.clientX-r.left)/r.width*100)+'%');
  hero.style.setProperty('--my',((e.clientY-r.top)/r.height*100)+'%');
});

document.addEventListener("focusin",e=>{
  const t=e.target;
  if(t&&(t.tagName==="INPUT"||t.tagName==="TEXTAREA")){
    t.setAttribute("autocomplete","off");
    t.setAttribute("autocorrect","off");
    t.setAttribute("autocapitalize","off");
    t.setAttribute("spellcheck","false");
  }
});

// Signed-in pill — this page (www.evono.ir) can't read the student app's session the normal
// way: its login token lives only in app.evono.ir's own localStorage, a different origin this page
// has no access to. So instead it asks the backend: /otp/verify sets a lightweight httpOnly cookie
// (see backend/src/lib/auth.js's SESSION_COOKIE), and since every Evono subdomain shares the same
// registrable domain, that cookie still rides along on this credentialed cross-origin request even
// though www.evono.ir and api.evono.ir are different origins — see backend/src/routes/public.js and
// server.js's cors({credentials:true}) for the other half of that. Fails silently either way (logged
// out, offline, backend unreachable): the page just keeps showing the normal sign-in button.
// Two places show this: the desktop header bar (#headSignin/#headProfile) and the phone/iPad
// hamburger drawer (#mnavSignin/#mnavProfile) — both get swapped together from the one fetch.
(function(){
  const API_BASE="https://api.evono.ir";
  const pairs=[
    {signin:document.getElementById("headSignin"),profile:document.getElementById("headProfile"),av:document.getElementById("headProfileAv"),name:document.getElementById("headProfileName")},
    {signin:document.getElementById("mnavSignin"),profile:document.getElementById("mnavProfile"),av:document.getElementById("mnavProfileAv"),name:document.getElementById("mnavProfileName")}
  ].filter(p=>p.signin&&p.profile&&p.av&&p.name);
  if(!pairs.length)return;
  // DEMO BUILD: no backend. The landing page and student-app/ share one origin here, so the student
  // app's own localStorage state is directly readable.
  let data=null;
  try{
    if(localStorage.getItem("evono-token-v1")){
      const st=JSON.parse(localStorage.getItem("evono-state-v1")||"{}");
      const pr=(st&&st.profile)||{};
      data={signedIn:true,name:pr.name||"",avatar:pr.avatar||null};
    }
  }catch(e){}
  Promise.resolve(data)
    .then(data=>{
      if(!data||!data.signedIn)return;
      const name=(data.name||"").trim()||"دانش‌آموز Evono";
      pairs.forEach(p=>{
        p.name.textContent=name;
        if(data.avatar){
          const img=document.createElement("img");
          img.src=data.avatar;img.alt="";
          p.av.replaceChildren(img);
        }else{
          p.av.textContent=name.charAt(0)||"؟";
        }
        p.signin.hidden=true;
        p.profile.hidden=false;
      });
    })
    .catch(()=>{});
})();

// Make the brand logo a little harder to casually drag or right-click-save — this raises friction,
// it can't make an image the browser has to render literally undownloadable (dev tools/view-source
// always can), but it stops the two easiest, most common ways people lift a logo image.
document.addEventListener("dragstart",e=>{if(e.target&&e.target.closest&&e.target.closest(".brand-mark"))e.preventDefault()});
document.addEventListener("contextmenu",e=>{if(e.target&&e.target.closest&&e.target.closest(".brand-mark"))e.preventDefault()});
