# Evono — demo build (no backend)

Pure static site. Nothing here talks to a server, so there are no API keys or secrets.

- `/` — landing page. Its sign-in buttons open `student-app/`.
- `student-app/` — the student app, running in demo mode (`const DEMO=true` near the top of `student-app/app.js`).

## Demo behaviour
- Any valid phone number (09XXXXXXXXX) logs in. The verification code is always **12345**.
- "Payment" is simulated: pick a plan, press pay, and the subscription activates instantly.
  Discount code **DEMO20** gives 20% off.
- EvonoAI replies are canned (they don't edit the plan).
- The small badge at the bottom resets the demo (clears local data).
- All data lives in the visitor's own browser (localStorage).

## Run / host
- Local: `node serve.js` → http://localhost:5500
- Host: upload the folder to any static host (Vercel, Netlify, GitHub Pages, cPanel public_html).
