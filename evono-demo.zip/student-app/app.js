"use strict";
document.documentElement.setAttribute("dir","rtl");document.documentElement.setAttribute("lang","fa");
/* ================= Jalali calendar (jalaali algorithm) ================= */
const div=(a,b)=>~~(a/b), mod=(a,b)=>a-~~(a/b)*b;
const BRK=[-61,9,38,199,426,686,756,818,1111,1181,1210,1635,2060,2097,2192,2262,2324,2394,2456,3178];
function jalCal(jy){let bl=BRK.length,gy=jy+621,leapJ=-14,jp=BRK[0],jm,jump,leap,leapG,march,n,i;
  for(i=1;i<bl;i++){jm=BRK[i];jump=jm-jp;if(jy<jm)break;leapJ=leapJ+div(jump,33)*8+div(mod(jump,33),4);jp=jm}
  n=jy-jp;leapJ=leapJ+div(n,33)*8+div(mod(n,33)+3,4);if(mod(jump,33)===4&&jump-n===4)leapJ+=1;
  leapG=div(gy,4)-div((div(gy,100)+1)*3,4)-150;march=20+leapJ-leapG;
  if(jump-n<6)n=n-jump+div(jump+4,33)*33;leap=mod(mod(n+1,33)-1,4);if(leap===-1)leap=4;return{leap,gy,march}}
function g2d(gy,gm,gd){let d=div((gy+div(gm-8,6)+100100)*1461,4)+div(153*mod(gm+9,12)+2,5)+gd-34840408;return d-div(div(gy+100100+div(gm-8,6),100)*3,4)+752}
function d2g(jdn){let j=4*jdn+139361631;j=j+div(div(4*jdn+183187720,146097)*3,4)*4-3908;const i=div(mod(j,1461),4)*5+308;const gd=div(mod(i,153),5)+1;const gm=mod(div(i,153),12)+1;const gy=div(j,1461)-100100+div(8-gm,6);return{gy,gm,gd}}
function j2d(jy,jm,jd){const r=jalCal(jy);return g2d(r.gy,3,r.march)+(jm-1)*31-div(jm,7)*(jm-7)+jd-1}
function d2j(jdn){const gy=d2g(jdn).gy;let jy=gy-621;const r=jalCal(jy);const jdn1f=g2d(gy,3,r.march);let jd,jm,k=jdn-jdn1f;
  if(k>=0){if(k<=185){jm=1+div(k,31);jd=mod(k,31)+1;return{jy,jm,jd}}else k-=186}else{jy-=1;k+=179;if(r.leap===1)k+=1}
  jm=7+div(k,30);jd=mod(k,30)+1;return{jy,jm,jd}}
/* Dates are stored as day numbers (JDN) internally, ISO for storage */
const isoFromD=d=>{const g=d2g(d);return `${g.gy}-${String(g.gm).padStart(2,"0")}-${String(g.gd).padStart(2,"0")}`};
const dFromIso=s=>{const [y,m,dd]=s.split("-").map(Number);return g2d(y,m,dd)};
const todayD=()=>{const n=new Date();return g2d(n.getFullYear(),n.getMonth()+1,n.getDate())};
const jFromIso=s=>d2j(dFromIso(s));
const isoFromJ=(y,m,d)=>isoFromD(j2d(y,m,d));
const JM=["فروردین","اردیبهشت","خرداد","تیر","مرداد","شهریور","مهر","آبان","آذر","دی","بهمن","اسفند"];
const WD=["شنبه","یکشنبه","دوشنبه","سه‌شنبه","چهارشنبه","پنجشنبه","جمعه"];
const wdIdx=d=>mod(d+2,7); // JDN: 0=Mon ... map to Sat=0
const fa=n=>(typeof n==="number"?n:Number(n)).toLocaleString("fa-IR",{maximumFractionDigits:1});
const faStr=s=>String(s).replace(/\d/g,c=>"۰۱۲۳۴۵۶۷۸۹"[c]);
const fa2=n=>(typeof n==="number"?n:Number(n)).toLocaleString("fa-IR",{minimumFractionDigits:2,maximumFractionDigits:2});
const jLabel=iso=>{const j=jFromIso(iso);return `${fa(j.jd)} ${JM[j.jm-1]} ${faStr(j.jy)}`};
const jShort=iso=>{const j=jFromIso(iso);return `${faStr(j.jy)}/${faStr(String(j.jm).padStart(2,"0"))}/${faStr(String(j.jd).padStart(2,"0"))}`};
const parseJ=s=>{const t=String(s).replace(/[۰-۹]/g,c=>"۰۱۲۳۴۵۶۷۸۹".indexOf(c)).replace(/[٠-٩]/g,c=>"٠١٢٣٤٥٦٧٨٩".indexOf(c)).split(/[\/\-\.]/).map(Number);
  if(t.length!==3||t.some(isNaN)||t[1]<1||t[1]>12||t[2]<1||t[2]>31||t[0]<1390||t[0]>1420)return null;return isoFromJ(t[0],t[1],t[2])};
const hm=min=>{const h=Math.floor(min/60),m=min%60;return faStr(`${String(h).padStart(2,"0")}:${String(m).padStart(2,"0")}`)};
const toMin=t=>{const [h,m]=String(t||"16:00").split(":").map(Number);return (h||0)*60+(m||0)};
const hmA=min=>{min=Math.max(0,Math.min(1439,Math.round(min)));return `${String(Math.floor(min/60)).padStart(2,"0")}:${String(min%60).padStart(2,"0")}`};
const nowMin=()=>{const n=new Date();return n.getHours()*60+n.getMinutes()};
const hmInput=(id,min,label)=>`<div class="field"><span>${label}</span><div class="hm"><label><input type="text" inputmode="numeric" data-pfa id="${id}-h" maxlength="2" value="${faStr(Math.floor((min||0)/60))}" aria-label="${label} — ساعت"><em>ساعت</em></label><label><input type="text" inputmode="numeric" data-pfa id="${id}-m" maxlength="2" value="${faStr((min||0)%60)}" aria-label="${label} — دقیقه"><em>دقیقه</em></label></div></div>`;
const HOURW=h=>h<5?"بامداد":h<12?"صبح":h<14?"ظهر":h<19?"عصر":"شب";
function tp(id,val){const m=toMin(val||"00:00");const H=Math.floor(m/60)%24,M=Math.round((m%60)/5)*5%60;
  return `<span class="tp"><select id="${id}-h" aria-label="ساعت">${Array.from({length:24},(_,h)=>`<option value="${h}" ${h===H?"selected":""}>${faStr(String(h).padStart(2,"0"))} ${HOURW(h)}</option>`).join("")}</select><b>:</b><select id="${id}-mm" aria-label="دقیقه">${Array.from({length:12},(_,i)=>i*5).map(x=>`<option value="${x}" ${x===M?"selected":""}>${faStr(String(x).padStart(2,"0"))}</option>`).join("")}</select></span>`}
function tpVal(id,fb){const h=document.getElementById(id+"-h"),m=document.getElementById(id+"-mm");if(!h||!m)return fb;return hmA(+h.value*60+ +m.value)}
function durCell(a,b){const d=toMin(b)-toMin(a);return d>0?durLabel(d):'<span class="warn">⚠ پایان باید بعد از شروع باشد</span>'}
document.addEventListener("change",e=>{const id=e.target&&e.target.id||"";let m;
  if((m=id.match(/^(av|ob)-[se]-(\d)-(h|mm)$/))){const p=m[1],i=m[2];const el=document.getElementById((p==="av"?"avd-":"obd-")+i);if(el)el.innerHTML=durCell(tpVal(`${p}-s-${i}`),tpVal(`${p}-e-${i}`))}
  if(/^(hol-[se]|ob-h[se])-(h|mm)$/.test(id)){const ob=id.startsWith("ob");const el=document.getElementById(ob?"obhd":"hold");if(el)el.innerHTML=durCell(tpVal(ob?"ob-hs":"hol-s"),tpVal(ob?"ob-he":"hol-e"))}});
/* Every [data-pfa] input accepts Persian (and Arabic-Indic) digits as the student types, and always displays
   Persian digits back — value stays readable by numeric code via toEnDigits() at the point it's read. */
document.addEventListener("input",e=>{const el=e.target;if(!el||!el.matches||!el.matches("input[data-pfa]"))return;
  const dec=el.dataset.pfa==="dec";let v=toEnDigits(el.value);
  v=dec?v.replace(/[^0-9.\-]/g,"").replace(/(?!^)-/g,"").replace(/(\..*)\./,"$1"):v.replace(/[^0-9\-]/g,"").replace(/(?!^)-/g,"");
  const s2=faStr(v);if(el.value!==s2)el.value=s2});
const readHM=id=>{const h=Number(toEnDigits(document.getElementById(id+"-h")?.value))||0,m=Number(toEnDigits(document.getElementById(id+"-m")?.value))||0;return Math.max(0,h*60+m)};
const durLabel=m=>m>=60?(m%60?`${fa(Math.floor(m/60))} ساعت و ${fa(m%60)} دقیقه`:`${fa(m/60)} ساعت`):`${fa(m)} دقیقه`;
const esc=s=>String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
const uid=()=>Math.random().toString(36).slice(2,9);

/* ================= Evono backend ================= */
// Point this at wherever you deploy backend/ (see backend/README.md "Deploying").
// Example for local testing: "http://localhost:3001"
const API_BASE="https://api.evono.ir";
const TOKEN_KEY="evono-token-v1";
function authToken(){try{return localStorage.getItem(TOKEN_KEY)||""}catch(e){return ""}}
function setAuthToken(t){try{if(t)localStorage.setItem(TOKEN_KEY,t);else localStorage.removeItem(TOKEN_KEY)}catch(e){}}
/** Thin fetch wrapper for every backend call: adds the auth header, parses JSON, and throws an
 *  Error with .code (the backend's {error:"..."} string) and .status on any non-2xx response or
 *  network failure, so call sites can show one honest message instead of a fake success. */
/* ================= DEMO BUILD ================= */
// This copy of the student app runs with NO backend: api() below is answered by demoApi() instead of
// fetch(). Any valid phone number logs in with the fixed code DEMO_CODE, EvonoAI replies are canned,
// and "payment" just activates a subscription locally. Set DEMO=false (and restore API_BASE) to
// talk to the real backend again.
const DEMO=true;
const DEMO_CODE="12345";
const DEMO_KEY="evono-demo-v1";
function demoLoad(){try{return JSON.parse(localStorage.getItem(DEMO_KEY)||"{}")}catch(e){return {}}}
function demoSave(d){try{localStorage.setItem(DEMO_KEY,JSON.stringify(d))}catch(e){}}
const demoWait=ms=>new Promise(r=>setTimeout(r,ms));
const DEMO_DAYS={weekly:7,monthly:30,quarter:90};
function demoAiReply(msgs){
  const last=msgs.filter(m=>m.role==="user"&&typeof m.content==="string").pop();
  const t=(last&&last.content)||"";
  const q=t.slice(-300);
  if(/ریاضی|فیزیک|شیمی|زیست|حسابان|هندسه/.test(q))return "برای این درس پیشنهاد می‌کنم هر جلسه را به سه بخش تقسیم کنی: ۲۵ دقیقه مرور مفهوم، ۴۰ دقیقه تست‌زنی و ۱۵ دقیقه تحلیل اشتباهات. سؤال‌هایی که غلط زدی را در یک دفترچهٔ جدا بنویس و آخر هفته دوباره حلشان کن.\n\n(این یک پاسخ نمایشی است؛ در نسخهٔ واقعی **EvonoAI** برنامهٔ هفتگی‌ات را هم مستقیم تغییر می‌دهد.)";
  if(/برنامه|ساعت|وقت|امشب|فردا|عوض|تغییر/.test(q))return "حتماً! در نسخهٔ واقعی همین‌جا برنامهٔ امروز و هفتهٔ تو را بر اساس ساعت مدرسه، خواب و ضعف‌هایت دوباره می‌چینم و تغییرها را با نشانگر مشخص می‌کنم.\n\nاین نسخه فقط نمایشی است و برنامه را تغییر نمی‌دهد.";
  if(/خسته|استرس|انگیزه|نمی‌تونم|بی‌حوصله/.test(q))return "طبیعیه که گاهی خسته بشی. امروز فقط یک بلوک ۲۵ دقیقه‌ای سبک انتخاب کن، بعدش ۵ دقیقه استراحت. شروع کردن از ادامه دادن سخت‌تره؛ خودت دیدی که بعد از شروع، بقیه‌اش راحت‌تر می‌شود.";
  return "سلام! من **EvonoAI** هستم؛ مشاور تحصیلی تو. از من دربارهٔ برنامهٔ هفتگی، مدیریت زمان، روش مطالعهٔ هر درس یا تحلیل گزارش روزانه‌ات بپرس.\n\n(پاسخ‌ها در این نسخهٔ نمایشی از پیش نوشته شده‌اند.)";
}
async function demoApi(path,opts){
  opts=opts||{};const body=opts.body||{};const d=demoLoad();const m=opts.method||"GET";
  await demoWait(250);
  const fail=(code,status)=>{const e=new Error(code);e.code=code;e.status=status||400;throw e};
  if(path==="/api/otp/send"){if(!/^09\d{9}$/.test(body.phone||""))fail("invalid_phone");return {ok:true,expiresInSeconds:120}}
  if(path==="/api/otp/verify"){if(String(body.code)!==DEMO_CODE)fail("wrong_or_expired_code");return {ok:true,token:"demo-token",role:"student",isNewStudent:!d.seen}}
  if(path==="/api/otp/logout")return {ok:true};
  if(path==="/api/me"&&m==="PUT")return {ok:true};
  if(path==="/api/me"){
    const out={extra_ai_messages:d.extra||0};
    if(d.sub)out.subscription={plan:d.sub.plan,status:"active",starts_at:new Date(d.sub.start).toISOString(),ends_at:new Date(d.sub.until).toISOString()};
    return out;
  }
  if(path==="/api/me/sync")return {ok:true,enabled:false};
  if(path==="/api/pay/plan-prices")return {ok:true,prices:{}};
  if(path==="/api/pay/topup-rate")return {ok:true,unitPriceToman:1500};
  if(path==="/api/pay/quote"){
    const p=PLANS.find(x=>x.id===body.plan);if(!p)fail("invalid_plan");
    let off=0;if(body.code){if(String(body.code).toUpperCase()==="DEMO20")off=Math.round(p.amount*.2);else fail("invalid_code")}
    return {ok:true,amountToman:p.amount,discountToman:off,totalToman:p.amount-off};
  }
  if(path==="/api/pay/request"){
    await demoWait(900);
    const days=DEMO_DAYS[body.plan]||30,now=Date.now();
    d.sub={plan:body.plan,start:now,until:now+days*86400000};demoSave(d);
    return {ok:true,redirectUrl:location.pathname+"?payment=success&order=DEMO"+Math.floor(1000+Math.random()*9000)};
  }
  if(path==="/api/pay/topup-request"){
    await demoWait(900);
    d.extra=(d.extra||0)+(Number(body.n)||0);demoSave(d);
    return {ok:true,redirectUrl:location.pathname+"?payment=success&type=topup&order=DEMO"+Math.floor(1000+Math.random()*9000)};
  }
  if(path==="/api/ai/chat"||path==="/api/ai/chat-with-tools"){
    await demoWait(900);
    const text=demoAiReply(body.messages||[]);
    return path==="/api/ai/chat"?{text}:{text,toolUse:[],raw:{content:[{type:"text",text}]}};
  }
  fail("not_found",404);
}
function demoBadge(){
  const b=document.createElement("button");b.type="button";
  b.textContent="نسخهٔ نمایشی · کد ورود ۱۲۳۴۵ · بازنشانی";
  b.style.cssText="position:fixed;bottom:10px;right:10px;z-index:9999;font:600 11px/1 Vazirmatn,Tahoma,sans-serif;color:#0A0B0D;background:#fff;border:0;border-radius:999px;padding:8px 12px;opacity:.9;cursor:pointer;box-shadow:0 4px 18px rgba(0,0,0,.45)";
  b.onclick=()=>{try{localStorage.clear()}catch(e){}location.href=location.pathname};
  document.body.appendChild(b);
}
if(DEMO)(document.body?demoBadge():addEventListener("DOMContentLoaded",demoBadge));
async function api(path,opts){
  opts=opts||{};
  if(DEMO)return demoApi(path,opts);
  const headers={"content-type":"application/json"};
  const t=authToken();if(t)headers.authorization="Bearer "+t;
  let res;
  try{
    // credentials:"include" — every call here still authenticates the normal way (the Authorization
    // header above), this only makes the browser ALSO accept the httpOnly session cookie /otp/verify
    // sets (see backend/src/lib/auth.js's SESSION_COOKIE) despite api.evono.ir being a different origin
    // from this page. That cookie is what lets the landing page's header show "already signed in" —
    // see backend/src/routes/public.js.
    res=await fetch(API_BASE+path,{method:opts.method||"GET",headers,body:opts.body!==undefined?JSON.stringify(opts.body):undefined,signal:opts.signal,credentials:"include"});
  }catch(e){const err=new Error("network_error");err.code="network_error";throw err;}
  let data=null;try{data=await res.json()}catch(e){}
  if(!res.ok){const err=new Error((data&&data.error)||"request_failed");err.code=(data&&data.error)||"request_failed";err.status=res.status;err.detail=data&&data.detail;throw err;}
  return data;
}

/* ================= Domain: fields, courses, exam rule sets ================= */
// names: [grade10, grade11, grade12] (null = not taught that year). kw = relative Konkur importance (approximate, editable), spec = specialized course
const CATALOG={
  tajrobi:{label:"علوم تجربی",areas:[
    {id:"bio",name:"زیست‌شناسی",names:["زیست‌شناسی ۱","زیست‌شناسی ۲","زیست‌شناسی ۳"],kw:4,spec:1},
    {id:"chem",name:"شیمی",names:["شیمی ۱","شیمی ۲","شیمی ۳"],kw:3,spec:1},
    {id:"phys",name:"فیزیک",names:["فیزیک ۱","فیزیک ۲","فیزیک ۳"],kw:2.5,spec:1},
    {id:"math",name:"ریاضی",names:["ریاضی ۱","ریاضی ۲","ریاضی ۳"],kw:2.5,spec:1},
    {id:"geo",name:"زمین‌شناسی",names:[null,"زمین‌شناسی",null],kw:1,spec:1},
    {id:"fa",name:"فارسی",names:["فارسی ۱","فارسی ۲","فارسی ۳"],kw:0,spec:0},
    {id:"ar",name:"عربی",names:["عربی ۱","عربی ۲","عربی ۳"],kw:0,spec:0},
    {id:"din",name:"دین و زندگی",names:["دین و زندگی ۱","دین و زندگی ۲","دین و زندگی ۳"],kw:0,spec:0},
    {id:"en",name:"زبان انگلیسی",names:["زبان انگلیسی ۱","زبان انگلیسی ۲","زبان انگلیسی ۳"],kw:0,spec:0},
    {id:"hoviyat",name:"هویت اجتماعی",names:[null,null,"هویت اجتماعی"],kw:0,spec:0},
    {id:"salamat",name:"سلامت و بهداشت",names:[null,null,"سلامت و بهداشت"],kw:0,spec:0},
    {id:"modiriat",name:"مدیریت خانواده و سبک زندگی",names:[null,null,"مدیریت خانواده و سبک زندگی"],kw:0,spec:0}]},
  riazi:{label:"ریاضی و فیزیک",areas:[
    {id:"calc",name:"حسابان",names:["ریاضی ۱","حسابان ۱","حسابان ۲"],kw:4,spec:1},
    {id:"geom",name:"هندسه",names:["هندسه ۱","هندسه ۲","هندسه ۳"],kw:2,spec:1},
    {id:"disc",name:"گسسته و آمار",names:[null,"آمار و احتمال","ریاضیات گسسته"],kw:2,spec:1},
    {id:"phys",name:"فیزیک",names:["فیزیک ۱","فیزیک ۲","فیزیک ۳"],kw:3,spec:1},
    {id:"chem",name:"شیمی",names:["شیمی ۱","شیمی ۲","شیمی ۳"],kw:2,spec:1},
    {id:"fa",name:"فارسی",names:["فارسی ۱","فارسی ۲","فارسی ۳"],kw:0,spec:0},
    {id:"ar",name:"عربی",names:["عربی ۱","عربی ۲","عربی ۳"],kw:0,spec:0},
    {id:"din",name:"دین و زندگی",names:["دین و زندگی ۱","دین و زندگی ۲","دین و زندگی ۳"],kw:0,spec:0},
    {id:"en",name:"زبان انگلیسی",names:["زبان انگلیسی ۱","زبان انگلیسی ۲","زبان انگلیسی ۳"],kw:0,spec:0},
    {id:"hoviyat",name:"هویت اجتماعی",names:[null,null,"هویت اجتماعی"],kw:0,spec:0},
    {id:"salamat",name:"سلامت و بهداشت",names:[null,null,"سلامت و بهداشت"],kw:0,spec:0},
    {id:"modiriat",name:"مدیریت خانواده و سبک زندگی",names:[null,null,"مدیریت خانواده و سبک زندگی"],kw:0,spec:0}]},
  ensani:{label:"ادبیات و علوم انسانی",areas:[
    {id:"rmath",name:"ریاضی و آمار",names:["ریاضی و آمار ۱","ریاضی و آمار ۲","ریاضی و آمار ۳"],kw:2,spec:1},
    {id:"adab",name:"علوم و فنون ادبی",names:["علوم و فنون ادبی ۱","علوم و فنون ادبی ۲","علوم و فنون ادبی ۳"],kw:2,spec:1},
    {id:"arq",name:"عربی، زبان قرآن",names:["عربی، زبان قرآن ۱","عربی، زبان قرآن ۲","عربی، زبان قرآن ۳"],kw:2,spec:1},
    {id:"hist",name:"تاریخ",names:["تاریخ ۱","تاریخ ۲","تاریخ ۳"],kw:1.5,spec:1},
    {id:"jog",name:"جغرافیا",names:["جغرافیای ایران","جغرافیا ۲","جغرافیا ۳"],kw:1.5,spec:1},
    {id:"soc",name:"جامعه‌شناسی",names:["جامعه‌شناسی ۱","جامعه‌شناسی ۲","جامعه‌شناسی ۳"],kw:1.5,spec:1},
    {id:"phil",name:"فلسفه و منطق",names:["منطق","فلسفه ۱","فلسفه ۲"],kw:1.5,spec:1},
    {id:"psy",name:"روان‌شناسی",names:[null,"روان‌شناسی",null],kw:1,spec:1},
    {id:"fa",name:"فارسی",names:["فارسی ۱","فارسی ۲","فارسی ۳"],kw:0,spec:0},
    {id:"din",name:"دین و زندگی",names:["دین و زندگی ۱","دین و زندگی ۲","دین و زندگی ۳"],kw:0,spec:0},
    {id:"en",name:"زبان انگلیسی",names:["زبان انگلیسی ۱","زبان انگلیسی ۲","زبان انگلیسی ۳"],kw:0,spec:0},
    {id:"tahlil",name:"تحلیل فرهنگی",names:[null,null,"تحلیل فرهنگی"],kw:0,spec:0},
    {id:"salamat",name:"سلامت و بهداشت",names:[null,null,"سلامت و بهداشت"],kw:0,spec:0},
    {id:"modiriat",name:"مدیریت خانواده و سبک زندگی",names:[null,null,"مدیریت خانواده و سبک زندگی"],kw:0,spec:0}]}
};
// Exam rule sets per Konkur year. Only 1405 is based on announced rules; later years are drafts to update from the settings page.
function ruleSet(K){
  const base={year:K,sabeghe:60,test:40,g12:43,g11:17,effect:"قطعی",g11Courses:"all",confirmed:false,
    note:"پیش‌نویس — بر اساس اخبار منتشرشده؛ پس از اعلام رسمی سازمان سنجش به‌روز کنید."};
  if(K<=1405)return{...base,g11Courses:"six",confirmed:true,note:"کنکور ۱۴۰۵: ۶۰٪ سوابق تحصیلی (۴۳٪ پایه دوازدهم، ۱۷٪ پایه یازدهم فقط ۶ درس)، ۴۰٪ آزمون."};
  return base;
}
function schoolYearStart(){const j=d2j(todayD());return j.jm>=6?j.jy:j.jy-1}
function konkurYearFor(grade){const s=schoolYearStart();return grade==="12"||grade==="grad"?s+1:grade==="11"?s+2:s+3}

/* ================= Textbook curriculum (chapter lists per book) =================
   Each book: array of [chapter title, sessions needed] or a number N = N lessons named «درس ۱…N».
   Students can edit any list in Settings; the production build should sync these from chap.sch.ir. */
const MATH10=[["مجموعه، الگو و دنباله",2],["مثلثات",2],["توان‌های گویا و عبارت‌های جبری",2],["معادله‌ها و نامعادله‌ها",2],["تابع",2],["شمارش، بدون شمردن",2],["آمار و احتمال",2]];
const CHEM=[[["کیهان، زادگاه الفبای هستی",4],["ردپای گازها در زندگی",4],["آب، آهنگ زندگی",4]],
  [["قدر هدایای زمینی را بدانیم",4],["در پی غذای سالم",4],["پوشاک، نیازی پایان‌ناپذیر",3]],
  [["مولکول‌ها در خدمت تندرستی",3],["آسایش و رفاه در سایهٔ شیمی",4],["شیمی، جلوه‌ای از هنر، زیبایی و ماندگاری",3],["شیمی، راهی به سوی آینده‌ای روشن‌تر",3]]];
const PHYS10=[["فیزیک و اندازه‌گیری",2],["ویژگی‌های فیزیکی مواد",3],["کار، انرژی و توان",3],["دما و گرما",4]];
/* هویت اجتماعی: فقط پایهٔ دوازدهم، مشترک بین تجربی و ریاضی (انسانی به‌جایش «تحلیل فرهنگی» را دارد که همان
   نقش را با محتوای دیگری ایفا می‌کند). ۱۰ درس، بدون فصل‌بندی، هرکدام یک جلسه. */
const HOVIYAT=[["کنش‌های ما",1],["پدیده‌های اجتماعی",1],["جامعه و فرهنگ (جهان اجتماعی)",1],["ارزیابی فرهنگ‌ها",1],
  ["هویت",1],["بازتولید هویت اجتماعی",1],["تحولات هویتی جامعه",1],["بعد فرهنگی هویت ایران",1],
  ["بعد سیاسی هویت ایران",1],["ابعاد جمعیتی و اقتصادی هویت ایران",1]];
/* سلامت و بهداشت: فقط پایهٔ دوازدهم، مشترک بین هر سه رشته. ۶ فصل. */
const SALAMAT=[["سلامت",1],["تغذیهٔ سالم و بهداشت مواد غذایی",2],["پیشگیری از بیماری‌ها",1],
  ["بهداشت در دوران نوجوانی",1],["پیشگیری از رفتارهای پرخطر",1],["محیط کار و زندگی سالم",1]];
const GEN={
  /* فارسی: هر پایه ۱۸ درس دارد، اما ۲ تای آن‌ها «درس آزاد» (ادبیات بومی) است — فقط برای مطالعهٔ آزاد، نه تدریس
     در کلاس و نه امتحان — پس اصلاً نباید برنامه‌ریزی شود. شماره‌های زیر همان شمارهٔ واقعی درس در کتاب درسی‌اند
     (نه شمارهٔ ردیف پشت‌سرهم)، فقط دو تای آزاد هر پایه از فهرست حذف شده‌اند. */
  fa:[[1,2,3,5,6,7,8,9,10,11,12,13,14,16,17,18], // دهم: درس‌های آزاد ۴ و ۱۵
      [1,2,3,5,6,7,8,9,10,11,12,14,15,16,17,18], // یازدهم: درس‌های آزاد ۴ و ۱۳
      [1,2,3,5,6,7,8,9,10,11,12,13,14,16,17,18]], // دوازدهم: درس‌های آزاد ۴ و ۱۵
  din:[12,12,12],
  en:[[["Saving Nature",2],["Wonders of Creation",2],["The Value of Knowledge",2],["Traveling the World",2]],
      [["Understanding People",2],["A Healthy Lifestyle",2],["Art and Culture",2]],
      [["Sense of Appreciation",2],["Look It Up!",2],["Renewable Energy",2]]],
  ar:[8,7,[["الدّینُ وَ التَّدَیُّن",2],["مَکَّةُ المُکَرَّمَة وَ المَدینَةُ المُنَوَّرَة",2],["الکُتُبُ طَعامُ الفِکر",2],["الفَرَزدَق",2]]],
  hoviyat:[null,null,HOVIYAT],
  salamat:[null,null,SALAMAT],
  /* مدیریت خانواده و سبک زندگی: فقط پایهٔ دوازدهم، مشترک بین هر سه رشته. ۲۲ درس (فصل‌بندی رسمی دقیقی که در
     منابع در دسترس نبود، پس مثل «دین و زندگی» به‌صورت ۲۲ درس پشت‌سرهم آمده). */
  modiriat:[null,null,22]
};
const CURR={
  tajrobi:{
    bio:[[["دنیای زنده",2],["گوارش و جذب مواد",3],["تبادلات گازی",3],["گردش مواد در بدن",5],["تنظیم اسمزی و دفع مواد زائد",2],["از یاخته تا گیاه",3],["جذب و انتقال مواد در گیاهان",3]],
         [["تنظیم عصبی",2],["حواس",3],["دستگاه حرکتی",2],["تنظیم شیمیایی",2],["ایمنی",3],["تقسیم یاخته",3],["تولیدمثل",4],["تولیدمثل نهان‌دانگان",3],["پاسخ گیاهان به محرک‌ها",2]],
         [["مولکول‌های اطلاعاتی",3],["جریان اطلاعات در یاخته",3],["انتقال اطلاعات در نسل‌ها",3],["تغییر در اطلاعات وراثتی",3],["از ماده به انرژی",3],["از انرژی به ماده",3],["فناوری‌های نوین زیستی",3],["رفتارهای جانوران",3]]],
    chem:CHEM,
    phys:[PHYS10,[["الکتریسیتهٔ ساکن",4],["جریان الکتریکی و مدارهای جریان مستقیم",4],["مغناطیس و القای الکترومغناطیسی",4]],
          [["حرکت بر خط راست",3],["دینامیک و حرکت دایره‌ای",3],["نوسان و موج",4],["آشنایی با فیزیک اتمی و هسته‌ای",3]]],
    math:[MATH10,[["هندسهٔ تحلیلی و جبر",2],["هندسه",2],["تابع",2],["مثلثات",2],["توابع نمایی و لگاریتمی",2],["حد و پیوستگی",2],["آمار و احتمال",2]],
          [["تابع",2],["مثلثات",2],["حدهای نامتناهی و حد در بی‌نهایت",2],["مشتق",3],["کاربردهای مشتق",2],["هندسه",2],["احتمال",2]]],
    geo:[null,[["آفرینش کیهان و تکوین زمین",1],["منابع معدنی و ذخایر انرژی زمین",1],["منابع آب و خاک",1],["زمین‌شناسی و سازه‌های مهندسی",1],["زمین‌شناسی و سلامت",1],["پویایی زمین",1],["زمین‌شناسی ایران",1]],null],
    ...GEN},
  riazi:{
    calc:[MATH10,[["جبر و معادله",3],["تابع",3],["توابع نمایی و لگاریتمی",2],["مثلثات",2],["حد و پیوستگی",2]],
          [["تابع",2],["مثلثات",2],["حدهای نامتناهی و حد در بی‌نهایت",2],["مشتق",3],["کاربردهای مشتق",3]]],
    geom:[[["ترسیم‌های هندسی و استدلال",2],["قضیهٔ تالس، تشابه و کاربردهای آن",2],["چندضلعی‌ها",2],["تجسم فضایی",1]],
          [["دایره",3],["تبدیل‌های هندسی و کاربردها",2],["روابط طولی در مثلث",2]],
          [["ماتریس و کاربردها",3],["آشنایی با مقاطع مخروطی",3],["بردارها",3]]],
    disc:[null,[["آشنایی با مبانی ریاضیات",2],["احتمال",3],["آمار توصیفی",2],["آمار استنباطی",2]],[["آشنایی با نظریهٔ اعداد",3],["گراف و مدل‌سازی",3],["ترکیبیات",3]]],
    phys:[[...PHYS10,["ترمودینامیک",3]],[["الکتریسیتهٔ ساکن",4],["جریان الکتریکی و مدارهای جریان مستقیم",3],["مغناطیس",3],["القای الکترومغناطیسی و جریان متناوب",3]],
          [["حرکت بر خط راست",3],["دینامیک و حرکت دایره‌ای",3],["نوسان و موج",3],["برهم‌کنش‌های موج",2],["آشنایی با فیزیک اتمی",2],["آشنایی با فیزیک هسته‌ای",2]]],
    chem:CHEM,
    ...GEN},
  ensani:{
    rmath:[8,8,8],adab:[12,12,12],arq:[8,7,6],hist:[12,12,12],jog:[10,10,10],soc:[10,10,10],phil:[10,12,12],psy:[null,8,null],
    fa:GEN.fa,din:GEN.din,en:GEN.en,
    /* تحلیل فرهنگی: جایگزین «هویت اجتماعی» مخصوص انسانی، فقط پایهٔ دوازدهم. ۴ فصل / ۱۳ درس؛ فصل‌بندی دقیق در
       منابع در دسترس نبود، پس مثل چند کتاب دیگر این رشته به‌صورت ۱۳ درس پشت‌سرهم آمده. */
    tahlil:[null,null,13],
    salamat:GEN.salamat,modiriat:GEN.modiriat}
};
function expandBook(arr){
  if(arr==null)return [];
  if(typeof arr==="number")return Array.from({length:arr},(_,i)=>`درس ${faStr(i+1)}`);
  /* An array of plain numbers (not [title,count] pairs) names the REAL lesson numbers of the textbook to
     include — used to skip «درس آزاد» (free-reading, non-exam) lessons while still labeling every remaining
     lesson with its true textbook number instead of renumbering 1..N. */
  if(typeof arr[0]==="number")return arr.map(n=>`درس ${faStr(n)}`);
  const out=[];arr.forEach(([t,n],i)=>{const head=/^[A-Za-z]/.test(t)?`Lesson ${i+1}: ${t}`:`فصل ${faStr(i+1)}: ${t}`;
    if(n>1)for(let k=1;k<=n;k++)out.push(`${head} — بخش ${faStr(k)}`);else out.push(head)});
  return out;
}
const curGi=()=>S.profile.grade==="10"?0:S.profile.grade==="11"?1:2;
function bookLessons(subId,gi){const ov=S.currOv&&S.currOv[subId]&&S.currOv[subId][gi];if(Array.isArray(ov)&&ov.length)return ov;
  const b=(CURR[S.profile.field]||{})[subId];return expandBook(b?b[gi]:null)}
function finalLessons(sub){return bookLessons(sub.id,curGi())}
function konkurLessons(sub){const out=[];for(let g=0;g<=curGi();g++){const nm=sub.names[g]||sub.name;bookLessons(sub.id,g).forEach(l=>out.push(`${nm} | ${l}`))}return out}
/* where the class is now, estimated from the school calendar (Mehr → end of Ordibehesht) until the student sets it */
function schoolFraction(){const j=d2j(todayD());if(j.jm>=4&&j.jm<=6)return 0;if(j.jm===3)return 1;const start=j2d(j.jm>=7?j.jy:j.jy-1,7,1);const end=j2d(j.jm>=7?j.jy+1:j.jy,2,31);const f=(todayD()-start)/(end-start);return Math.max(0,Math.min(1,f))}
/* فیزیک، ریاضی و شیمی: the "heavy" books where a rushed چصل means shaky fundamentals. */
const IMPORTANT_BOOKS=new Set(["phys","chem","math","calc","geom"]);
/* Calendar already says the class should be well into the book, but the student's own progress is still at/near
   چصل ۱ — i.e. they started late and are catching up from the beginning, so they get the faster floor instead. */
function startingFromScratch(sub){const L=finalLessons(sub).length;if(!L)return false;
  const P=prog(sub);return schoolFraction()>=0.15&&P.f<=Math.max(1,Math.round(L*0.08))}
function prog(sub){S.progress=S.progress||{};const p=S.progress[sub.id]||(S.progress[sub.id]={});
  if(p.f==null){const L=finalLessons(sub).length;p.f=Math.floor(schoolFraction()*L)}if(p.k==null)p.k=0;return p}
const chapterHeadOf=t=>{const i=t.indexOf(" — ");return i===-1?t:t.slice(0,i)};
/* Whether finishing the lesson at `idx` closes out its whole فصل/درس unit — true for the last بخش of a
   multi-part chapter (فیزیک، شیمی، ریاضی...) and, just as much, for every single-part لesson (فارسی، عربی...)
   since each of those IS its own complete unit. Used to pace مرور (review) sessions, below. */
function isUnitEnd(sub,idx){const L=finalLessons(sub);if(idx<0||idx>=L.length)return false;
  const here=L[idx],nextL=idx+1<L.length?L[idx+1]:null;return nextL==null||chapterHeadOf(nextL)!==chapterHeadOf(here)}
/* Review cadence: sub.spec marks a "real" specialized book (فیزیک، زیست، ریاضی...) vs a general/light one
   (فارسی، عربی، دین‌وزندگی، زبان — sub.spec===0). Specialized books get a مرور session after every فصل ends
   (2 sessions for the heaviest ones); general books only earn one after every 3 فصل/درس pass, since a single
   عربی یا فارسی درس is quick and doesn't need its own review right away. */
function reviewOwedOn(sub){return sub.spec?1:3}
function reviewSessionsFor(sub){return sub.spec?(IMPORTANT_BOOKS.has(sub.id)?2:1):1}
/* A multi-part chapter is several consecutive "— بخش N" entries sharing the same head text. Returns the
   remaining part labels (starting at the student's current position) still left in whichever chapter that is,
   so a student who says "let's finish this chapter today" can be given every remaining بخش as its own session
   instead of just the next one. Returns null for a single-part chapter (nothing to spread across sessions). */
function chapterRemaining(sub){const L=finalLessons(sub);const P=prog(sub);const i0=P.f;if(i0>=L.length)return null;
  const head=t=>{const i=t.indexOf(" — ");return i===-1?t:t.slice(0,i)};const h=head(L[i0]);
  if(L[i0]===h)return null; // no "— بخش" suffix at all: single-part chapter
  const parts=[];for(let i=i0;i<L.length&&head(L[i])===h;i++)parts.push(L[i]);
  return parts.length>1?{title:h,parts}:null}
/* Konkur covers grades 10, 11 and 12. Each subject's Konkur sessions rotate between the current book and the
   earlier books the student switched on. How much review happens is a flat WEEKLY session cap across ALL
   subjects combined — light: at most 2 review sessions this week, medium: 3, heavy: 5 — never a percentage
   or a share of Konkur time. Once a week's quota is used, every subject's Konkur session goes back to the
   current book until the next 7-day window resets it. There is no separate lifetime limit per subject: a
   past grade's book keeps getting review, a few sessions a week, until it's fully covered — so the whole
   thing actually gets finished well before the exam instead of trickling on forever at a low percentage. */
const REVIEW_CAP={light:2,medium:3,heavy:4};
function reviewPrefs(){const r=(S.prefs&&S.prefs.review)||{};return{g10:r.g10!==false,g11:r.g11!==false,level:REVIEW_CAP[r.level]?r.level:"medium"}}
// Past-grade review must actually finish well before Konkur, not still be running the week of the
// exam — so it's switched off entirely once inside this buffer, freeing every Konkur session for
// this year's material in the final stretch.
const REVIEW_CUTOFF_DAYS=42; // 6 weeks before Konkur
function konkurReviewCutoffActive(){const k=S.exams.find(e=>e.kind==="konkur");if(!k)return false;return daysUntil(k.date)<=REVIEW_CUTOFF_DAYS}
function pastGrades(){if(konkurReviewCutoffActive())return[];const r=reviewPrefs();const g=S.profile.grade;const out=[];if((g==="11"||g==="12")&&r.g10)out.push(0);if(g==="12"&&r.g11)out.push(1);return out}
function konkurGradeUsage(sub,g,planTasks,dateIso){
  let c=(prog(sub).kgCount&&prog(sub).kgCount[g])||0;
  Object.values(S.plans).forEach(p=>{if(p.date===dateIso)return;p.tasks.forEach(t=>{if(t.subjectId===sub.id&&t.bucket==="konkur"&&t.lessonGrade===g&&(t.status==="todo"||t.status==="doing"))c++})});
  (planTasks||[]).forEach(t=>{if(t.subjectId===sub.id&&t.bucket==="konkur"&&t.lessonGrade===g)c++});
  return c;
}
// Simple deterministic string hash + PRNG, used only to shuffle WHICH days of the week the review cap's
// sessions fall on. Seeded by the week's first date, so it's stable while regenerating the same week
// (settings tweaks, chat edits, re-render) but a different draw every time "this week" rolls forward —
// so review doesn't pile onto the same weekday pattern (e.g. always Saturday/Sunday) week after week.
function hashSeed(str){let h=2166136261;for(let i=0;i<str.length;i++){h^=str.charCodeAt(i);h=Math.imul(h,16777619)}return h>>>0}
function mulberry32(seed){let a=seed;return function(){a|=0;a=a+0x6D2B79F5|0;let t=Math.imul(a^a>>>15,1|a);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296}}
// Distributes the weekly review-session cap across THIS rolling 7-day window's dates at random (seeded per
// week, see above) — e.g. a light cap of 2 might land as {day0:0,day1:2,day2..6:0} one week and
// {day0:1,day1:0,day2:1,day3..6:0} the next, instead of always front-loading the earliest days.
function reviewDayQuotas(wk){
  const cap=REVIEW_CAP[reviewPrefs().level]||3;const rnd=mulberry32(hashSeed(wk[0]));
  const q={};wk.forEach(d=>q[d]=0);
  for(let i=0;i<cap;i++){const d=wk[Math.floor(rnd()*wk.length)];q[d]=(q[d]||0)+1}
  return q;
}
// Has TODAY's plan-in-progress already used up its (randomized) share of the weekly review cap? Checked
// per day against reviewDayQuotas() instead of a flat running total, so the cap still holds across the
// week but which days carry it shifts each week.
function pastReviewsThisWeek(dateIso,planTasks){
  const cur=curGi();const wk=weekDates();if(dateIso<wk[0]||dateIso>wk[6])return 0;
  const quota=reviewDayQuotas(wk)[dateIso]||0;
  let n=0;
  (planTasks||[]).forEach(t=>{if(t.bucket==="konkur"&&t.lessonGrade!=null&&t.lessonGrade<cur)n++});
  return n>=quota?Infinity:0;
}
function konkurGradeAt(sub,planTasks,dateIso,mins){
  const has=g=>bookLessons(sub.id,g).length>0;const cur=curGi();const usage=g=>konkurGradeUsage(sub,g,planTasks,dateIso);
  if(S.profile.grade==="grad"){const all=[0,1,2].filter(has);if(!all.length)return 2;return all.slice().sort((a,b)=>usage(a)-usage(b))[0]}
  const pe=pastGrades().filter(has);if(!pe.length)return cur;
  const oldToday=(planTasks||[]).some(t=>t.bucket==="konkur"&&t.lessonGrade!=null&&t.lessonGrade<cur);
  if(oldToday)return has(cur)?cur:pe[0];
  // پایه دهم/یازدهم review is only worth a session that's actually long enough to make progress in —
  // never squeeze it into a tail slot shorter than 45min, unless the student's own session length is
  // already under 45min (their own choice, respected as the floor instead).
  const floor=Math.min(45,+S.profile.sessionLen||45);
  if(mins!=null&&mins<floor)return has(cur)?cur:pe[0];
  // "under": past grades whose book still has real untaught material left — review must eventually cover
  // the WHOLE past book, not stop after an arbitrary few sessions, so the student actually finishes it.
  const under=pe.filter(g=>usage(g)<bookLessons(sub.id,g).length);
  if(!under.length)return has(cur)?cur:cur; // both past books fully reviewed — done, back to this year's book
  if(pastReviewsThisWeek(dateIso,planTasks)>=(REVIEW_CAP[reviewPrefs().level]||3))return has(cur)?cur:under[0];
  return under.slice().sort((a,b)=>usage(a)-usage(b))[0];
}
function konkurLessonFor(sub,planTasks,dateIso,effF,mins){
  const g=konkurGradeAt(sub,planTasks,dateIso,mins);const idx=konkurGradeUsage(sub,g,planTasks,dateIso);
  const P=prog(sub);const L=bookLessons(sub.id,g);if(!L.length)return null;const nm=sub.names[g]||sub.name;
  const isCur=g===curGi()&&S.profile.grade!=="grad";
  /* effF is P.f "as of today", also counting any final-bucket lesson already queued earlier the SAME day —
     without this, a همان‌روز «خواندن فصل ۱ بخش ۱» session (still todo, so P.f itself hasn't moved yet) left
     this konkur session thinking that content was still untaught, and mislabeled it «پیش‌خوانی» right after
     the student had, in fact, just read it that same day. */
  const F=effF!=null?effF:P.f;
  if(isCur&&idx>=F&&F===0)return{idx,grade:g,label:`پیش‌خوانی ${nm} | ${L[idx%L.length]}`};
  if(isCur&&idx>=F){ /* the class hasn't reached this part of the current book yet: practise what's been taught */
    const done=Math.max(1,Math.min(F,L.length));return{idx:idx%done,grade:g,label:`${nm} | ${L[idx%done]}`}}
  return{idx,grade:g,label:`${g<curGi()?"مرور "+nm:nm} | ${L[idx%L.length]}`};
}
/* How many مرور (review) sessions for this subject are already sitting in the week's plans (from today up to
   but not including dateIso, plus whatever's already been added to today's own plan-in-progress) and haven't
   been done yet — so we don't queue more مرور sessions than are actually owed while regenerating future days. */
function reviewsAlreadyScheduled(subId,dateIso,planTasks){
  const t0=todayIso();let n=0;
  Object.values(S.plans).forEach(q=>{if(q.date>=t0&&q.date<dateIso)q.tasks.forEach(t=>{if(t.subjectId===subId&&t.isReview&&(t.status==="todo"||t.status==="doing"))n++})});
  (planTasks||[]).forEach(t=>{if(t.subjectId===subId&&t.isReview)n++});
  return n;
}
function lessonFor(sub,bucket,dateIso,planTasks,mins){
  if(bucket==="konkur"){const P=prog(sub);
    let effF=P.f;(planTasks||[]).forEach(t=>{if(t.subjectId===sub.id&&t.bucket==="final"&&t.lessonIdx!=null)effF=Math.max(effF,t.lessonIdx+1)});
    return konkurLessonFor(sub,planTasks,dateIso,effF,mins)}
  const list=bucket==="final"?finalLessons(sub):konkurLessons(sub);if(!list.length)return null;
  const P=prog(sub);let off=0;const t0=todayIso();
  Object.values(S.plans).forEach(q=>{if(q.date>=t0&&q.date<dateIso)q.tasks.forEach(t=>{if(t.subjectId===sub.id&&t.bucket===bucket&&(t.status==="todo"||t.status==="doing"))off++})});
  (planTasks||[]).forEach(t=>{if(t.subjectId===sub.id&&t.bucket===bucket)off++});
  const base=bucket==="final"?P.f:P.k;const idx=base+off;
  if(bucket==="final"&&idx>=list.length)return{idx,label:"مرور: "+list[(idx-list.length)%list.length]};
  if(bucket==="final"){const head=t=>{const i=t.indexOf(" — ");return i===-1?t:t.slice(0,i)};
    const here=list[idx%list.length],nextL=idx+1<list.length?list[idx+1]:null;
    const chapterEnd=idx>0&&head(list[idx-1]??"")===head(here)&&(nextL==null||head(nextL)!==head(here)); // last part of a multi-part chapter (or the whole book)
    const chapterStart=idx===0||head(list[idx-1]??"")!==head(here); // first part of a chapter never touched before: nothing to test/practice yet
    return{idx,label:here,chapterEnd,chapterStart};}
  return{idx,label:list[idx%list.length]};
}

/* ================= State ================= */
const DEFAULT_AV=()=>({0:{on:true,start:"15:30",end:"21:30",minutes:360},1:{on:true,start:"15:30",end:"21:30",minutes:360},2:{on:true,start:"15:30",end:"21:30",minutes:360},3:{on:true,start:"15:30",end:"21:30",minutes:360},4:{on:true,start:"15:30",end:"21:30",minutes:360},5:{on:true,start:"09:00",end:"17:00",minutes:480},6:{on:true,start:"09:30",end:"16:30",minutes:420}});
const DEFAULT_SLEEP=()=>({wake:"06:30",bed:"23:00",wakeOff:"08:30",bedOff:"23:30"});
function normAv(av){for(let i=0;i<7;i++){const a=av[i]||(av[i]={on:false,start:"16:00",end:"16:00",minutes:0});if(!a.end)a.end=hmA(toMin(a.start)+(+a.minutes||0));a.minutes=Math.max(0,toMin(a.end)-toMin(a.start))}return av}
function freshState(){return{v:1,onboarded:false,profile:{name:"",grade:"12",field:"tajrobi",konkurYear:konkurYearFor("12"),sessionLen:60,breakLen:10,retake:false,dailyGoal:240,email:"",avatar:null,theme:"silver"},
  availability:DEFAULT_AV(),subjects:[],exams:[],results:[],finalScores:{},finalExcluded:{},plans:{},overrides:{},pinned:{},excluded:{},backlog:{},log:[],reports:[],chat:[],insights:{},
  prefs:{order:"hard_first",maxSubjects:4,dailySubjects:[],notes:"",pace:"steady"},sub:null,timer:null,intents:[],
  sleep:DEFAULT_SLEEP(),remind:{session:true,pre:true,wake:true,bed:true,report:true},holiday:{start:"09:00",end:"18:00"},progress:{},currOv:{},tickets:[]}}
let S=freshState();
const THEMES=[["silver","نقره‌ای تیره"],["blue","آبی تیره"],["light","روشن"]];
function applyTheme(){const t=(S.profile&&S.profile.theme)||"silver";if(t==="silver")document.documentElement.removeAttribute("data-appearance");else document.documentElement.setAttribute("data-appearance",t);
  const tc=document.querySelector('meta[name="theme-color"]');if(tc)tc.setAttribute("content",{silver:"#060708",blue:"#05070D",light:"#F3F4F7"}[t]||"#060708");
  const sb=document.querySelector('meta[name="apple-mobile-web-app-status-bar-style"]');if(sb)sb.setAttribute("content",t==="light"?"default":"black-translucent")}
let TAB="today";let WEEK_OFF=0; let ANIM=true; let OB_STEP=0; let OPEN_WHY=null; let STORE="memory"; let LOGGED_OUT=false; let CARRY=null; let TX_EXPANDED=false;
let OPEN_TICKET=null; let NEW_TICKET_OPEN=false;
let TICKET_IMG=null; let TICKET_DRAFT="";
let NT_PREFILL_SUBJECT=""; let NT_PREFILL_MSG="";
let db=null, userId=null, saveTimer=null, saving=false, saveAgain=false;
const LS_KEY="evono-state-v1";

function buildSubjects(field,grade){
  return CATALOG[field].areas.map(a=>({id:a.id,name:a.name,names:a.names,kw:a.kw,spec:a.spec,level:3,chapter:""}));
}
function courseName(sub,grade){const g=grade==="10"?0:grade==="11"?1:2;return sub.names[g]||sub.name}
function gradeIdx(){return S.profile.grade==="10"?0:S.profile.grade==="11"?1:2}

/* Auto-create the three main exams from the rule set. Dates are estimates until the official timetable is published. */
function buildMainExams(){
  const K=S.profile.konkurYear, g=S.profile.grade, out=[];
  const finals=(gradeNum,year)=>{let day=3;S.subjects.forEach(s=>{const nm=s.names[gradeNum===12?2:1];if(!nm)return;
    out.push({id:"f"+gradeNum+"-"+s.id,kind:gradeNum===12?"final12":"final11",subjectId:s.id,title:"امتحان نهایی "+nm,date:isoFromJ(year,3,Math.min(day,31)),estimated:true});day+=3;});};
  if(g==="12")finals(12,K);
  if(g==="11"){finals(11,K-1);finals(12,K);}
  if(g==="10"){finals(11,K-1);finals(12,K);}
  out.push({id:"konkur",kind:"konkur",subjectId:null,title:"کنکور سراسری "+faStr(K),date:isoFromJ(K,4,25),estimated:true});
  const keep=S.exams.filter(e=>!["final11","final12","konkur"].includes(e.kind));
  S.exams=[...out,...keep];
}

/* ================= Persistence ================= */
function serial(){return JSON.parse(JSON.stringify(S))}
function trimState(){
  const cut=isoFromD(todayD()-30);
  Object.keys(S.plans).forEach(k=>{if(k<cut)delete S.plans[k]});
  Object.keys(S.overrides).forEach(k=>{if(k<cut)delete S.overrides[k]});
  Object.keys(S.pinned).forEach(k=>{if(k<cut)delete S.pinned[k]});
  S.excluded=S.excluded||{};Object.keys(S.excluded).forEach(k=>{if(k<cut)delete S.excluded[k]});
  if(S.log.length>600)S.log=S.log.slice(-600);
  if(S.reports.length>90)S.reports=S.reports.slice(-90);
  if(S.chat.length>30)S.chat=S.chat.slice(-30);
  if(S.results.length>300)S.results=S.results.slice(-300);
}
function save(){trimState();clearTimeout(saveTimer);saveTimer=setTimeout(flush,700)}
async function flush(){
  const data=serial();
  try{localStorage.setItem(LS_KEY,JSON.stringify(data))}catch(e){}
  scheduleBackendSync();
  if(!db||!userId)return;
  if(saving){saveAgain=true;return}
  saving=true;
  try{await db.doc("data/users/"+userId+"/state").set(data);STORE="account"}
  catch(e){console.warn("save failed",e&&e.code)}
  finally{saving=false;if(saveAgain){saveAgain=false;flush()}}
}
/* ================= Optional external backup (see backend/.env.example EXTERNAL_DB_*, README.md) =================
   Best-effort background backup of this browser's local state to whatever database the backend
   operator optionally configured. If nothing is configured there, PUT /api/me/sync just replies
   {enabled:false} and every function below is a silent no-op — the student's data keeps living only
   in this browser's localStorage exactly as it does with nothing set up. Never blocks save()/flush(),
   never shows the student anything: a network failure, a logged-out session, or a disabled feature
   all look identical from here. */
let syncTimer=null,syncing=false,syncAgain=false;
function scheduleBackendSync(){if(!authToken())return;clearTimeout(syncTimer);syncTimer=setTimeout(syncToBackend,4000)}
async function syncToBackend(){
  if(!authToken())return;
  if(syncing){syncAgain=true;return}
  syncing=true;
  try{await api("/api/me/sync",{method:"PUT",body:{data:serial()}})}
  catch(e){/* not configured, offline, or logged out — silently keep local-only, same as always */}
  // Separate from the optional full-state backup above (that one needs EXTERNAL_DB_* configured and
  // mirrors everything; this one always works and only pushes the bits the landing page's signed-in
  // header check (GET /api/public/whoami, via app.evono.ir's session cookie) actually needs to show a
  // name and avatar there — see backend/src/routes/public.js.
  try{await api("/api/me",{method:"PUT",body:{name:S.profile.name||null,grade:S.profile.grade||null,field:S.profile.field||null,theme:S.profile.theme||null,profile:{avatar:S.profile.avatar||null}}})}
  catch(e){/* offline or logged out — the landing page just won't show them as signed in yet */}
  finally{syncing=false;if(syncAgain){syncAgain=false;syncToBackend()}}
}
/** Called once from boot(), only when this browser has no local state yet (a new device, or
 *  localStorage was cleared) and the student is logged in — restores their last backup, if the
 *  backend has the external database configured and something was actually saved there. Never
 *  overwrites data that's already in this browser: local always wins once it exists. */
async function restoreFromBackend(){
  if(!authToken())return false;
  try{
    const r=await api("/api/me/sync");
    if(r&&r.enabled&&r.data&&typeof r.data==="object"){
      S={...freshState(),...r.data};
      try{localStorage.setItem(LS_KEY,JSON.stringify(S))}catch(e){}
      return true;
    }
  }catch(e){/* not configured, offline, or nothing backed up yet — just start fresh locally like always */}
  return false;
}
/* Zarinpal redirects the browser back to this same page (see backend/src/routes/pay.js's /callback,
   which is what actually calls Zarinpal's verify endpoint) with ?payment=success|failed&order=CODE.
   There's no client-side routing in this SPA, so this just reads those query params once on boot,
   shows the honest result, and clears them from the URL. */
async function handlePaymentReturn(){
  const q=new URLSearchParams(location.search);
  const payment=q.get("payment");
  if(!payment)return;
  const order=q.get("order")||"";
  history.replaceState(null,"",location.pathname);
  TAB="plans";ANIM=true;render();
  const type=q.get("type")||"sub";
  if(payment==="success"){
    await syncSubscription();
    const body=type==="topup"
      ?`تراکنش تأیید شد و پیام‌های اضافهٔ <b class='brand-word'>EvonoAI</b> به حسابت اضافه شد.${order?` شمارهٔ پیگیری: <span class="num" dir="ltr">#${esc(order)}</span>`:""}`
      :`تراکنش تأیید شد و اشتراک تو فعال شد یا (اگر اشتراک دیگری فعال بود) در صف قرار گرفت.${order?` شمارهٔ پیگیری: <span class="num" dir="ltr">#${esc(order)}</span>`:""}`;
    showModal(`<div class="modal-icon ok">✓</div><h2>پرداخت با موفقیت انجام شد</h2><p class="muted">${body}</p>
      <div class="row" style="justify-content:center;margin-top:20px"><button class="btn primary" data-m="close">باشه</button></div>`);
  }else{
    showModal(`<div class="modal-icon fail">✕</div><h2>پرداخت ناموفق بود</h2><p class="muted">تراکنش تکمیل یا تأیید نشد؛ مبلغی از حساب تو کسر نشده است.${order?` شمارهٔ پیگیری: <span class="num" dir="ltr">#${esc(order)}</span>`:""}</p>
      <div class="row" style="justify-content:center;margin-top:20px"><button class="btn primary" data-m="close">باشه</button></div>`);
  }
}
async function boot(){
  let raw=null;
  try{raw=localStorage.getItem(LS_KEY);if(raw){S={...freshState(),...JSON.parse(raw)};STORE="local"}}catch(e){}
  // Fresh browser (nothing in localStorage yet) + logged in: try restoring the student's last backup
  // from the optional external database before falling back to a blank slate — see restoreFromBackend()
  // above. Skipped entirely whenever local data already exists, so it can never clobber it.
  if(!raw)await restoreFromBackend();
  S.sleep={...DEFAULT_SLEEP(),...(S.sleep||{})};S.remind={...freshState().remind,...(S.remind||{})};S.profile={...freshState().profile,...(S.profile||{})};normAv(S.availability);
  applyTheme();render();
  const c=window.claude;
  if(c&&c.use){
    try{
      const [dbNs,userNs]=await Promise.all([c.use("db"),c.use("user")]);
      if(dbNs&&userNs){userId=await userNs.id();if(userId){db=dbNs;
        try{const snap=await db.doc("data/users/"+userId+"/state").get();
          if(snap.exists){S={...freshState(),...snap.data()};S=JSON.parse(JSON.stringify(S));STORE="account"}
          else if(S.onboarded){STORE="account";flush()} else STORE="account";
        }catch(e){console.warn(e&&e.code)}}}
    }catch(e){console.warn(e)}
  }
  S.sleep={...DEFAULT_SLEEP(),...(S.sleep||{})};S.remind={...freshState().remind,...(S.remind||{})};S.profile={...freshState().profile,...(S.profile||{})};normAv(S.availability);
  {const n=sanitizeTimes(S.sleep,S.availability,S.holiday);normAv(S.availability);if(n.length){Object.keys(S.plans).forEach(k=>{if(k>=todayIso()&&!(S.plans[k]&&S.plans[k].custom))delete S.plans[k]});save()}}
  applyTheme();processPastDays();render();
  if(S.onboarded)await handlePaymentReturn();
  if(S.timer&&!S.timer.paused&&S.timer.endAt<=Date.now())timerEnd(true);
  if(S.onboarded)checkSubExpiry();
  checkIOSInstallTip();
}
/* iOS Safari can't be "installed" via a browser prompt like Chrome's beforeinstallprompt — the only way
   onto the home screen is the student doing it themselves from Safari's own Share sheet. So instead of a
   fake install button, this just recognizes that situation (iPhone/iPad, in Safari, not already added) and
   shows a small one-time tip pointing at the real Share button. Dismissing it (or already being installed)
   is remembered so it never nags twice. */
function isIOSDevice(){
  const ua=navigator.userAgent||navigator.vendor||"";
  return /iPad|iPhone|iPod/.test(ua)||(navigator.platform==="MacIntel"&&navigator.maxTouchPoints>1);
}
function isStandaloneApp(){
  return window.navigator.standalone===true||(window.matchMedia&&window.matchMedia("(display-mode: standalone)").matches);
}
function isSafariBrowser(){
  const ua=navigator.userAgent||"";
  return /Safari/.test(ua)&&!/CriOS|FxiOS|EdgiOS|OPiOS|OPT\/|GSA/.test(ua);
}
function checkIOSInstallTip(){
  try{
    if(isStandaloneApp())return;
    if(!isIOSDevice()||!isSafariBrowser())return;
    if(localStorage.getItem("a2hsDismissed"))return;
    const el=$("#a2hs");if(!el)return;
    el.hidden=false;
    $("#a2hsClose").onclick=()=>{el.hidden=true;try{localStorage.setItem("a2hsDismissed","1")}catch(e){}};
  }catch(e){}
}
/* Buying a plan while another is already active never overwrites what's already queued — every purchase
   stacks onto the end of the line, in order. S.sub.queue is an array of plan ids, each one starting the
   moment the one ahead of it (or the current active term, for the first) finishes. Older saved states only
   ever had a single S.sub.next slot; migrate that into a one-item queue the first time we touch it. */
function migrateSubQueue(){
  if(!S.sub)return;
  if(S.sub.next&&!Array.isArray(S.sub.queue)){S.sub.queue=[S.sub.next]}
  delete S.sub.next;
  if(!Array.isArray(S.sub.queue))S.sub.queue=[];
}
function subQueue(){migrateSubQueue();return S.sub?S.sub.queue:[]}
/* Timestamp the (0-based) index-th item in the queue will start: the current term's end, plus the full
   duration of every queued plan ahead of it. Used both to show a purchase's real start date up front and
   to activate each queued plan, in turn, once its predecessor's term actually ends. */
function queueSlotStart(index){
  if(!S.sub)return Date.now();
  let t=S.sub.until;const q=subQueue();
  for(let i=0;i<index&&i<q.length;i++)t+=PLAN_MS[q[i]]||MONTH_MS;
  return t;
}
/* If the current term has actually run out and a plan is waiting in the queue (bought while the old one
   was still active — see resolveGateway), swap it in now and keep the rest of the queue behind it. Runs
   every render, so it fires the moment the student opens the app after their current term ends, without
   waiting for any explicit "renew" click. */
function activateQueuedSub(){
  const q=subQueue();
  if(!S.sub||!q.length||S.sub.until>Date.now())return;
  const now=Date.now();
  const nextPlan=q[0];const rest=q.slice(1);
  S.sub={plan:nextPlan,start:now,until:now+(PLAN_MS[nextPlan]||MONTH_MS),queue:rest};S.aiUse=null;S.seenExpiryFor=null;save();
}
/* Shared "close to the end of the term" check — same window the one-time heads-up modal uses (2 days for
   the 7-day weekly plan, 5 days otherwise), but with no once-per-cycle gating, so UI like the plan-card
   button can reflect it on every render, not just the first time it's true. */
function subNearExpiry(){
  if(!S.sub||!subActive()||subQueue().length)return false;
  const daysLeft=Math.ceil((S.sub.until-Date.now())/86400000);
  const window=S.sub.plan==="weekly"?2:5;
  return daysLeft<=window;
}
/* One heads-up per subscription period, right when a student opens the app close to its end — never more
   than once for the same S.sub.until, so renewing resets it and it can warn again next time it's close.
   Skipped entirely if a plan is already queued behind it — the student already took care of it. */
function checkSubExpiry(){
  if(!subNearExpiry())return;
  const daysLeft=Math.ceil((S.sub.until-Date.now())/86400000);
  if(S.seenExpiryFor===S.sub.until)return;
  S.seenExpiryFor=S.sub.until;save();
  const p=PLANS.find(x=>x.id===subPlan());
  showModal(`<div class="modal-icon">⏳</div><h2>اشتراک ${p?esc(p.name):""} تو ${daysLeft<=1?"فردا":`تا ${fa(daysLeft)} روز دیگر`} تمام می‌شود</h2>
    <p class="muted">اگر تمدید نکنی، این‌ها را از دست می‌دهی:</p>
    <ul style="text-align:right;margin:10px 0 0;padding-inline-start:18px;color:var(--ink-2);line-height:2">
      <li>گفت‌وگو و تحلیل با <b class='brand-word'>EvonoAI</b> (چت آزاد، تحلیل گزارش روزانه، مرور هفتگی)</li>
      <li>${p&&p.feat&&p.feat[0]?esc(p.feat[0]):(aiQuota()?`${fa(aiQuota())} پیام <b class='brand-word'>EvonoAI</b>`:`دسترسی به <b class='brand-word'>EvonoAI</b>`)}</li>
    </ul>
    <p class="small muted" style="margin-top:10px">برنامهٔ هفته، تایمر جلسه، یادآورها و گزارش روزانه حتی بدون اشتراک هم کار می‌کنند.</p>
    <div class="row" style="justify-content:center;margin-top:18px"><button class="btn primary" data-m="plans">تمدید اشتراک</button><button class="btn ghost" data-m="close">بعداً</button></div>`);
}

/* ================= Planner engine (deterministic) ================= */
function daysUntil(iso){return dFromIso(iso)-todayD()}
function upcoming(kinds){return S.exams.filter(e=>(!kinds||kinds.includes(e.kind))&&daysUntil(e.date)>=0).sort((a,b)=>a.date<b.date?-1:1)}
function examFor(subId,kind){return S.exams.find(e=>e.kind===kind&&e.subjectId===subId)}
function currentFinalKind(){const g=S.profile.grade;return g==="12"?"final12":g==="11"?"final11":null}
function lastResult(subId,kind){const r=S.results.filter(x=>x.subjectId===subId&&x.kind===kind);return r.length?r[r.length-1]:null}
function lastTouched(subId,dateIso){let best=null;const l=lastStudied(subId);if(l&&l<dateIso)best=l;
  Object.values(S.plans).forEach(p=>{if(p.date<dateIso&&(!best||p.date>best)&&p.tasks.some(t=>t.subjectId===subId&&t.status!=="skipped"&&t.status!=="missed"))best=p.date});return best}
function recentPlanned(subId,dateIso,bucket){let n=0;const d0=dFromIso(dateIso);for(let i=1;i<=2;i++){const p=S.plans[isoFromD(d0-i)];if(p)n+=p.tasks.filter(t=>t.subjectId===subId&&t.bucket===bucket&&t.status!=="skipped").length}return n}
/* how many sessions of this subject/bucket already sit in the trailing 6 days — used to keep chapter pace realistic */
function weekLoad(subId,bucket,dateIso){let n=0;const d0=dFromIso(dateIso);for(let i=1;i<=6;i++){const p=S.plans[isoFromD(d0-i)];if(p)n+=p.tasks.filter(t=>t.subjectId===subId&&t.bucket===bucket&&t.status!=="skipped"&&t.status!=="missed").length}return n}
function lastStudied(subId){for(let i=S.log.length-1;i>=0;i--){const l=S.log[i];if(l.subjectId===subId&&l.status==="done")return l.date}return null}
function countsInFinals(sub){const g=S.profile.grade;if(g==="12"||g==="11")return !!sub.names[g==="12"?2:1];return false}

/* ---- برنامهٔ امتحانی (exam-prep tab) ----
   The global default is exactly 3 weeks (21 days) before the nearest امتحان نهایی — a student can ask
   EvonoAI to start it sooner (more days out, e.g. "4 weeks" = 28), never later/shorter than the 21-day floor. */
function examPrepWindowDays(){const P=S.prefs||{};const v=Math.round(+P.examPrepDays);return Math.max(21,isNaN(v)?0:v)}
function examPrepFirst(){const fk=currentFinalKind();if(!fk)return null;const up=upcoming([fk]);return up.length?up[0]:null}
function examPrepActive(){const g=S.profile.grade;if(g!=="11"&&g!=="12")return false;const first=examPrepFirst();if(!first)return false;return daysUntil(first.date)<=examPrepWindowDays()}
/* The student's own answers from the برنامهٔ امتحانی setup wizard (see openExamPrepWizard) — a lazily-
   initialized bag on S so old saved states without it still work. subjectIds/examTimes/sleep/sessionLen/
   breakLen/studyMinutes are all null until the wizard (or EvonoAI, via set_exam_prep_plan) sets them. */
function examPrepState(){return S.examPrep=S.examPrep||{setupDone:false,school:null,studyMinutes:null,subjectIds:null,examTimes:{},sleep:null,sessionLen:null,breakLen:null}}
function examPrepSetupDone(){return !!examPrepState().setupDone}
/* Subjects that actually have a registered امتحان نهایی date this year — the only ones the wizard/AI can
   include in برنامهٔ امتحانی at all. */
function examPrepEligibleSubjects(){const fk=currentFinalKind();if(!fk)return[];return S.subjects.filter(s=>countsInFinals(s)&&examFor(s.id,fk))}
/* Must finish at least 1 full day before the exam itself — so the hard deadline for a subject's items is
   the day BEFORE its امتحان نهایی date, not the exam date itself. */
function examPrepDeadline(examDateIso){return isoFromD(dFromIso(examDateIso)-1)}
/* Every unread lesson of the book as «خواندن تشریحی» (never تست، هرگز پایه‌های قبل — این فقط دورهٔ کتاب
   امسال برای امتحان نهایی است)، سپس چند «نمونه سؤال امتحان نهایی سال‌های قبل» و یک «خلاصه‌نویسی» جمع‌بندی. */
function examPrepItems(sub){
  const L=finalLessons(sub);const P=prog(sub);
  const unread=L.slice(Math.max(0,Math.min(P.f,L.length)));
  const items=unread.map(label=>({type:"خواندن تشریحی",label}));
  const sampleCount=Math.max(2,Math.min(4,Math.ceil(L.length/6)));
  for(let i=0;i<sampleCount;i++)items.push({type:"نمونه سؤال امتحان نهایی سال‌های قبل",label:null});
  items.push({type:"خلاصه‌نویسی",label:"جمع‌بندی کل "+sub.name});
  return items;
}
/* Earliest-deadline-first packing across every final-track subject at once: each subject's own امتحان نهایی
   date is a hard deadline none of its items may cross (if the student's real available time is genuinely too
   little, items still get scheduled as soon as possible — days.lateCount flags how many missed their subject's
   own exam date, so the UI can say so honestly instead of quietly mis-scheduling). Only the three allowed
   session types ever appear here — no تست‌زنی، no بخش کنکور، nothing from another grade's book. */
function examPrepSchedule(){
  const fk=currentFinalKind();if(!fk)return{days:[],lateCount:0};
  const EP=examPrepState();
  const eligible=examPrepEligibleSubjects();
  const subs=EP.subjectIds?eligible.filter(s=>EP.subjectIds.includes(s.id)):eligible;
  const L=Number(EP.sessionLen)||Number(S.profile.sessionLen)||60;
  const queue=[];
  subs.forEach(s=>{const ex=examFor(s.id,fk);if(daysUntil(ex.date)<0)return;
    const deadline=examPrepDeadline(ex.date);
    examPrepItems(s).forEach(it=>queue.push({...it,subjectId:s.id,deadline,examDate:ex.date}))});
  queue.sort((a,b)=>a.deadline<b.deadline?-1:a.deadline>b.deadline?1:0);
  const days=[];let lateCount=0,di=0;
  // While the wizard hasn't been completed yet, fall back to the day's normal available-time window
  // (same as before this feature existed); once EP.studyMinutes is set, that becomes the day's own cap.
  const capFor=iso=>EP.studyMinutes!=null?Math.max(0,Math.round(EP.studyMinutes)):Math.max(0,availabilityFor(iso).minutes);
  let iso=isoFromD(todayD());let cur={iso,items:[]};let used=0,cap=capFor(iso);
  queue.forEach(it=>{
    while(used+L>cap&&di<220){days.push(cur);di++;iso=isoFromD(todayD()+di);cur={iso,items:[]};used=0;cap=capFor(iso)}
    if(iso>it.deadline)lateCount++;
    cur.items.push(it);used+=L;
  });
  if(cur.items.length)days.push(cur);
  return{days,lateCount};
}

/* Seasonal phase: share of time for final-exam / school work vs Konkur */
function phase(){
  const g=S.profile.grade,fk=currentFinalKind();
  const nextF=fk?upcoming([fk])[0]:null, dF=nextF?daysUntil(nextF.date):null;
  if(g==="grad")return{finals:S.profile.retake?0.3:0,label:S.profile.retake?"کنکور + ترمیم معدل":"تمرکز کامل روی کنکور",why:"دانش‌آموخته هستید؛ بیشتر وقت برای کنکور است."};
  /* پایه دهم و یازدهم قبلاً سهم تست‌شان خیلی کم بود؛ کمی افزایش یافت — یازدهم چون به کنکور نزدیک‌تر است
     و نهایی‌اش هم در سوابق تحصیلی کنکور اثر دارد، همیشه کمی بیشتر از دهم. */
  if(g==="10")return{finals:0.7,label:"پایه‌سازی",why:"پایه دهم امتحان نهایی کشوری ندارد و مستقیم در کنکور اثر ندارد، اما پایهٔ همهٔ درس‌های یازدهم، دوازدهم و کنکور است؛ کمی تست هم برای آشنایی با فرم سؤال‌ها."};
  if(dF===null)return{finals:g==="12"?0.05:0.25,label:g==="12"?"فقط کنکور":"تابستان — پایه‌سازی کنکور",why:"امتحان‌های نهایی امسال تمام شده‌اند."};
  if(dF<=30)return{finals:g==="12"?0.8:0.85,label:"آمادگی نهایی",why:`امتحان نهایی ${fa(dF)} روز دیگر است؛ تمرکز روی کتاب درسی و پاسخ تشریحی.`};
  if(dF<=75)return{finals:g==="12"?0.6:0.68,label:"شیب به سمت نهایی",why:`تا امتحان نهایی ${fa(dF)} روز مانده؛ سهم نهایی بیشتر می‌شود.`};
  return{finals:g==="12"?0.5:0.6,label:"آموزش + پایه‌سازی کنکور",why:"هنوز تا امتحان نهایی فاصله هست؛ درس‌های جدید مدرسه را یاد می‌گیرید و هم‌زمان برای کنکور کار می‌کنید."};
}
function weakness(sub){
  let w=(5-(sub.level||3)); // 0..4
  const fk=currentFinalKind(), pr=fk?lastResult(sub.id,"practice"):null, mk=lastResult(sub.id,"mock");
  if(pr&&pr.score<15)w+=1; if(pr&&pr.score>=18.5)w-=0.5;
  if(mk&&mk.score<30)w+=1; if(mk&&mk.score>=60)w-=0.5;
  return Math.max(0,w);
}
function urgency(days){if(days==null||days<0)return 1;return 1+2.2*Math.exp(-days/25)}
function scoreSubject(sub,bucket,dateIso){
  const reasons=[];let base=0;const dToday=dFromIso(dateIso);
  const K=S.profile.konkurYear, rs=ruleSet(K);
  if(bucket==="final"){
    const fk=currentFinalKind();
    if(fk&&countsInFinals(sub)){base=sub.spec?2:1.3;reasons.push(`در امتحان نهایی پایه ${S.profile.grade==="12"?"دوازدهم":"یازدهم"} اثر دارد (بخشی از سهم ${fa(rs.sabeghe)}٪ سوابق تحصیلی در کنکور ${faStr(K)})`)}
    else if(S.profile.grade==="10"){base=sub.spec?1.6:1;reasons.push("درس مدرسه و پایهٔ سال‌های بعد")}
    else if(S.profile.grade==="grad"&&S.profile.retake){base=sub.spec?1.5:1;reasons.push("برای ترمیم معدل انتخاب کرده‌اید")}
    else return null;
    const ex=fk?examFor(sub.id,fk):null;
    if(ex){const d=dFromIso(ex.date)-dToday;base*=urgency(d);if(d>=0&&d<=45)reasons.push(`امتحان نهایی این درس ${fa(d)} روز دیگر است${ex.estimated?" (تاریخ تخمینی)":""}`)}
    const pr=lastResult(sub.id,"practice");if(pr)reasons.push(`آخرین نمرهٔ تمرینی نهایی: ${fa(pr.score)} از ۲۰`);
  }else{
    if(!sub.kw)return null;
    base=sub.kw/2;reasons.push(`اهمیت ${sub.kw>=3?"بالا":"متوسط"} در کنکور رشتهٔ شما (تخمینی)`);
    const kx=S.exams.find(e=>e.kind==="konkur");if(kx){const d=dFromIso(kx.date)-dToday;base*=urgency(d*2)}
    const mk=lastResult(sub.id,"mock");if(mk)reasons.push(`آخرین درصد آزمون آزمایشی: ${fa(mk.score)}٪`);
  }
  const w=weakness(sub);base*=1+w*0.22;if((sub.level||3)<=2)reasons.push("در خودارزیابی، این درس جزو درس‌های ضعیف شماست");
  const bl=S.backlog[sub.id]||0;if(bl>0){base+=Math.min(bl,180)/120;reasons.push(`${durLabel(bl)} کار عقب‌افتاده در این درس دارید`)}
  const ls=lastTouched(sub.id,dateIso);const gap=ls?dToday-dFromIso(ls):14;if(gap>=4){base+=Math.min(gap,14)*0.04;reasons.push(ls?`${fa(gap)} روز است این درس در برنامه نبوده`:"هنوز جلسه‌ای برای این درس ثبت نشده")}
  const rp=recentPlanned(sub.id,dateIso,bucket);if(rp)base*=Math.pow(0.75,rp);
  /* don't cram a whole (multi-part) chapter into one week unless the student asked to go faster.
     Grade 10 has no national final and no konkur pressure yet, so by default we keep its pace lighter/slower
     unless the student explicitly asks to go faster (pace:"fast"). تجربی has the hardest konkur competition,
     so by default we let it move a bit faster/denser than other fields, unless the student asks for pace:"easy". */
  if(bucket==="final"){
    const pace=(S.prefs&&S.prefs.pace)||"steady";
    if(pace!=="fast"){
      const wk=weekLoad(sub.id,"final",dateIso);
      let thresh=3,decay=0.5,why="سرعت پیش‌روی این فصل را کنترل می‌کنیم تا خوب جا بیفتد؛ برای سریع‌تر رفتن بگو «سریع‌تر برو»";
      if(pace==="easy"){thresh=2;decay=0.35;why="طبق خواستهٔ شما، سرعت پیش‌روی را آسان‌تر و کم‌فشارتر نگه داشتیم؛ برای سریع‌تر رفتن بگو «سریع‌تر برو»"}
      else if(S.profile.grade==="10"){thresh=2;decay=0.4;why="پایه دهم فشار امتحان نهایی یا کنکور ندارد؛ سرعت را آرام و کم‌فشار نگه می‌داریم؛ اگر می‌خواهی سخت‌تر و سریع‌تر پیش بروی بگو «سریع‌تر برو»"}
      else if(S.profile.field==="tajrobi"){thresh=4;decay=0.62;why="رشتهٔ تجربی رقابت کنکور سنگین‌تری دارد؛ کمی فشرده‌تر پیش می‌رویم؛ اگر می‌خواهی آسان‌تر باشد بگو «آسان‌تر برو»"}
      /* فیزیک، ریاضی و شیمی روی سرعت «معمولی و کنترل‌شده» قانون سخت‌گیرانه‌تر خودشان را دارند: هر فصل با تست پایانش
         دست‌کم حدود ۳ هفته طول بکشد، چون از مهر وقت هست — مگر این‌که دانش‌آموز دیر شروع کرده و از اول کتاب عقب باشد
         که آن‌وقت برای جبران، حدود ۲ هفته برای هر فصل هدف می‌گیریم. */
      if(pace==="steady"&&IMPORTANT_BOOKS.has(sub.id)){
        if(startingFromScratch(sub)){thresh=2;decay=0.55;why=`چون از ابتدای کتاب ${sub.name} شروع کرده‌ای و از برنامهٔ کلاس عقب‌ای، این فصل را برای جبران فشرده‌تر پیش می‌بریم؛ هدف حدود ۲ هفته برای هر فصل`}
        else{thresh=1;decay=0.3;why=`از مهر وقت داری؛ فصل‌های ${sub.name} را کش می‌دهیم تا با تمرین و تست پایانش دست‌کم حدود ۳ هفته طول بکشد و خوب جا بیفتد؛ برای سریع‌تر رفتن بگو «سریع‌تر برو»`}
      }
      if(wk>=thresh){base*=Math.pow(decay,wk-(thresh-1));reasons.push(why)}
    }
  }
  S.exams.filter(e=>e.kind==="school"&&e.subjectId===sub.id).forEach(e=>{const d=dFromIso(e.date)-dToday;if(d>=0&&d<=3){base+=3/(d+1);reasons.push(`آزمون مدرسه (${e.title}) ${d===0?"امروز":fa(d)+" روز دیگر"} است`)}});
  return{score:base,reasons};
}
/* The very first session touching a chapter/lesson the student hasn't seen at all yet must be a reading
   session — تست‌زنی or تمرین before any مطالعه would ask the student to solve problems on material they were
   never taught. Used for: final-bucket chapterStart (a brand-new chapter), and konkur-bucket «پیش‌خوانی»
   sessions (current-grade content the class hasn't reached yet, so there is nothing prior to review/test). */
function freshStartType(bucket,sub,ls){
  if(!ls)return null;
  if(bucket==="final"&&ls.chapterStart&&!ls.chapterEnd)return S.profile.grade==="10"?"مطالعهٔ کتاب درسی":"مطالعهٔ خط‌به‌خط کتاب درسی";
  if(bucket==="konkur"&&ls.label&&ls.label.startsWith("پیش‌خوانی "))return "پیش‌خوانی + خلاصه‌نویسی";
  return null;
}
function taskType(bucket,sub,dateIso,n){
  const dToday=dFromIso(dateIso);
  const heavyTest=S.profile.grade==="12"||S.profile.grade==="grad"; // konkur students: most sessions must include real تست‌زنی
  if(bucket==="final"){
    if(S.profile.grade==="10")return n%2?"حل تمرین کتاب":"مطالعهٔ کتاب درسی";
    const fk=currentFinalKind();const ex=fk?examFor(sub.id,fk):null;const d=ex?dFromIso(ex.date)-dToday:99;
    if(d<=21)return n%2?"تمرین تشریحی":"نمونه‌سؤال نهایی سال‌های قبل";
    return heavyTest?["مطالعهٔ خط‌به‌خط کتاب درسی","تمرین تشریحی","تست ترکیبی از کتاب کمک‌درسی"][n%3]:(n%2?"تمرین تشریحی":"مطالعهٔ خط‌به‌خط کتاب درسی");
  }
  const kx=S.exams.find(e=>e.kind==="konkur");const d=kx?dFromIso(kx.date)-dToday:999;
  if(d<=60)return heavyTest?["تست‌زنی (زمان‌دار)","آزمون زمان‌دار","مرور خطاها و جمع‌بندی"][n%3]:["آزمون زمان‌دار","مرور خطاها","جمع‌بندی"][n%3];
  return heavyTest?["تست‌زنی (کتاب‌های کمک‌آموزشی)","درسنامه + تست","تست‌زنی (کتاب‌های کمک‌آموزشی)"][n%3]:(n%2?"درسنامه + تست":"تست‌زنی");
}
function seasonOf(iso){if(S.profile.grade==="grad")return "free";const j=jFromIso(iso);
  if(j.jm>=4&&j.jm<=6)return "summer";if((j.jm===1&&j.jd<=13)||(j.jm===12&&j.jd>=26))return "nowruz";if(j.jm===3)return "exams";return "school"}
const SEASON={summer:{t:"تابستان",d:"مدرسه تعطیل است؛ برنامه از صبح شروع می‌شود و بازهٔ روزهای تعطیل به کار می‌رود.",i:"☀︎"},
  nowruz:{t:"تعطیلات نوروز",d:"مدرسه تعطیل است؛ فرصت خوبی برای جبران عقب‌افتادگی‌ها و مرور است.",i:"✿︎"},
  exams:{t:"فصل امتحانات نهایی",d:"کلاس عادی نیست؛ تمام روز برای آمادگی امتحان در اختیار توست.",i:"✎︎"},
  free:{t:"بدون مدرسه",d:"پشت‌کنکوری هستی؛ بازهٔ روزهای تعطیل برای همهٔ روزها به کار می‌رود.",i:"◆︎"},school:null};
function isOffDay(dateIso){return seasonOf(dateIso)!=="school"||[5,6].includes(wdIdx(dFromIso(dateIso)))}
function seasonBanner(iso){const k=seasonOf(iso);const x=SEASON[k];
  const nx=isoFromD(dFromIso(iso)+1);
  if(x&&k!=="free"&&seasonOf(nx)==="school")return `<section class="season"><span class="sico">✎</span><div><b>سال تحصیلی از فردا شروع می‌شود</b><p class="small muted">امروز آخرین روز ${x.t} است. از فردا برنامه‌ها با ساعت مدرسه و بازهٔ روزهای مدرسه چیده شده‌اند.</p></div></section>`;
  if(!x)return "";return `<section class="season"><span class="sico">${x.i}</span><div><b>${x.t}</b><p class="small muted">${x.d} بازهٔ این روزها: ${faStr(S.holiday.start)} تا ${faStr(S.holiday.end)}</p></div><button class="btn sm" data-act="opensettings" style="margin-inline-start:auto">تغییر بازه</button></section>`}
/* A bedtime between 03:00 and 12:00 is almost always a 12-hour-clock slip (e.g. 11:00 meant 23:00). */
function fixBed(t){const m=toMin(t);return (m>=180&&m<=720)?hmA(m+720):hmA(m)}
function fixWake(t){const m=toMin(t);return (m>=780&&m<=1140)?hmA(m-720):hmA(m)}
/* An end time before the start: if adding 12h makes sense (08:30 → 20:30) use that, otherwise give 3 hours. */
function fixEnd(st,en){if(en>st)return en;if(en<720&&en+720>st)return en+720;return st+180}
function sanitizeTimes(sl,av,hol){const notes=[];
  if(sl){[["bed","خواب روزهای مدرسه"],["bedOff","خواب روزهای تعطیل"]].forEach(([k,l])=>{const f=fixBed(sl[k]);if(f!==sl[k]){notes.push(`${l} ${faStr(sl[k])} → ${faStr(f)}`);sl[k]=f}});
    [["wake","بیداری روزهای مدرسه"],["wakeOff","بیداری روزهای تعطیل"]].forEach(([k,l])=>{const f=fixWake(sl[k]);if(f!==sl[k]){notes.push(`${l} ${faStr(sl[k])} → ${faStr(f)}`);sl[k]=f}})}
  if(av)for(let i=0;i<7;i++){const a=av[i];if(!a)continue;const st=toMin(a.start),en=toMin(a.end);const f=fixEnd(st,en);if(f!==en){const ne=hmA(Math.min(f,1439));notes.push(`${WD[i]}: پایان ${faStr(a.end)} → ${faStr(ne)}`);a.end=ne}a.minutes=Math.max(0,toMin(a.end)-toMin(a.start))}
  if(hol){const f=fixEnd(toMin(hol.start),toMin(hol.end));if(f!==toMin(hol.end)){const ne=hmA(Math.min(f,1439));notes.push(`روزهای تعطیل: پایان ${faStr(hol.end)} → ${faStr(ne)}`);hol.end=ne}}
  return notes}
function sleepFor(dateIso){const z=S.sleep||DEFAULT_SLEEP();const off=isOffDay(dateIso);return{wake:fixWake(off?(z.wakeOff||z.wake):z.wake),bed:fixBed(off?(z.bedOff||z.bed):z.bed)}}
function bedLimit(dateIso){const b=toMin(sleepFor(dateIso).bed);return (b<180?b+1440:b)-30}
function availabilityFor(dateIso){
  const a=S.availability[wdIdx(dFromIso(dateIso))]||{on:false};const o=S.overrides[dateIso];
  let st,en;
  if(o&&o.off)return{minutes:0,start:a.start||"16:00",end:a.start||"16:00"};
  if(o&&o.end){st=toMin(o.start);en=toMin(o.end)}
  else if(o&&o.minutes!=null){st=toMin(o.start||a.start);en=st+o.minutes}
  else if(seasonOf(dateIso)!=="school"){const h=S.holiday||{start:"09:00",end:"18:00"};st=toMin(h.start);en=fixEnd(st,toMin(h.end))}
  else{if(!a.on)return{minutes:0,start:a.start||"16:00",end:a.start||"16:00"};st=toMin(a.start);en=fixEnd(st,toMin(a.end||hmA(st+(+a.minutes||0))))}
  const sl=sleepFor(dateIso);st=Math.max(st,toMin(sl.wake));en=Math.min(en,bedLimit(dateIso));
  return{minutes:Math.max(0,en-st),start:hmA(st),end:hmA(en)};
}
function windowFor(dateIso){
  let {minutes,start,end}=availabilityFor(dateIso);
  if(dateIso===todayIso()){const nowR=Math.ceil((nowMin()+5)/5)*5;const st=toMin(start),en=toMin(start)+minutes;
    if(nowR>st){if(minutes<=0)return{minutes:0,start,end};
      const limit=en-nowR>=25?en:bedLimit(dateIso);minutes=Math.max(0,limit-nowR);if(minutes<25)minutes=0;start=hmA(nowR);end=hmA(nowR+minutes)}}
  return{minutes,start,end};
}
function generatePlan(dateIso){
  let {minutes,start}=windowFor(dateIso);
  const L=+S.profile.sessionLen||60,B=Number(S.profile.breakLen??10)||0;
  // dailyGoal is a MINIMUM the student wants ("at least 6 hours a day"), not a cap — the actual
  // availability window (whatever start/end time or per-day override the student set) is what
  // decides how much gets scheduled. Feasibility warnings elsewhere (maybeWarnSchedule) already tell
  // the student if a window is too SHORT to hit their goal; generation itself must never shrink a
  // window that's longer than the goal — that would silently throw away time the student asked for.
  const tasks=[];let t=toMin(start);let used=0;
  const pins=(S.pinned[dateIso]||[]).slice();
  const endW=toMin(start)+minutes;let streak=0;
  const addTask=(o)=>{if(tasks.length&&t+Math.min(o.minutes,25)>endW)return false;const m=Math.min(o.minutes,Math.max(25,endW-t));tasks.push({id:uid(),start:t,status:"todo",...o,minutes:m});t+=m+B;used+=m+B;streak++;if(streak%3===0&&minutes>300){t+=30;used+=30}return true};
  pins.forEach(p=>{if(used+p.minutes>minutes+5&&tasks.length)return;addTask({...p,pinned:true})});
  let remaining=minutes-used;if(minutes>300)remaining-=Math.floor(remaining/(3*(L+B)+30))*30;
  let n=Math.floor((remaining+B)/(L+B));let tail=remaining-n*(L+B)+B;
  const ph=phase();
  const cand={final:[],konkur:[]};
  const ex=(S.excluded&&S.excluded[dateIso])||[];
  S.subjects.forEach(s=>{if(s.off)return;["final","konkur"].forEach(b=>{if(ex.includes(s.id+":"+b))return;const r=scoreSubject(s,b,dateIso);if(r)cand[b].push({sub:s,...r})})});
  if(!cand.final.length&&!cand.konkur.length)return{date:dateIso,minutes,start,tasks,phase:ph.label,split:ph.finals};
  const slots=n+(tail>=25?1:0);
  let nF=Math.round(slots*ph.finals);if(!cand.final.length)nF=0;if(!cand.konkur.length)nF=slots;
  const P=S.prefs||{};const maxS=Math.max(1,+P.maxSubjects||99);const picks=[];const usedS=new Set();
  (P.dailySubjects||[]).forEach(id=>{if(picks.length>=slots)return;for(const b of ["final","konkur"]){const c=cand[b].find(x=>x.sub.id===id);if(c){picks.push({...c,bucket:b,reasons:["طبق خواستهٔ شما این درس هر روز در برنامه است",...c.reasons]});usedS.add(id);c.score*=0.5;break}}});
  const pickFrom=(list,count,bucket)=>{for(let i=0;i<count;i++){const pool=list.filter(x=>usedS.size<maxS||usedS.has(x.sub.id));if(!pool.length)break;pool.sort((a,b)=>b.score-a.score);
    let c=pool[0];const last=picks[picks.length-1];if(last&&last.sub.id===c.sub.id&&pool[1])c=pool[1];picks.push({...c,bucket});usedS.add(c.sub.id);c.score*=0.5;}};
  const haveF=picks.filter(p=>p.bucket==="final").length;
  pickFrom(cand.final,Math.max(0,nF-haveF),"final");pickFrom(cand.konkur,Math.max(0,slots-picks.length),"konkur");
  if(picks.length<slots)pickFrom(cand.final,slots-picks.length,"final");
  if(P.order==="easy_first")picks.sort((a,b)=>a.score-b.score);
  else if(P.order==="mixed"){picks.sort((a,b)=>b.score-a.score);const o=[];let i=0,j=picks.length-1;while(i<=j){o.push(picks[i++]);if(i<=j)o.push(picks[j--])}picks.splice(0,picks.length,...o)}
  else picks.sort((a,b)=>b.score-a.score);
  for(let i=1;i<picks.length;i++){if(picks[i].sub.id===picks[i-1].sub.id){const j=picks.findIndex((p,k)=>k>i&&p.sub.id!==picks[i].sub.id);if(j>0){[picks[i],picks[j]]=[picks[j],picks[i]]}}}
  const count={};
  picks.forEach((p,i)=>{const isTail=tail>=25&&i===picks.length-1;const mins=isTail?Math.min(tail,L):L;count[p.sub.id]=(count[p.sub.id]||0)+1;
    if(p.bucket==="final"){
      const P=prog(p.sub);const owed=P.rv||0;
      if(owed>reviewsAlreadyScheduled(p.sub.id,dateIso,tasks)){
        addTask({subjectId:p.sub.id,bucket:p.bucket,minutes:mins,type:"مرور دوره‌ای",isReview:true,lesson:P.rvNote?`مرور: ${P.rvNote}`:`مرور فصل‌های اخیر ${p.sub.name}`,lessonIdx:null,lessonGrade:null,reasons:["چند فصل/درس این کتاب تازه تمام شده؛ یک جلسهٔ مرور قبل از ادامه دادن",...p.reasons.slice(0,3)],priority:p.score>=3?"بالا":p.score>=1.8?"متوسط":"عادی"});
        return;
      }
    }
    const ls=lessonFor(p.sub,p.bucket,dateIso,tasks,mins);
    const chEnd=ls&&ls.chapterEnd&&p.bucket==="final";
    const fresh=!chEnd&&freshStartType(p.bucket,p.sub,ls);
    const ty=chEnd?"تست جامع پایان فصل":fresh||taskType(p.bucket,p.sub,dateIso,count[p.sub.id]+i);
    addTask({subjectId:p.sub.id,bucket:p.bucket,minutes:mins,type:ty,lesson:ls?ls.label:null,lessonIdx:ls?ls.idx:null,lessonGrade:ls&&ls.grade!=null?ls.grade:null,reasons:chEnd?["پایان این فصل رسید؛ یک تست جامع از کل فصل قبل از رفتن سراغ فصل بعد",...p.reasons.slice(0,3)]:fresh?["این بخش را قبلاً نخوانده‌ای؛ اول باید خوانده شود",...p.reasons.slice(0,3)]:p.reasons.slice(0,4),priority:p.score>=3?"بالا":p.score>=1.8?"متوسط":"عادی"})});
  return{date:dateIso,minutes,start,tasks,phase:ph.label,split:ph.finals,generatedAt:Date.now()};
}
function todayIso(){return isoFromD(todayD())}
function planFor(dateIso,force){if(force||!S.plans[dateIso]){S.plans[dateIso]=generatePlan(dateIso);if(dateIso===todayIso())S.pinned[dateIso]=[];save()}return S.plans[dateIso]}
function regenerateKeepingDone(dateIso){
  const old=S.plans[dateIso];const done=old?old.tasks.filter(t=>t.status==="done"||t.status==="skipped"||(t.status==="doing"&&S.timer&&S.timer.taskId===t.id)):[];
  const p=generatePlan(dateIso);
  p.tasks=[...done,...p.tasks.filter(t=>!done.some(d=>t.start<d.start+d.minutes&&d.start<t.start+t.minutes))].sort((a,b)=>a.start-b.start);
  if(old&&old.change)p.change=old.change;
  S.plans[dateIso]=p;S.pinned[dateIso]=[];save();return p;
}
function rollWeek(off){const s0=todayD()+off*7;return Array.from({length:7},(_,i)=>isoFromD(s0+i)).sort((a,b)=>wdIdx(dFromIso(a))-wdIdx(dFromIso(b)))}
function calWeek(off){const s=todayD()-wdIdx(todayD())+off*7;return Array.from({length:7},(_,i)=>isoFromD(s+i))}
function weekDates(){return Array.from({length:7},(_,i)=>isoFromD(todayD()+i))}
function ensureWeek(){weekDates().forEach(d=>planFor(d))}
function regenerateWeek(force){const ds=weekDates();ds.forEach((d,i)=>{const p=S.plans[d];if(p&&p.custom&&!force)return;if(i===0)regenerateKeepingDone(d);else S.plans[d]=generatePlan(d)});
  Object.keys(S.plans).filter(d=>d>ds[6]).sort().forEach(d=>{const p=S.plans[d];if(p&&p.custom&&!force)return;S.plans[d]=generatePlan(d)});save()}
/* Missed tasks from past days become backlog (never stacked onto one day) */
function processPastDays(){
  activateQueuedSub();
  const t=todayIso();let changed=false;
  Object.values(S.plans).forEach(p=>{if(p.date<t&&!p.closed){p.tasks.forEach(k=>{if(k.status==="todo"||k.status==="doing"){k.status="missed";if(k.subjectId){S.backlog[k.subjectId]=Math.min(240,(S.backlog[k.subjectId]||0)+k.minutes);S.log.push({date:p.date,subjectId:k.subjectId,bucket:k.bucket,minutes:k.minutes,status:"missed"})}}});p.closed=true;changed=true}});
  if(changed)save();
}
function exclude(dateIso,subId,bucket){S.excluded=S.excluded||{};const a=S.excluded[dateIso]=S.excluded[dateIso]||[];const key=subId+":"+bucket;if(!a.includes(key))a.push(key)}
function setTaskStatus(dateIso,taskId,status,actual){
  const p=S.plans[dateIso];if(!p)return false;const k=p.tasks.find(x=>x.id===taskId);if(!k)return false;
  const prev=k.status;k.status=status;
  if(status==="done"&&k.lessonIdx!=null&&k.subjectId&&subById(k.subjectId)){const sub=subById(k.subjectId);const P=prog(sub);if(k.bucket==="final"){
      if(isUnitEnd(sub,k.lessonIdx)){P.rc=(P.rc||0)+1;const L=finalLessons(sub);P.rvNote=chapterHeadOf(L[k.lessonIdx]||"");
        if(P.rc>=reviewOwedOn(sub)){P.rv=(P.rv||0)+reviewSessionsFor(sub);P.rc=0}}
      P.f=Math.max(P.f,k.lessonIdx+1);
    }else{P.kc=(P.kc||0)+1;if(k.lessonGrade!=null){P.kg=P.kg||{};P.kg[k.lessonGrade]=Math.max(P.kg[k.lessonGrade]||0,k.lessonIdx+1);
        P.kgCount=P.kgCount||{};P.kgCount[k.lessonGrade]=(P.kgCount[k.lessonGrade]||0)+1; // persisted usage count for konkurGradeUsage, survives old-day plan pruning
      }}}
  if(status==="done"&&k.isReview&&k.subjectId&&subById(k.subjectId)){const P=prog(subById(k.subjectId));P.rv=Math.max(0,(P.rv||0)-1)}
  if(status==="done"){const m=actual||k.minutes;k.actual=m;if(k.subjectId){S.backlog[k.subjectId]=Math.max(0,(S.backlog[k.subjectId]||0)-m);S.log.push({date:dateIso,subjectId:k.subjectId,bucket:k.bucket,minutes:m,status:"done"})}}
  if(status==="skipped"&&k.subjectId)exclude(dateIso,k.subjectId,k.bucket);
  if(status==="skipped"&&prev!=="skipped"&&k.subjectId){S.backlog[k.subjectId]=Math.min(240,(S.backlog[k.subjectId]||0)+k.minutes);S.log.push({date:dateIso,subjectId:k.subjectId,bucket:k.bucket,minutes:k.minutes,status:"skipped"})}
  save();return true;
}
/* Let the student reorder which not-yet-started session comes first, without changing which sessions
   are actually planned for the day. Only "todo" sessions move — a session already done, skipped, missed,
   or in progress keeps its real clock time, and reordering can't jump a todo session past one of those. */
function relayoutTasks(p){const B=Number(S.profile.breakLen??10)||0;let streak=0,cursor=null;
  p.tasks.forEach(t=>{
    if(t.status!=="todo"){cursor=t.start+t.minutes+B;streak++;if(streak%3===0&&p.minutes>300)cursor+=30;return}
    // No fixed task came before this one yet, so the day's own study-window start is the real anchor here —
    // NOT this task's own leftover .start, which after a reorder belongs to whichever slot it used to sit in.
    if(cursor==null)cursor=toMin(p.start);
    t.start=cursor;cursor=t.start+t.minutes+B;streak++;if(streak%3===0&&p.minutes>300)cursor+=30;
  });
}
/* Drag-reorder result: orderedTodoIds is the new order for just the "todo" sessions (from the drag list),
   everything else (done/skipped/missed/doing) keeps its own array slot untouched — same invariant as moveTask. */
function reorderTasks(dateIso,orderedTodoIds){
  const p=S.plans[dateIso];if(!p)return false;
  const todo=orderedTodoIds.map(id=>p.tasks.find(t=>t.id===id&&t.status==="todo")).filter(Boolean);
  if(todo.length!==p.tasks.filter(t=>t.status==="todo").length)return false; // ids must match exactly, or bail out
  let ti=0;p.tasks=p.tasks.map(t=>t.status==="todo"?todo[ti++]:t);
  relayoutTasks(p);p.custom=true;save();return true;
}
const subById=id=>S.subjects.find(s=>s.id===id);
function resolveDate(x){const v=String(x??"").trim().toLowerCase();if(!v||v==="today"||v==="امروز"||v==="امشب"||v==="tonight")return todayIso();if(v==="tomorrow"||v==="فردا")return isoFromD(todayD()+1);if(/^\d{4}-\d{2}-\d{2}$/.test(v))return v;return parseJ(v)}
function dayName(iso){const d=dFromIso(iso)-todayD();return d===0?"امروز":d===1?"فردا":`${WD[wdIdx(dFromIso(iso))]} ${jLabel(iso)}`}
const subName=id=>{const s=subById(id);return s?courseName(s,S.profile.grade==="grad"?"12":S.profile.grade):"—"};
/* A مرور/کنکور session can be studying an EARLIER grade's book (t.lessonGrade) than the student is
   currently in — show that book's own title (e.g. «فیزیک ۲») instead of the current grade's book
   («فیزیک ۳»), so the title never implies the wrong book for what's actually being studied. */
const taskSubName=t=>{const s=subById(t&&t.subjectId);if(!s)return "—";
  if(t.lessonGrade!=null&&t.lessonGrade!==gradeIdx())return s.names[t.lessonGrade]||s.name;
  return courseName(s,S.profile.grade==="grad"?"12":S.profile.grade)};

/* ================= Actions shared by UI and EvonoAI ================= */
const ACT={
  set_today_time({minutes,start}){const m=Math.round(Number(minutes));if(!(m>=0&&m<=900))throw new Error("زمان باید بین ۰ تا ۱۵ ساعت باشد");
    const d=todayIso();const st=start&&/^\d{1,2}:\d{2}$/.test(start)?toMin(start):Math.max(toMin(availabilityFor(d).start),Math.ceil((nowMin()+5)/5)*5);S.overrides[d]=m?{start:hmA(st),end:hmA(st+m)}:{off:true};regenerateKeepingDone(d);S.plans[d].custom=true;
    return{ok:true,message:`برنامهٔ امروز برای ${durLabel(m)} بازسازی شد`,tasks:S.plans[d].tasks.filter(t=>t.status==="todo").map(t=>({id:t.id,subject:subName(t.subjectId),minutes:t.minutes}))}},
  move_task({task_id,to_date}){const id=String(task_id);let src=null,k=null;for(const d of weekDates()){const p=S.plans[d];const x=p&&p.tasks.find(t=>t.id===id);if(x){src=d;k=x;break}}
    if(!k)throw new Error("این جلسه در برنامهٔ این هفته پیدا نشد");if(k.status==="done")throw new Error("این جلسه قبلاً انجام شده است");
    const iso=resolveDate(to_date);if(!iso)throw new Error("تاریخ مقصد باید شمسی و به شکل 1405/08/15 باشد");if(iso<=src)throw new Error("روز مقصد باید بعد از روز فعلی جلسه باشد");if(availabilityFor(iso).minutes<=0)throw new Error("آن روز روز استراحت است و زمان درس ندارد");
    (S.pinned[iso]=S.pinned[iso]||[]).push({subjectId:k.subjectId,bucket:k.bucket,minutes:k.minutes,type:k.type,reasons:["از "+jLabel(src)+" به این روز منتقل شد",...(k.reasons||[]).slice(0,2)],priority:k.priority});
    const sp=S.plans[src];sp.tasks=sp.tasks.filter(x=>x.id!==id);exclude(src,k.subjectId,k.bucket);
    if(S.plans[iso])S.plans[iso]=generatePlan(iso);
    save();return{ok:true,message:`${subName(k.subjectId)} از ${jLabel(src)} به ${jLabel(iso)} منتقل شد`}},
  set_preferences(a){const P=S.prefs=S.prefs||{};const ch=[];
    if(a.session_len!=null){const v=Math.round(+a.session_len);if(!(v>=15&&v<=150))throw new Error("طول جلسه باید بین ۱۵ دقیقه و ۲ ساعت و ۳۰ دقیقه باشد");S.profile.sessionLen=v;ch.push(`جلسه‌های ${fa(v)} دقیقه‌ای`)}
    if(a.break_len!=null){const v=Math.round(+a.break_len);if(!(v>=0&&v<=45))throw new Error("استراحت باید بین ۰ تا ۴۵ دقیقه باشد");S.profile.breakLen=v;ch.push(`استراحت ${fa(v)} دقیقه`)}
    if(a.order!=null){if(!["hard_first","easy_first","mixed"].includes(a.order))throw new Error("ترتیب درس‌ها نامعتبر است");P.order=a.order;ch.push({hard_first:"اول درس سخت",easy_first:"اول درس آسان",mixed:"یکی سخت یکی آسان"}[a.order])}
    if(a.pace!=null){if(!["easy","steady","fast"].includes(a.pace))throw new Error("سرعت پیشروی باید easy، steady یا fast باشد");P.pace=a.pace;ch.push(a.pace==="fast"?"سرعت پیشروی فصل‌ها: سریع‌تر (به درخواست خودت)":a.pace==="easy"?"سرعت پیشروی فصل‌ها: آسان‌تر و کم‌فشارتر (به درخواست خودت)":"سرعت پیشروی فصل‌ها: معمولی و کنترل‌شده")}
    if(a.max_subjects_per_day!=null){const v=Math.round(+a.max_subjects_per_day);if(!(v>=1&&v<=8))throw new Error("تعداد درس در روز باید بین ۱ تا ۸ باشد");P.maxSubjects=v;ch.push(`حداکثر ${fa(v)} درس در روز`)}
    if(Array.isArray(a.daily_subjects)){P.dailySubjects=a.daily_subjects.map(String).filter(x=>subById(x));ch.push(P.dailySubjects.length?"درس‌های هرروزه: "+P.dailySubjects.map(subName).join("، "):"بدون درس هرروزه")}
    if(a.notes!=null){P.notes=String(a.notes).slice(0,300)}
    if(a.availability&&typeof a.availability==="object"){Object.entries(a.availability).forEach(([k,v])=>{const i=+k;if(!(i>=0&&i<=6)||!v)return;const cur=S.availability[i];
      if(v.minutes!=null)cur.minutes=Math.max(0,Math.min(900,Math.round(+v.minutes)||0));if(v.start&&/^\d{1,2}:\d{2}$/.test(v.start))cur.start=v.start.padStart(5,"0");if(v.on!=null)cur.on=!!v.on;if(cur.minutes===0)cur.on=false});ch.push("زمان روزهای هفته")}
    Object.keys(S.overrides).forEach(k=>{if(k>todayIso())delete S.overrides[k]});
    regenerateWeek();return{ok:true,message:"برنامهٔ هفته بازسازی شد"+(ch.length?" | "+ch.join("، "):"")}},
  set_subject_progress({subject_id,lesson_number}){const s=subById(String(subject_id));if(!s)throw new Error("درس نامعتبر است");const L=finalLessons(s);if(!L.length)throw new Error("این درس فهرست فصل ندارد");
    const n=Math.round(Number(lesson_number));if(!(n>=1&&n<=L.length+1))throw new Error(`شمارهٔ جلسه باید بین ۱ تا ${fa(L.length)} باشد`);prog(s).f=n-1;regenerateWeek();
    return{ok:true,message:`${subName(s.id)}: از «${n-1<L.length?L[n-1]:"مرور کتاب"}» ادامه می‌دهیم`}},
  set_holiday_window({start,end}){const ok=v=>/^\d{1,2}:\d{2}$/.test(String(v));if(!ok(start)||!ok(end))throw new Error("ساعت شروع و پایان باید به شکل HH:MM باشد");if(toMin(end)-toMin(start)<60)throw new Error("بازه باید دست‌کم ۱ ساعت باشد");
    S.holiday={start:hmA(toMin(start)),end:hmA(toMin(end))};regenerateWeek();return{ok:true,message:`بازهٔ روزهای بدون مدرسه: ${faStr(S.holiday.start)} تا ${faStr(S.holiday.end)}`}},
  set_exam_prep_start({days_before,weeks_before}){
    let d=days_before!=null?Math.round(+days_before):(weeks_before!=null?Math.round(+weeks_before*7):null);
    if(d==null||isNaN(d))throw new Error("باید تعداد روز یا هفتهٔ پیش از امتحان را بگویی");
    if(d<21)throw new Error("برنامهٔ امتحانی همیشه دست‌کم ۳ هفته (۲۱ روز) پیش از امتحان است؛ کمتر از این ممکن نیست — فقط می‌شود زودتر شروعش کرد");
    if(d>70)throw new Error("بیش از ۱۰ هفته پیش از امتحان معنی ندارد");
    S.prefs=S.prefs||{};S.prefs.examPrepDays=d;save();
    const first=examPrepFirst();
    return{ok:true,message:`برنامهٔ امتحانی از ${fa(d)} روز پیش از نزدیک‌ترین امتحان نهایی نشانت داده می‌شود`+(first?` — یعنی از ${jLabel(isoFromD(dFromIso(first.date)-d))}`:"")+(first&&daysUntil(first.date)<=d?" (همین الان فعال شد)":"")}},
  set_daily_goal({hours}){const h=Number(hours);if(!(h>0&&h<=15))throw new Error("ساعت مطالعهٔ روزانه باید بین ۰ تا ۱۵ ساعت باشد");
    const targetMinutes=Math.round(h*60);const pr=S.profile;let note="";
    const fit=scheduleFits(S.availability,pr.sessionLen,pr.breakLen);
    if(targetMinutes>fit.maxMinutes+0.5){S.availability=extendAvToFit(S.availability,pr.sessionLen,pr.breakLen,targetMinutes);sanitizeTimes(S.sleep,S.availability,S.holiday);note=" | بازهٔ روزهای فعال کمی گسترش یافت تا این هدف جا شود"}
    pr.dailyGoal=targetMinutes;save();regenerateWeek();
    return{ok:true,message:`هدف روزانه: ${fa(h)} ساعت شد و برنامهٔ هفته بازسازی شد${note}`}},
  set_konkur_review({grade10,grade11,level}){S.prefs=S.prefs||{};const r=S.prefs.review={...reviewPrefs()};
    if(grade10!=null)r.g10=!!grade10;if(grade11!=null)r.g11=!!grade11;if(level!=null){if(!REVIEW_CAP[level])throw new Error("میزان مرور باید light، medium یا heavy باشد");r.level=level}
    regenerateWeek();return{ok:true,message:`مرور کنکور: ${[r.g10?"پایه دهم":null,r.g11&&S.profile.grade==="12"?"پایه یازدهم":null].filter(Boolean).join(" و ")||"خاموش"} | حداکثر ${fa(REVIEW_CAP[r.level])} جلسه در هفته`}},
  regenerate_week(){regenerateWeek(true);return{ok:true,message:"برنامهٔ ۷ روز آینده دوباره ساخته شد"}},
  replace_day_plan({date,sessions,note}){
    const iso=resolveDate(date);if(!iso)throw new Error("تاریخ نامعتبر است؛ از today، tomorrow یا تاریخ شمسی مثل 1405/07/05 استفاده کن");if(iso<todayIso())throw new Error("روزهای گذشته را نمی‌شود تغییر داد");
    if(!Array.isArray(sessions)||!sessions.length)throw new Error("فهرست جلسه‌ها خالی است");
    const p=planFor(iso);
    const keep=p.tasks.filter(t=>t.status==="done"||t.status==="skipped"||(t.status==="doing"&&S.timer&&S.timer.taskId===t.id));
    const blockers=keep.filter(t=>t.status!=="skipped").map(t=>({s:t.start,e:t.start+t.minutes}));
    const B=Number(S.profile.breakLen??10)||0;const sl=sleepFor(iso);const wake=toMin(sl.wake),limit=bedLimit(iso)+30;
    const floor=iso===todayIso()?Math.max(wake,Math.ceil((nowMin()+2)/5)*5):wake;
    const win=windowFor(iso);let cur=Math.max(floor,toMin(win.start||sl.wake));
    const out=[],notes=[];
    for(const x of sessions){const sub=subById(String(x&&x.subject_id));if(!sub)throw new Error("شناسهٔ درس نامعتبر است: "+(x&&x.subject_id));
      let m=Math.round(Number(x.minutes));if(!(m>=10&&m<=240))throw new Error("مدت هر جلسه باید بین ۱۰ دقیقه و ۴ ساعت باشد");
      let st=x.start&&/^\d{1,2}:\d{2}$/.test(String(x.start))?toMin(x.start):cur;
      if(st<floor){notes.push(`${sub.name} از ساعت ${faStr(hmA(floor))} شروع شد (ساعت ${faStr(hmA(st))} گذشته بود)`);st=floor}
      let moved=true;while(moved){moved=false;for(const b of blockers){if(st<b.e&&b.s<st+m){st=b.e+B;moved=true}}}
      if(st+m>limit){const fit=limit-st;if(fit>=20){notes.push(`${sub.name} به ${durLabel(fit)} کوتاه شد تا از ساعت خواب رد نشود`);m=fit}
        else{notes.push(`${sub.name} جا نشد چون از ساعت خواب (${faStr(sl.bed)}) رد می‌شد`);continue}}
      const bk=x.target==="konkur"?"konkur":"final";const auto=lessonFor(sub,bk,iso,out.filter(o=>o.bucket===bk));
      /* even when the AI gives its own exact lesson text (per rule 15), we still need a matching lessonIdx/lessonGrade
         so that marking this session done advances the subject's progress — otherwise the same part gets scheduled
         again next week. Start from the auto-computed pointer, then refine it if the given text names a different
         part of the book. */
      let lIdx=auto?auto.idx:null,lGrade=auto&&auto.grade!=null?auto.grade:null;
      if(x.lesson){const txt=String(x.lesson).slice(0,90);
        if(bk==="final"){const L=finalLessons(sub);const mi=L.indexOf(txt);if(mi!==-1)lIdx=mi}
        else{outer: for(let g=0;g<=curGi();g++){const Lg=bookLessons(sub.id,g);const nm=sub.names[g]||sub.name;
          const bare=txt.startsWith(nm+" | ")?txt.slice(nm.length+3):txt;const mi=Lg.indexOf(bare);
          if(mi!==-1){lIdx=mi;lGrade=g;break outer}}}}
      const fresh=!x.type&&freshStartType(bk,sub,auto);
      const t={id:uid(),start:st,minutes:m,status:"todo",subjectId:sub.id,lesson:x.lesson?String(x.lesson).slice(0,90):(auto?auto.label:null),lessonIdx:lIdx,lessonGrade:lGrade,bucket:x.target==="konkur"?"konkur":"final",type:String(x.type||fresh||taskType(bk,sub,iso,out.length)).slice(0,60),reasons:["به درخواست تو"+(note?": "+String(note).slice(0,120):"")],priority:"بالا"};
      out.push(t);blockers.push({s:st,e:st+m});cur=st+m+B;}
    if(!out.length)throw new Error("هیچ جلسه‌ای جا نشد؛ "+notes.join("، "));
    p.tasks=[...keep,...out].sort((a,b)=>a.start-b.start);p.custom=true;save();
    return{ok:true,message:`برنامهٔ ${dayName(iso)} با ${fa(out.length)} جلسهٔ جدید جایگزین شد`+(notes.length?` (${notes.join("، ")})`:""),new_plan:out.map(t=>({time:hmA(t.start),end:hmA(t.start+t.minutes),subject:subName(t.subjectId),lesson:t.lesson,minutes:t.minutes})),adjustments:notes}},
  set_day_time({date,start,end,off}){const iso=resolveDate(date);if(!iso)throw new Error("تاریخ نامعتبر است");if(iso<todayIso())throw new Error("روزهای گذشته را نمی‌شود تغییر داد");
    if(off){S.overrides[iso]={off:true}}else{if(!/^\d{1,2}:\d{2}$/.test(String(start))||!/^\d{1,2}:\d{2}$/.test(String(end)))throw new Error("ساعت شروع و پایان باید به شکل HH:MM باشد");if(toMin(end)-toMin(start)<20)throw new Error("پایان باید دست‌کم ۲۰ دقیقه بعد از شروع باشد");S.overrides[iso]={start:hmA(toMin(start)),end:hmA(toMin(end))}}
    if(iso===todayIso())regenerateKeepingDone(iso);else S.plans[iso]=generatePlan(iso);S.plans[iso].custom=true;save();
    const w=availabilityFor(iso);return{ok:true,message:off?`${dayName(iso)} روز استراحت شد`:`زمان ${dayName(iso)}: ${faStr(w.start)} تا ${faStr(w.end)} (${durLabel(w.minutes)}) و برنامه‌اش بازسازی شد`}},
  set_sleep_schedule({wake,bed,weekend_wake,weekend_bed}){const z=S.sleep=S.sleep||DEFAULT_SLEEP();const ok=v=>/^\d{1,2}:\d{2}$/.test(String(v));
    if(wake!=null){if(!ok(wake))throw new Error("ساعت بیداری باید به شکل HH:MM باشد");z.wake=hmA(toMin(wake))}if(bed!=null){if(!ok(bed))throw new Error("ساعت خواب باید به شکل HH:MM باشد");z.bed=hmA(toMin(bed))}
    if(weekend_wake!=null){if(!ok(weekend_wake))throw new Error("ساعت بیداری آخر هفته باید به شکل HH:MM باشد");z.wakeOff=hmA(toMin(weekend_wake))}if(weekend_bed!=null){if(!ok(weekend_bed))throw new Error("ساعت خواب آخر هفته باید به شکل HH:MM باشد");z.bedOff=hmA(toMin(weekend_bed))}
    regenerateWeek();return{ok:true,message:`ساعت خواب و بیداری ذخیره شد (روزهای مدرسه ${faStr(z.wake)}–${faStr(z.bed)}، تعطیل ${faStr(z.wakeOff)}–${faStr(z.bedOff)}) و برنامه بازسازی شد`}},
  restore_auto_plan({date}){const iso=resolveDate(date);if(!iso)throw new Error("تاریخ نامعتبر است");delete S.overrides[iso];const p=S.plans[iso];if(p){p.custom=false;p.change=null}
    if(iso===todayIso())regenerateKeepingDone(iso);else S.plans[iso]=generatePlan(iso);S.plans[iso].change=null;save();return{ok:true,message:`${dayName(iso)} به برنامهٔ خودکار Evono برگشت`}},
  skip_task({task_id}){const ok=setTaskStatus(todayIso(),String(task_id),"skipped");if(!ok)throw new Error("این جلسه پیدا نشد");return{ok:true,message:"جلسه رد شد و به کار عقب‌افتاده اضافه شد (در روزهای بعد پخش می‌شود، نه یک‌جا)"}},
  complete_task({task_id,actual_minutes}){const ok=setTaskStatus(todayIso(),String(task_id),"done",actual_minutes?Number(actual_minutes):undefined);if(!ok)throw new Error("این جلسه پیدا نشد");return{ok:true,message:"جلسه انجام‌شده ثبت شد"}},
  add_exam({title,subject_id,date,kind}){const iso=parseJ(date)||(/^\d{4}-\d{2}-\d{2}$/.test(String(date))?String(date):null);if(!iso)throw new Error("تاریخ باید شمسی و به شکل 1405/08/15 باشد");
    const k=["school","mock","other"].includes(kind)?kind:"school";if(subject_id&&!subById(String(subject_id)))throw new Error("درس نامعتبر است");
    S.exams.push({id:uid(),kind:k,subjectId:subject_id?String(subject_id):null,title:String(title||"آزمون").slice(0,80),date:iso,estimated:false});
    const d=todayIso();if(daysUntil(iso)<=3)regenerateKeepingDone(d);save();return{ok:true,message:`${String(title)} در ${jLabel(iso)} ثبت شد${daysUntil(iso)<=3?" و برنامهٔ امروز بازسازی شد":""}`}},
  add_session_today({subject_id,minutes,bucket}){const s=subById(String(subject_id));if(!s)throw new Error("درس نامعتبر است");
    if(s.off)throw new Error(`${subName(s.id)} از برنامه‌ریزی حذف شده؛ اول باید از تنظیمات کامل برش‌گردانی، بعد بشود برایش جلسه اضافه کرد`);
    const m=Math.max(15,Math.min(180,Math.round(Number(minutes)||45)));
    const d=todayIso();(S.pinned[d]=S.pinned[d]||[]).push({subjectId:s.id,bucket:bucket==="konkur"?"konkur":"final",minutes:m,type:bucket==="konkur"?"تست‌زنی":"مطالعهٔ کتاب درسی",reasons:["به درخواست شما در گفت‌وگو با EvonoAI اضافه شد"],priority:"بالا"});
    regenerateKeepingDone(d);return{ok:true,message:`جلسهٔ ${durLabel(m)} ${subName(s.id)} در ابتدای برنامهٔ امروز قرار گرفت (کل زمان امروز تغییر نکرد)`}},
  record_result({subject_id,kind,score}){const s=subById(String(subject_id));if(!s)throw new Error("درس نامعتبر است");const k=kind==="mock"?"mock":kind==="official"?"official":"practice";const v=Number(score);
    if(k==="mock"?!(v>=-33&&v<=100):!(v>=0&&v<=20))throw new Error("نمره خارج از محدوده است");S.results.push({id:uid(),subjectId:s.id,kind:k,score:v,date:todayIso()});save();return{ok:true,message:`نتیجه ثبت شد: ${subName(s.id)} ${fa(v)}${k==="mock"?"٪":" از ۲۰"}`}},
  set_subject_level({subject_id,level}){const s=subById(String(subject_id));if(!s)throw new Error("درس نامعتبر است");const l=Math.max(1,Math.min(5,Math.round(Number(level))));s.level=l;save();return{ok:true,message:`سطح ${s.name} روی ${fa(l)} از ۵ تنظیم شد (از برنامه‌های بعدی اثر می‌گذارد)`}},
  regenerate_today(){regenerateKeepingDone(todayIso());return{ok:true,message:"برنامهٔ امروز با آخرین داده‌ها دوباره ساخته شد"}},
  /* Lets EvonoAI change anything the برنامهٔ امتحانی setup wizard collects, later, in chat — all fields
     optional, only the given ones change. Mirrors set_preferences' "partial patch" shape. */
  set_exam_prep_plan(a){
    const fk=currentFinalKind();if(!fk)throw new Error("این دانش‌آموز پایهٔ یازدهم یا دوازدهم نیست، برنامهٔ امتحانی ندارد");
    const EP=examPrepState();const eligible=examPrepEligibleSubjects();const ch=[];
    if(a.school!=null){EP.school=!!a.school;ch.push(EP.school?"در این بازه مدرسه هم می‌رود":"در این بازه مدرسه نمی‌رود")}
    if(a.study_hours!=null){const h=Number(a.study_hours);if(!(h>0&&h<=16))throw new Error("ساعت مطالعهٔ روزانهٔ برنامهٔ امتحانی باید بین ۰ تا ۱۶ ساعت باشد");EP.studyMinutes=Math.round(h*60);ch.push(`روزی ${fa(h)} ساعت`)}
    if(a.session_len!=null){const v=Math.round(+a.session_len);if(!(v>=15&&v<=150))throw new Error("طول جلسه باید بین ۱۵ دقیقه و ۲ ساعت و ۳۰ دقیقه باشد");EP.sessionLen=v;ch.push(`جلسه‌های ${fa(v)} دقیقه‌ای`)}
    if(a.break_len!=null){const v=Math.round(+a.break_len);if(!(v>=0&&v<=45))throw new Error("استراحت باید بین ۰ تا ۴۵ دقیقه باشد");EP.breakLen=v;ch.push(`استراحت ${fa(v)} دقیقه`)}
    if(a.sleep&&typeof a.sleep==="object"){const ok=v=>/^\d{1,2}:\d{2}$/.test(String(v));EP.sleep=EP.sleep||{wake:S.sleep.wake,bed:S.sleep.bed};
      if(a.sleep.wake!=null){if(!ok(a.sleep.wake))throw new Error("ساعت بیداری باید HH:MM باشد");EP.sleep.wake=hmA(toMin(a.sleep.wake))}
      if(a.sleep.bed!=null){if(!ok(a.sleep.bed))throw new Error("ساعت خواب باید HH:MM باشد");EP.sleep.bed=hmA(toMin(a.sleep.bed))}
      ch.push("ساعت خواب برنامهٔ امتحانی")}
    if(Array.isArray(a.subject_ids)){const ids=eligible.map(s=>s.id);const picked=a.subject_ids.map(String).filter(id=>ids.includes(id));
      if(!picked.length)throw new Error("دست‌کم یک درس باید در برنامهٔ امتحانی بماند");EP.subjectIds=picked;ch.push("درس‌های برنامهٔ امتحانی: "+picked.map(subName).join("، "))}
    if(Array.isArray(a.exam_times)){EP.examTimes=EP.examTimes||{};let n=0;a.exam_times.forEach(x=>{const s=subById(String(x&&x.subject_id));if(!s||!eligible.some(e=>e.id===s.id))return;if(!/^\d{1,2}:\d{2}$/.test(String(x&&x.time)))return;EP.examTimes[s.id]=hmA(toMin(x.time));n++});if(n)ch.push("ساعت دقیق امتحان‌ها")}
    if(!ch.length)throw new Error("هیچ فیلدی برای تغییر داده نشد");
    EP.setupDone=true;save();
    return{ok:true,message:"برنامهٔ امتحانی به‌روز شد | "+ch.join("، ")};
  }
};

/* ================= Rendering ================= */
const $=s=>document.querySelector(s);
/* A gentler, slower alternative to window.scrollTo({behavior:"smooth"}) — the native smooth scroll has a
   short, fixed duration we can't tune, which felt too abrupt for the week-tab landing scroll. This eases
   over an explicit duration instead. */
function easeScrollTo(targetY,duration){
  const startY=window.scrollY,diff=targetY-startY;
  if(Math.abs(diff)<1)return;
  const t0=performance.now();
  const ease=t=>t<0.5?4*t*t*t:1-Math.pow(-2*t+2,3)/2;
  function step(now){
    const t=Math.min(1,(now-t0)/duration);
    window.scrollTo(0,startY+diff*ease(t));
    if(t<1)requestAnimationFrame(step);
  }
  requestAnimationFrame(step);
}
let INDPOS=null;
function placeInd(){const nav=document.querySelector("nav.tabs");if(!nav)return;const sel=nav.querySelector("[aria-selected=true]");const ind=nav.querySelector(".ind");if(!sel||!ind)return;
  const nr=nav.getBoundingClientRect(),br=sel.getBoundingClientRect();const target={w:br.width,x:nr.right-br.right-nav.clientLeft-nav.scrollLeft};
  if(INDPOS){ind.style.transition="none";ind.style.width=INDPOS.w+"px";ind.style.insetInlineStart=INDPOS.x+"px";void ind.offsetWidth;ind.style.transition=""}
  requestAnimationFrame(()=>{ind.style.width=target.w+"px";ind.style.insetInlineStart=target.x+"px"});INDPOS=target;}
window.addEventListener("resize",()=>placeInd());
function toast(msg){const t=$("#toast");t.textContent=msg;t.hidden=false;t.style.animation="none";void t.offsetWidth;t.style.animation="";clearTimeout(toast._t);toast._t=setTimeout(()=>t.hidden=true,2600)}
/* Rebuilds everything inside <header class="top"> EXCEPT the .brand block (logo + wordmark + greeting),
   which is left completely untouched. Rebuilding the whole header on every render (as this app used to
   do everywhere) destroys and recreates the logo <img> each time — even though its src is almost always
   unchanged — and that node-recreation is exactly what produced the flicker when switching tabs. The
   logo/greeting's own two dynamic bits (id="brand-logo" src, id="brand-greet" text) are still kept live,
   just via a direct attribute/textContent write instead of tearing the element down. */
function patchHeader(headerEl){
  const tmp=document.createElement("div");tmp.innerHTML=renderTop();
  const freshHeader=tmp.firstElementChild;
  const curLogo=headerEl.querySelector("#brand-logo"),newLogo=freshHeader.querySelector("#brand-logo");
  if(curLogo&&newLogo&&curLogo.getAttribute("src")!==newLogo.getAttribute("src"))curLogo.setAttribute("src",newLogo.getAttribute("src"));
  const curGreet=headerEl.querySelector("#brand-greet"),newGreet=freshHeader.querySelector("#brand-greet");
  if(curGreet&&newGreet&&curGreet.textContent!==newGreet.textContent)curGreet.textContent=newGreet.textContent;
  const curBrand=headerEl.querySelector(".brand");
  Array.from(headerEl.children).forEach(ch=>{if(ch!==curBrand)ch.remove()});
  Array.from(freshHeader.children).forEach(ch=>{if(!(ch.classList&&ch.classList.contains("brand")))headerEl.appendChild(ch)});
}
function navInnerHTML(tabs){return `<span class="ind" aria-hidden="true"></span>${tabs.map(([k,l])=>`<button role="tab" data-tab="${k}" aria-selected="${TAB===k}">${k==="ai"?'<span class="ai-mark">Evono<i>AI</i></span>':l}</button>`).join("")}`}
/** Locks the phone-login / phone-verify screen to the real screen with zero scroll or rubber-band —
 *  including on iOS Safari, which can reveal a flash of blank/native-gray canvas above a merely
 *  position:fixed child during its elastic overscroll bounce if the page (html/body) underneath it
 *  can still "move." Pinning html+body themselves (not just #app) removes that bounce entirely,
 *  and doing it here in JS (rather than only a CSS :has() rule) also works on older iPad/iOS Safari
 *  versions that don't support :has(). */
function setCenterScreen(on){
  $("#app").classList.toggle("center-screen",on);
  document.documentElement.classList.toggle("no-scroll",on);
  document.body.classList.toggle("no-scroll",on);
}
function render(){
  applyTheme();
  const enteringTab=ANIM; // true only on the render that switches into this tab, not on every later re-render of it
  if(TAB!=="profile")TX_EXPANDED=false; // leaving the profile tab always collapses the transaction list back down
  const app=$("#app");
  if(LOGGED_OUT){setCenterScreen(true);app.innerHTML=renderPhone();bindPhone();return}
  if(!S.onboarded){setCenterScreen(!OB.phoneOk);app.innerHTML=renderOnboarding();if(!OB.phoneOk)bindPhone();bindOnboarding();return}
  setCenterScreen(false);
  if(!S.tickets)S.tickets=[];
  processPastDays();
  const tabs=[["today","امروز"],["week","برنامهٔ هفته"],...(examPrepActive()?[["examprep","برنامهٔ امتحانی"]]:[]),["ai","EvonoAI"],["journey","مسیر امتحان‌ها"],["report","گزارش روزانه"],["results","نتایج و آزمون‌ها"],["review","مرور هفتگی"],["plans","اشتراک"],["profile","پروفایل"],["tickets","تیکت‌ها"]];
  if(!tabs.some(t=>t[0]===TAB))TAB="today";
  const viewHTML=({today:renderToday,week:renderWeek,plans:renderPlans,journey:renderJourney,ai:renderAI,report:renderReport,results:renderResults,review:renderReview,profile:renderProfile,tickets:renderTickets,examprep:renderExamPrep})[TAB]();
  const existingChrome=app.querySelector(".chrome"),existingHeader=existingChrome&&existingChrome.querySelector("header.top"),existingView=app.querySelector("#view");
  if(existingChrome&&existingHeader&&existingView){
    patchHeader(existingHeader);
    const navEl=existingChrome.querySelector("nav.tabs");if(navEl)navEl.innerHTML=navInnerHTML(tabs);
    existingView.className=ANIM?"enter":"";
    existingView.innerHTML=viewHTML;
  }else{
    app.innerHTML=`<div class="chrome">${renderTop()}
    <nav class="tabs" role="tablist">${navInnerHTML(tabs)}</nav></div>
    <main id="view" class="${ANIM?"enter":""}">${viewHTML}</main>`;
  }
  app.querySelectorAll("[data-tab]").forEach(b=>b.onclick=()=>{if(TAB===b.dataset.tab)return;const goingToWeek=b.dataset.tab==="week";TAB=b.dataset.tab;ANIM=true;render();if(!goingToWeek)window.scrollTo({top:0,behavior:"smooth"})});
  app.querySelectorAll("[data-timer]").forEach(b=>b.onclick=()=>{if(b.dataset.timer==="pause")pauseTimer();else stopTimer()});
  requestAnimationFrame(()=>document.querySelectorAll(".jtrack i[data-pct]").forEach(el=>{el.style.width=el.dataset.pct+"%"}));
  placeInd();if(ANIM)app.querySelectorAll("#view .card,#view .next,#view .alert,#view .task").forEach((el,i)=>el.style.animationDelay=Math.min(i*50,600)+"ms");ANIM=false;
  bindView();
  if(TAB==="week"&&enteringTab&&WEEK_OFF===0){
    // Center today's card in the week strip so the student sees this day's plan first, without having
    // to scroll the strip themselves — but do that horizontal centering on its own, undoing any vertical
    // scroll it drags along with it, then let the page ease down to just past the start of the "مرور
    // برای کنکور" section's heading (just below the sticky header, plus a bit more so the heading isn't
    // pinned right at the top edge), not all the way to the section's bottom or the grid itself.
    const todayCard=app.querySelector(".week .day.today");
    if(todayCard){
      const y0=window.scrollY;
      todayCard.scrollIntoView({inline:"center",block:"nearest"});
      window.scrollTo(0,y0);
    }
    const reviewEl=$("#view .review");
    const chromeH=(app.querySelector(".chrome")||{}).offsetHeight||0;
    const capY=reviewEl?Math.max(0,reviewEl.getBoundingClientRect().top+window.scrollY-chromeH+130):0;
    easeScrollTo(capY,1100);
  }
  if(TAB==="week"&&!S.seenWeekDragHint){S.seenWeekDragHint=true;save();
    showModal(`<div class="modal-icon">↕</div><h2>جابه‌جایی جلسه‌های هر روز</h2><p class="muted">هر جلسهٔ نخوانده را می‌توانی نگه‌داری و بکشی تا ترتیب خواندنش در همان روز عوض شود؛ توی «امروز» هم با گرفتن دستگیرهٔ کنار دکمه‌ها همین کار را می‌کنی.</p><div class="row" style="justify-content:center;margin-top:18px"><button class="btn primary" data-m="close">متوجه شدم</button></div>`);
  }
  // First time the برنامهٔ امتحانی tab is opened (and every time after, until the wizard is actually
  // completed), ask the required setup questions before showing a schedule built on guesses.
  if(TAB==="examprep"&&enteringTab&&!examPrepSetupDone())openExamPrepWizard();
}
function renderTop(){
  const main=upcoming(["final11","final12","konkur"]);
  const nextF=main.find(e=>e.kind!=="konkur");const kx=main.find(e=>e.kind==="konkur");
  const chip=(label,e)=>e?`<span class="cd ${daysUntil(e.date)<=30?"hot":""}"><span>${label}</span><strong class="num">${fa(daysUntil(e.date))}</strong><span>روز</span></span>`:"";
  return `<header class="top"><div class="brand"><img class="brand-mark" id="brand-logo" src="${logoSrc()}" alt="Evono" aria-hidden="true" draggable="false"><b>Evono</b><span id="brand-greet">سلام ${esc(S.profile.name||"")}</span></div>
  <div class="chips">${chip(nextF?(nextF.kind==="final12"?"نهایی دوازدهم":"نهایی یازدهم"):"",nextF)}${chip("کنکور "+faStr(S.profile.konkurYear),kx)}</div>
  ${subActive()?`<span class="active-sub"><span class="dot" aria-hidden="true"></span><b>اشتراک فعال</b>${aiQuota()?`<i class="dv" aria-hidden="true"></i><span class="num">${fa(aiLeft())}</span> پیام`:""}</span>${aiQuota()&&aiLeft()===0?'<button class="btn primary sm" data-tab="plans">ارتقا</button>':""}`:`<span class="trial"><span class="tr-txt">${subLapsed()?"اشتراک تمام شد":`<span class="ai-mark">Evono<i>AI</i></span> نیاز به اشتراک دارد`}</span><button class="btn primary" data-tab="plans">${subLapsed()?"تمدید اشتراک":"خرید اشتراک"}</button></span>`}
  ${renderTimerBar()}
  <span class="store" title="محل ذخیره‌سازی داده‌ها">${STORE==="account"?"ذخیره در حساب شما":STORE==="local"?"ذخیره در همین مرورگر":"ذخیره نمی‌شود"}</span></header>`;
}
function renderChange(d,p){if(!p||!p.change)return "";const c=p.change;const at=new Date(c.at);
  return `<section class="card change"><div class="card-h"><div><span class="label">تغییر برنامه به درخواست تو | ساعت ${faStr(hmA(at.getHours()*60+at.getMinutes()))}</span><h2 style="margin-top:4px">برنامهٔ قبلی ${dayName(d)} لغو شد و برنامهٔ جدید جایگزین شد</h2></div>
    <div class="row">${c.cancelled.length?`<button class="btn sm" data-restore="${d}">بازگرداندن برنامهٔ قبلی</button>`:""}</div></div>
    ${c.note?`<div class="req">«${esc(c.note)}»</div>`:""}
    ${c.cancelled.length?`<details class="cancelled"><summary>برنامهٔ قبلی (لغو شده) | ${fa(c.cancelled.length)} جلسه</summary>${c.cancelled.map(t=>`<div class="old"><span>${esc(taskSubName(t))} | ${esc(t.lesson||t.type||"")}</span><span class="num">${hm(t.start)} | ${durLabel(t.minutes)}</span></div>`).join("")}</details>`:""}
  </section>`}
function studyTips(){
  if(S.dismissed&&S.dismissed.tips)return "";
  const tips=[];const L=+S.profile.sessionLen||60;
  if(L<60)tips.push({t:`جلسه‌های تو ${durLabel(L)} است. پیشنهاد Evono: هر جلسه دست‌کم ۱ ساعت باشد تا عمیق‌تر یاد بگیری.`,act:`<button class="btn sm primary" data-tip="len60">جلسه‌ها را ۱ ساعته کن</button>`});
  const ds=weekDates();const mins=ds.map(d=>{const p=S.plans[d];return p?p.tasks.reduce((a,t)=>a+t.minutes,0):0});const days=mins.filter(m=>m>0);
  const avg=days.length?days.reduce((a,b)=>a+b,0)/days.length:0;
  if(avg<300)tips.push({t:`میانگین برنامهٔ روزانه‌ات ${durLabel(Math.round(avg))} است. اگر می‌خواهی جدی بخوانی، هدف روزی ۶ ساعت یا بیشتر است؛ مخصوصاً پنجشنبه و جمعه.`,act:`<button class="btn sm" data-act="opensettings">تنظیم زمان درس</button><button class="btn sm ghost" data-tip="ask6">کمکم کن ۶ ساعت بخوانم</button>`});
  if(!tips.length)return "";
  return `<section class="card tips"><div class="card-h"><h2>پیشنهاد <span class="ai-mark">Evono</span></h2><div class="row" style="align-items:center;gap:8px"><span class="small muted">برای آمادگی جدی</span><button type="button" class="x-close" data-act="dismiss" data-id="tips" aria-label="بستن" title="بستن">×</button></div></div>
    <div class="stack" style="gap:10px">${tips.map(x=>`<div class="tip"><p>${x.t}</p><div class="row">${x.act}</div></div>`).join("")}</div></section>`;
}
function reviewCard(compact){
  const g=S.profile.grade;if(!(g==="11"||g==="12"))return "";const r=reviewPrefs();const pe=pastGrades();
  const wk=weekDates().map(d=>S.plans[d]).filter(Boolean).flatMap(p=>p.tasks).filter(t=>t.bucket==="konkur");
  const c10=wk.filter(t=>t.lessonGrade===0).length,c11=wk.filter(t=>t.lessonGrade===1).length;
  const on=pe.length>0;
  if(compact)return `<section class="card review ${on?"":"off"}"><div class="rv-head"><span class="rv-ico">${on?"✓":"!"}</span><div><b>${on?"مرور پایه‌های قبل برای کنکور روشن است":"مرور پایه دهم و یازدهم برای کنکور خاموش است"}</b><p class="small muted">${on?`این هفته ${fa(c10)} جلسهٔ مرور دهم${g==="12"?` و ${fa(c11)} جلسهٔ مرور یازدهم`:""} در برنامه‌ات است.`:"کنکور از هر سه پایه است؛ روشنش کن تا کتاب‌های پایه‌های قبل هم در برنامه بیایند."}</p></div><button class="btn sm ${on?"":"primary"}" data-goto="week">${on?"تنظیم":"روشن کن"}</button></div></section>`;
  return `<section class="card review ${on?"":"off"}">
    <div class="card-h"><div><span class="label">مرور برای کنکور</span><h2 style="margin-top:4px">کنکور از هر سه پایه است: دهم، یازدهم و دوازدهم</h2>
      <p class="small muted" style="margin-top:4px">${g==="12"?"کتاب‌های پایه دهم و یازدهم را هم به جلسه‌های کنکورت اضافه کن.":"کتاب‌های پایه دهم را هم به جلسه‌های کنکورت اضافه کن."} Evono جلسه‌های کنکور را فصل‌به‌فصل بین این کتاب‌ها می‌چرخاند.</p></div>
      ${on?`<span class="badge">روشن</span>`:`<span class="badge ghost">خاموش</span>`}</div>
    <div class="rv-grid">
      <label class="rv"><input type="checkbox" data-rv="g10" ${r.g10?"checked":""}><span><b>پایه دهم</b><small>${esc(S.subjects.filter(x=>x.kw>0&&x.names[0]).map(x=>x.names[0]).slice(0,4).join("، "))}</small></span></label>
      ${g==="12"?`<label class="rv"><input type="checkbox" data-rv="g11" ${r.g11?"checked":""}><span><b>پایه یازدهم</b><small>${esc(S.subjects.filter(x=>x.kw>0&&x.names[1]).map(x=>x.names[1]).slice(0,4).join("، "))}</small></span></label>`:""}
    </div>
    <div class="row" style="margin-top:12px;justify-content:space-between"><span class="small">سقف جلسه‌های مرور در هفته:</span>
      <div class="seg">${[["light","کم | حداکثر ۲"],["medium","متوسط | حداکثر ۳"],["heavy","زیاد | حداکثر ۴"]].map(([k,l])=>`<label><input type="radio" name="rvlvl" value="${k}" ${r.level===k?"checked":""}><span>${l}</span></label>`).join("")}</div></div>
    ${on?`<p class="small muted" style="margin-top:10px">این هفته: ${fa(c10)} جلسهٔ مرور دهم${g==="12"?` | ${fa(c11)} جلسهٔ مرور یازدهم`:""}</p>`:""}
  </section>`}
function pillFor(b){return b==="final"?(S.profile.grade==="10"?'<span class="pill p-school">مدرسه</span>':`<span class="pill p-final">نهایی ${S.profile.grade==="12"||S.profile.grade==="grad"?"۱۲":"۱۱"}</span>`):'<span class="pill p-konkur">کنکور</span>'}
function renderToday(){
  const d=todayIso();const p=planFor(d);const ph=phase();
  const todo=p.tasks.filter(t=>t.status==="todo"||t.status==="doing");const next=todo[0];
  const doneMin=p.tasks.filter(t=>t.status==="done").reduce((a,t)=>a+(t.actual||t.minutes),0);
  const planMin=p.tasks.reduce((a,t)=>a+t.minutes,0);
  const nowM=new Date().getHours()*60+new Date().getMinutes();
  const missingScores=(S.profile.grade==="12"||S.profile.grade==="grad")?S.subjects.filter(s=>s.names[1]&&S.finalScores[s.id]==null&&!(S.finalExcluded&&S.finalExcluded[s.id])):[];
  return `<div class="grid g-main">
  <div class="stack">
    ${next?`<section class="next" aria-label="کار بعدی"><div class="stack" style="gap:4px"><span class="label">بعدی | ${hm(next.start)}</span>
      <h1>${esc(taskSubName(next))}</h1>${next.lesson?`<p class="meta" style="color:var(--ink);font-weight:600">${esc(next.lesson)}</p>`:""}<p class="meta">${esc(next.type)} | ${durLabel(next.minutes)} | ${next.bucket==="final"?(S.profile.grade==="10"?"مدرسه":"آمادگی امتحان نهایی"):"آمادگی کنکور"}</p></div>
      <button class="btn primary" data-act="start" data-id="${next.id}">${next.status==="doing"?"پایان جلسه ✓":"شروع جلسه ←"}</button></section>`
      :`<section class="next"><div><span class="label">امروز</span><h1>${p.tasks.length?"همهٔ جلسه‌های امروز بسته شد":"امروز جلسه‌ای برنامه‌ریزی نشده"}</h1><p class="meta">${p.tasks.length?"گزارش روزانه را ثبت کنید تا برنامهٔ فردا دقیق‌تر شود.":"زمان در دسترس امروز صفر است. از <b class='brand-word'>EvonoAI</b> یا تنظیمات زمان اضافه کنید."}</p></div>
      <button class="btn primary" data-goto="report">گزارش روزانه</button></section>`}
    ${missingScores.length?`<div class="alert"><b>نمرهٔ نهایی پایه یازدهم ثبت نشده:</b> ${missingScores.map(s=>esc(s.names[1])).join("، ")}. اگر درسی که در سوابق اثر دارد نمرهٔ نهایی نداشته باشد، صفر حساب می‌شود. نمره‌ها را در «نتایج و آزمون‌ها» وارد کنید.</div>`:""}
    ${seasonBanner(d)}
    ${reviewCard(true)}
    ${renderChange(d,p)}
    ${studyTips()}
    <section class="card"><div class="card-h"><div><h2>${p.change?"برنامهٔ جدید امروز":"برنامهٔ امروز"}</h2><p class="small muted">${jLabel(d)} | ${WD[wdIdx(todayD())]} | ${durLabel(p.minutes)} زمان در دسترس</p></div>
      <div class="row">${p.custom?`<button class="btn sm ghost" data-auto="${d}">برنامهٔ خودکار</button>`:""}<button class="btn sm" data-act="regen">بازسازی</button></div></div>
      <div class="sleepmark">☀ بیداری <b class="num">${faStr(sleepFor(d).wake)}</b></div>
      <div class="tl">${(()=>{const todoIdxs=p.tasks.map((x,ix)=>x.status==="todo"?ix:-1).filter(ix=>ix!==-1);return p.tasks.length?p.tasks.map((t,i)=>{const late=t.status==="todo"&&t.start+t.minutes<nowM;
        const pos=todoIdxs.indexOf(i);return `
        ${i?`<div class="brk">استراحت ${durLabel(S.profile.breakLen)}</div>`:""}
        <div class="task ${t.status==="done"?"done":""} ${t.status==="skipped"||t.status==="missed"?"skipped":""}"${pos!==-1?` data-drag-id="${t.id}" data-drag-date="${d}"`:""}>
          <div class="t num">${hm(t.start)}<small>${durLabel(t.minutes)}</small></div>
          <div class="body"><h3>${esc(taskSubName(t))} ${t.fromChange?'<span class="pill newtag">جدید</span>':""} ${pillFor(t.bucket)} ${t.priority==="بالا"?'<span class="pill p-warn">اولویت بالا</span>':""} ${t.status==="done"?'<span class="pill p-good">انجام شد</span>':t.status==="skipped"?'<span class="pill p-school">رد شد</span>':t.status==="doing"?'<span class="pill p-good">در حال انجام</span>':late?'<span class="pill p-crit">عقب افتاده</span>':""}</h3>
            ${t.lesson?`<p class="lesson">${esc(t.lesson)}</p>`:""}<p class="sub">${esc(t.type)}</p>
            ${OPEN_WHY===t.id?`<div class="why"><b>چرا این جلسه؟</b><ul>${(t.reasons||[]).map(r=>`<li>${esc(r)}</li>`).join("")}<li>فاز فعلی: ${esc(p.phase)} (${fa(Math.round(p.split*100))}٪ ${S.profile.grade==="10"?"مدرسه":"نهایی"} / ${fa(100-Math.round(p.split*100))}٪ کنکور)</li></ul></div>`:""}
          </div>
          <div class="acts">${pos!==-1?`<span class="t-grip grip" aria-hidden="true"></span>`:""}${t.status==="todo"||t.status==="doing"?`<button class="btn sm" data-act="done" data-id="${t.id}">انجام شد</button><button class="btn sm ghost" data-act="skip" data-id="${t.id}">رد کردن</button>`:""}<button class="btn sm ghost" data-act="why" data-id="${t.id}" aria-expanded="${OPEN_WHY===t.id}">چرا؟</button></div>
        </div>`}).join(""):`<p class="muted">برای امروز جلسه‌ای ساخته نشد.</p>`})()}</div>
      <div class="sleepmark">☾ خواب <b class="num">${faStr(sleepFor(d).bed)}</b></div>
    </section>
  </div>
  <div class="stack">
    <section class="card"><div class="card-h"><h2>وضعیت امروز</h2><span class="pill p-final">${esc(ph.label)}</span></div>
      <div class="stats"><div class="stat"><span class="label">انجام‌شده</span><b class="num">${durLabel(doneMin)}</b><span class="small muted">از ${durLabel(planMin)}</span></div>
      <div class="stat"><span class="label">کار عقب‌افتاده</span><b class="num">${durLabel(Object.values(S.backlog).reduce((a,b)=>a+b,0))}</b><span class="small muted">پخش در روزهای بعد</span></div></div>
      <div style="margin-top:12px"><div class="split" role="img" aria-label="تقسیم زمان"><i style="width:${Math.round(ph.finals*100)}%;background:var(--accent)"></i><i style="flex:1;background:var(--saffron)"></i></div>
      <div class="legend" style="margin-top:6px"><span><i style="background:var(--accent)"></i>${S.profile.grade==="10"?"مدرسه":"نهایی"} ${fa(Math.round(ph.finals*100))}٪</span><span><i style="background:var(--saffron)"></i>کنکور ${fa(100-Math.round(ph.finals*100))}٪</span></div>
      <p class="small muted" style="margin-top:6px">${esc(ph.why)}</p></div>
    </section>
    <section class="card"><div class="card-h"><h2>پیش رو</h2><button class="btn sm ghost" data-goto="results">همه</button></div>
      ${upcoming().slice(0,5).map(e=>`<div class="row" style="justify-content:space-between;padding:6px 0;border-top:1px solid var(--line)"><div><b style="font-size:.9rem">${esc(e.title)}</b><div class="small muted">${jLabel(e.date)}${e.estimated?" | تخمینی":""}</div></div><span class="pill ${e.kind==="konkur"?"p-konkur":e.kind.startsWith("final")?"p-final":"p-school"} num">${fa(daysUntil(e.date))} روز</span></div>`).join("")||'<p class="muted small">امتحانی ثبت نشده.</p>'}
    </section>
    <section class="card"><div class="card-h"><h2><span class="ai-mark">Evono<i>AI</i></span></h2></div>
      <p class="small muted">بگویید چه شده؛ برنامه را واقعاً تغییر می‌دهد.</p>
      <div class="quick" style="margin-top:10px">${QUICK.slice(0,4).map(q=>`<button data-quick="${esc(q)}">${esc(q)}</button>`).join("")}</div>
    </section>
  </div></div>`;
}
const QUICK=["امروز فقط ۲ ساعت وقت دارم","فردا امتحان شیمی مدرسه دارم","دیروز اصلاً درس نخواندم","چرا این برنامه را به من دادی؟","احساس می‌کنم عقب افتاده‌ام","تست‌های فیزیک را زودتر تمام کردم"];

function journeyPts(){const K=S.profile.konkurYear;const f=k=>S.exams.filter(e=>e.kind===k).map(e=>dFromIso(e.date));
  const f11=f("final11"),f12=f("final12");const kx=S.exams.find(e=>e.kind==="konkur");
  return[j2d(K-3,7,1),f11.length?Math.min(...f11):j2d(K-1,3,1),f12.length?Math.min(...f12):j2d(K,3,1),kx?dFromIso(kx.date):j2d(K,4,25)]}
function journeyPct(){const p=journeyPts();const t=todayD();if(t<=p[0])return 0;for(let i=0;i<3;i++){if(t<p[i+1])return 25*(i+(t-p[i])/(p[i+1]-p[i]))}return 75}
function renderJourney(){
  const g=S.profile.grade,K=S.profile.konkurYear,rs=ruleSet(K);
  const steps=[["پایه دهم","پایه‌سازی"],["نهایی یازدهم","خرداد "+faStr(K-1)],["نهایی دوازدهم","خرداد "+faStr(K)+" (و نوبت دی در صورت اعلام)"],["کنکور "+faStr(K),"آزمون تستی"]];
  const at=g==="10"?0:g==="11"?1:g==="12"?2:3;
  const fk=currentFinalKind();
  const counting=S.subjects.filter(s=>countsInFinals(s));
  const readiness=(kind)=>{const subs=kind==="konkur"?S.subjects.filter(s=>s.kw>0):counting;if(!subs.length)return null;
    const avg=subs.reduce((a,s)=>a+(s.level||3),0)/subs.length;const res=S.results.filter(r=>r.kind===(kind==="konkur"?"mock":"practice"));
    return{avg,n:subs.length,res:res.length,last:res.slice(-1)[0]}};
  const rF=readiness("final"),rK=readiness("konkur");
  return `<div class="stack">
  <section class="card"><div class="card-h"><div><h2>مسیر شما تا کنکور ${faStr(K)}</h2><p class="small muted">${esc(CATALOG[S.profile.field].label)} | ${g==="grad"?"دانش‌آموخته":"پایه "+({"10":"دهم","11":"یازدهم","12":"دوازدهم"})[g]}</p></div></div>
    ${(()=>{const pct=journeyPct();const reached=i=>pct>=i*25-0.01;const nowI=[0,1,2,3].find(i=>!reached(i));const cur=nowI==null?3:nowI;
      return `<div class="journey tracked"><div class="jtrack" aria-hidden="true"><i data-pct="${pct.toFixed(2)}"></i></div>${steps.map((s,i)=>`<div class="jstep ${i<cur||(nowI==null)?"past":i===cur?"now":""}"><span class="dot"></span><b>${esc(s[0])}</b><span>${esc(s[1])}</span></div>`).join("")}</div>
      <p class="small muted" style="margin-top:12px">${nowI==null?"کنکور برگزار شده است.":`تا ${esc(steps[cur][0])}: ${fa(Math.max(0,Math.ceil((journeyPts()[cur]-todayD()))))} روز`}</p>`})()}
  </section>
  <div class="grid" style="grid-template-columns:repeat(auto-fit,minmax(260px,1fr))">
    ${[["final11","امتحان نهایی یازدهم"],["final12","امتحان نهایی دوازدهم"],["konkur","کنکور"]].map(([k,l])=>{const ex=upcoming([k]);const first=ex[0];
      const done=(k==="final11"&&(g==="12"||g==="grad"))||(k==="final12"&&g==="grad");
      return `<section class="card"><div class="card-h"><h3>${l}</h3>${done?'<span class="pill p-good">برگزار شده</span>':first?`<span class="pill ${k==="konkur"?"p-konkur":"p-final"} num">${fa(daysUntil(first.date))} روز</span>`:'<span class="pill p-school">—</span>'}</div>
      ${done?(k==="final11"?`<p class="small">نمره‌های ثبت‌شده: ${fa(finalScoreCount())} درس. ${finalScoreCount()?"معدل "+fa2(avgScores()):""}</p>`:'<p class="small">نمره‌های رسمی را در بخش نتایج ثبت کنید.</p>')
      :first?`<p class="small">${ex.length>1?`${fa(ex.length)} امتحان | اولی ${jLabel(first.date)}`:jLabel(first.date)}${first.estimated?' <span class="pill p-warn">تاریخ تخمینی</span>':""}</p>
      ${k!=="konkur"&&k===fk&&rF?`<p class="small muted" style="margin-top:6px">میانگین خودارزیابی ${fa(rF.avg)} از ۵ | ${fa(rF.res)} نمونه‌سؤال ثبت شده</p>`:""}
      ${k==="konkur"&&rK?`<p class="small muted" style="margin-top:6px">میانگین خودارزیابی ${fa(rK.avg)} از ۵ | ${fa(rK.res)} آزمون آزمایشی ثبت شده</p>`:""}`:'<p class="small muted">در مسیر فعلی شما نیست.</p>'}
      </section>`}).join("")}
  </div>
  <section class="card"><div class="card-h"><div><h2>قوانین اثر سوابق تحصیلی | کنکور ${faStr(K)}</h2><p class="small muted">${esc(rs.note)}</p></div>${rs.confirmed?'<span class="pill p-good">اعلام‌شده</span>':'<span class="pill p-warn">پیش‌نویس</span>'}</div>
    <div class="bar" style="height:14px" role="img" aria-label="سهم‌ها"><i style="width:${rs.g12}%;background:var(--accent)"></i><i style="width:${rs.g11}%;background:color-mix(in oklab,var(--accent) 50%,var(--surface))"></i><i style="flex:1;background:var(--saffron)"></i></div>
    <div class="legend" style="margin-top:8px;flex-wrap:wrap"><span><i style="background:var(--accent)"></i>نهایی دوازدهم ~${fa(rs.g12)}٪</span><span><i style="background:color-mix(in oklab,var(--accent) 50%,var(--surface))"></i>نهایی یازدهم ~${fa(rs.g11)}٪ ${rs.g11Courses==="six"?"(۶ درس)":"(درس‌ها طبق اعلام سنجش)"}</span><span><i style="background:var(--saffron)"></i>آزمون کنکور ~${fa(rs.test)}٪</span></div>
    <div class="note" style="margin-top:12px">فقط نمرهٔ کتبی امتحان نهایی در کنکور اثر دارد؛ نمرهٔ مستمر و معدل کل دیپلم اثر ندارد. پایه دهم امتحان نهایی کشوری ندارد. اگر درسی که اثر دارد نمرهٔ نهایی نداشته باشد، صفر حساب می‌شود. ضرایب و فهرست دقیق درس‌ها هر سال تغییر می‌کند — تاریخ‌ها و قوانین را در تنظیمات به‌روز کنید.</div>
  </section>
  ${counting.length?`<section class="card"><div class="card-h"><h2>درس‌های امتحان نهایی امسال</h2><span class="small muted">مرتب‌شده بر اساس اولویت امروز</span></div><div class="tscroll"><table><thead><tr><th>درس</th><th>تاریخ</th><th>خودارزیابی</th><th>آخرین تمرین</th><th>اولویت</th></tr></thead><tbody>
    ${counting.map(s=>({s,r:scoreSubject(s,"final",todayIso())})).sort((a,b)=>(b.r?.score||0)-(a.r?.score||0)).map(({s,r})=>{const ex=examFor(s.id,fk);const pr=lastResult(s.id,"practice");return `<tr><td>${esc(courseName(s,g))}</td><td class="num">${ex?jShort(ex.date):"—"}</td><td class="num">${fa(s.level)} / ۵</td><td class="num">${pr?fa(pr.score)+" از ۲۰":"—"}</td><td>${r?`<div class="bar" style="width:90px"><i style="width:${Math.min(100,r.score/5*100)}%;background:var(--accent)"></i></div>`:""}</td></tr>`}).join("")}
  </tbody></table></div></section>`:""}
  </div>`;
}
function avgScores(){
  const v=Object.entries(S.finalScores).filter(([id])=>!(S.finalExcluded&&S.finalExcluded[id])).map(([,val])=>Number(val)).filter(x=>!isNaN(x));
  return v.length?Math.round(v.reduce((a,b)=>a+b,0)/v.length*100)/100:0;
}
function finalScoreCount(){return Object.keys(S.finalScores).filter(id=>!(S.finalExcluded&&S.finalExcluded[id])).length}

function renderExamPrep(){
  const fk=currentFinalKind();const first=examPrepFirst();const win=examPrepWindowDays();const early=win>21;
  const {days,lateCount}=examPrepSchedule();
  const EP=examPrepState();
  const eligible=examPrepEligibleSubjects();
  const subs=EP.subjectIds?eligible.filter(s=>EP.subjectIds.includes(s.id)):eligible;
  const totalRemaining=subs.reduce((a,s)=>{const L=finalLessons(s);return a+Math.max(0,L.length-Math.min(prog(s).f,L.length))},0);
  return `<div class="stack">
  <section class="card"><div class="card-h"><div><h2>برنامهٔ امتحانی</h2><p class="small muted">${first?`تا نزدیک‌ترین امتحان نهایی (${jLabel(first.date)}): ${fa(Math.max(0,daysUntil(first.date)))} روز مانده`:"امتحان نهایی‌ای در پیش نیست"}</p></div>
    <div class="row">${early?'<span class="badge ghost">زودتر، به درخواست تو</span>':'<span class="badge">۳ هفته پیش از امتحان‌ها</span>'}<button type="button" class="btn sm ghost" data-act="examprepwizard">${examPrepSetupDone()?"ویرایش تنظیمات":"تنظیم برنامه"}</button></div></div>
    <p class="small muted">این برنامه فقط «خواندن تشریحی»، «نمونه سؤال امتحان نهایی سال‌های قبل» و «خلاصه‌نویسی» دارد — هیچ تست‌زنی و هیچ درسی از پایه‌های قبل در آن نیست — تا هر ${fa(subs.length)} درس امتحانی امسال دست‌کم یک روز پیش از امتحان خودش تمام شود.</p>
    ${examPrepSetupDone()?`<p class="small muted" style="margin-top:6px">${EP.school?"با احتساب مدرسه‌رفتن در این بازه":"بدون مدرسه در این بازه"} | روزی ${EP.studyMinutes?durLabel(EP.studyMinutes):"—"} مطالعه${EP.sleep?` | خواب ${faStr(EP.sleep.bed)} تا بیداری ${faStr(EP.sleep.wake)}`:""}</p>`
      :`<div class="alert" style="margin-top:10px">هنوز برنامهٔ امتحانی‌ات را تنظیم نکرده‌ای؛ روی «تنظیم برنامه» بزن تا چند سؤال کوتاه بپرسم و دقیق برایت بچینمش.</div>`}
    <div class="stats" style="margin-top:14px"><div class="stat"><span class="label">جلسهٔ باقی‌ماندهٔ کتاب</span><b class="num">${fa(totalRemaining)}</b></div><div class="stat"><span class="label">روزهای برنامه‌ریزی‌شده</span><b class="num">${fa(days.length)}</b></div><div class="stat"><span class="label">شروع پیش‌فرض</span><b class="num">۳ هفته</b></div></div>
    ${lateCount?`<div class="alert" style="margin-top:14px">با زمان مطالعهٔ فعلی، ${fa(lateCount)} جلسه دیرتر از یک روز پیش از امتحان همان درس جا می‌شود. از <b class='brand-word'>EvonoAI</b> بخواه ساعت مطالعهٔ روزانه را زیاد کند یا زودتر (مثلاً از ۴ هفته مانده) شروعش کن.</div>`:""}
  </section>
  ${subs.length?`<section class="card flat"><b class="small">امتحان‌های این برنامه</b><div class="stack" style="gap:6px;margin-top:8px">${subs.map(s=>{const ex=examFor(s.id,fk);const t=EP.examTimes&&EP.examTimes[s.id];return `<div class="row" style="justify-content:space-between"><span class="small">${esc(subName(s.id))}</span><span class="small muted num">${jLabel(ex.date)}${t?" | ساعت "+faStr(t):""}</span></div>`}).join("")}</div></section>`:""}
  ${!days.length?`<section class="card"><p class="muted">${subs.length?"همهٔ کتاب‌های امتحانی امسال خوانده شده‌اند؛ فقط نمونه‌سؤال و خلاصه‌نویسی مانده، یا هنوز به بازهٔ امتحانی نرسیده‌ای.":"امسال درسی با امتحان نهایی ثبت‌شده نداری."}</p></section>`:days.map(d=>{const dn=dFromIso(d.iso);const j=d2j(dn);const isToday=d.iso===todayIso();
    return `<section class="card flat"><div class="card-h"><b>${isToday?"امروز":WD[wdIdx(dn)]}</b><span class="small muted">${fa(j.jd)} ${JM[j.jm-1]}</span></div>
    <div class="stack" style="gap:8px">${d.items.map(it=>`<div class="wtask"><b>${esc(subName(it.subjectId))}</b><span class="wt-type">${esc(it.type)}${it.label?" — "+esc(it.label):""}</span></div>`).join("")}</div>
    </section>`}).join("")}
  </div>`;
}

/* ---------- برنامهٔ امتحانی — تنظیم اولیه (required setup wizard) ----------
   Shown the first time the student opens برنامهٔ امتحانی (and re-openable any time via its own "ویرایش
   تنظیمات" button) — every field here is required before the wizard lets the student move on, per the
   student's own request. Its answers live in examPrepState() and drive examPrepSchedule() directly. */
let EPW=null;
const EPW_STEPS=["school","subjects","times","sleep","pace"];
function openExamPrepWizard(){
  const fk=currentFinalKind();if(!fk)return;
  const EP=examPrepState();
  const eligible=examPrepEligibleSubjects();
  const picked={};eligible.forEach(s=>{picked[s.id]=EP.subjectIds?EP.subjectIds.includes(s.id):true});
  const times={};eligible.forEach(s=>{times[s.id]=(EP.examTimes&&EP.examTimes[s.id])||"09:00"});
  EPW={step:0,school:EP.school,studyHours:EP.studyMinutes?Math.round(EP.studyMinutes/60*10)/10:null,picked,times,
    sleepWake:(EP.sleep&&EP.sleep.wake)||S.sleep.wake,sleepBed:(EP.sleep&&EP.sleep.bed)||S.sleep.bed,
    sessionLen:EP.sessionLen||S.profile.sessionLen||60,breakLen:EP.breakLen!=null?EP.breakLen:(S.profile.breakLen??10)};
  closeModal();
  const o=document.createElement("div");o.className="modal-bg";
  o.innerHTML=`<div class="modal wide" role="dialog" aria-modal="true" id="examprep-wizard-el">${examPrepWizardHTML()}</div>`;
  document.body.appendChild(o);
  // No click-outside-to-dismiss here on purpose — every field is required, tapping the backdrop shouldn't
  // be a way to skip it. Only the × (data-ew="close") or a real settings link closes it.
  bindExamPrepWizard(document.getElementById("examprep-wizard-el"));
}
function examPrepWizardHTML(){
  const fk=currentFinalKind();
  const eligible=examPrepEligibleSubjects();
  if(!eligible.length){
    return `<div class="row" style="justify-content:space-between;align-items:flex-start;margin-bottom:6px"><h2 style="margin:0">برنامهٔ امتحانی</h2><button type="button" class="x-close" data-ew="close" aria-label="بستن" title="بستن">×</button></div>
    <p class="muted">هنوز تاریخ هیچ امتحان نهایی‌ای برای درس‌هایت ثبت نشده، پس نمی‌شود برنامه‌اش را چید. اول از «تنظیمات کامل ← امتحانات اصلی» تاریخ امتحان‌های نهایی را ثبت کن، بعد دوباره این تب را باز کن.</p>
    <div class="row" style="justify-content:center;margin-top:16px"><button type="button" class="btn primary" data-ew="opensettings">رفتن به تنظیمات</button></div>`;
  }
  const i=Math.max(0,Math.min(EPW.step,EPW_STEPS.length-1));EPW.step=i;
  const name=EPW_STEPS[i];
  const head=`<div class="row" style="justify-content:space-between;align-items:flex-start;margin-bottom:4px"><div><h2 style="margin:0">تنظیم برنامهٔ امتحانی</h2><p class="small muted" style="margin-top:2px">مرحلهٔ ${fa(i+1)} از ${fa(EPW_STEPS.length)}</p></div><button type="button" class="x-close" data-ew="close" aria-label="بستن" title="بستن">×</button></div>
  <div class="row" style="gap:6px;margin-bottom:16px" aria-hidden="true">${EPW_STEPS.map((_,si)=>`<span style="flex:1;height:4px;border-radius:99px;background:${si<=i?"var(--metal)":"var(--line-2)"}"></span>`).join("")}</div>`;
  let body="";
  if(name==="school"){
    body=`<div class="stack" style="gap:18px">
      <div><b>در همین ۳ تا ۴ هفتهٔ باقی‌مانده، مدرسه هم می‌روی؟</b>
      <div class="seg" style="margin-top:10px"><label><input type="radio" name="ew-school" value="1" ${EPW.school===true?"checked":""}><span>بله</span></label><label><input type="radio" name="ew-school" value="0" ${EPW.school===false?"checked":""}><span>نه، تعطیل است</span></label></div></div>
      <label class="field"><span>روزی چند ساعت می‌خواهی فقط برای همین برنامهٔ امتحانی بخوانی؟</span><input type="text" inputmode="decimal" data-pfa="dec" id="ew-hours" placeholder="مثلاً ۶" value="${EPW.studyHours!=null?faStr(EPW.studyHours):""}"></label>
    </div>`;
  }else if(name==="subjects"){
    body=`<b>کدام درس‌ها امتحان نهایی دارند و می‌خواهی در این برنامه باشند؟</b><p class="small muted" style="margin-top:2px">دست‌کم یکی را انتخاب کن.</p>
    <div class="stack" style="gap:8px;margin-top:12px">${eligible.map(s=>`<label class="rv"><input type="checkbox" data-ew-sub="${s.id}" ${EPW.picked[s.id]?"checked":""}><span><b>${esc(subName(s.id))}</b></span></label>`).join("")}</div>`;
  }else if(name==="times"){
    const chosen=eligible.filter(s=>EPW.picked[s.id]);
    body=`<b>هر امتحان نهایی دقیقاً ساعت چند برگزار می‌شود؟</b><p class="small muted" style="margin-top:2px">تا دست‌کم یک روز کامل پیش از همین ساعت، خواندن آن درس تمام می‌شود.</p>
    <div class="stack" style="gap:14px;margin-top:14px">${chosen.length?chosen.map(s=>{const ex=examFor(s.id,fk);return `<div class="field"><span>${esc(subName(s.id))} — ${ex?jLabel(ex.date):""}</span>${tp("ew-time-"+s.id,EPW.times[s.id])}</div>`}).join(""):'<p class="small muted">هیچ درسی در مرحلهٔ قبل انتخاب نشد.</p>'}</div>`;
  }else if(name==="sleep"){
    body=`<b>در همین بازه چه ساعتی می‌خوابی و بیدار می‌شوی؟</b>
    <div class="fgrid" style="margin-top:14px"><div class="field"><span>بیداری</span>${tp("ew-wake",EPW.sleepWake)}</div><div class="field"><span>خواب</span>${tp("ew-bed",EPW.sleepBed)}</div></div>`;
  }else if(name==="pace"){
    body=`<b>طول هر جلسهٔ مطالعه و استراحت بین جلسه‌ها در این بازه؟</b>
    <div class="fgrid" style="margin-top:14px">${hmInput("ew-len",EPW.sessionLen,"طول هر جلسه")}${hmInput("ew-brk",EPW.breakLen,"استراحت بین جلسه‌ها")}</div>`;
  }
  const nav=`<div class="row" style="justify-content:space-between;margin-top:22px">
    ${i>0?`<button type="button" class="btn" data-ew="back">→ قبلی</button>`:"<span></span>"}
    <button type="button" class="btn primary" data-ew="${i===EPW_STEPS.length-1?"finish":"next"}">${i===EPW_STEPS.length-1?"ثبت و اعمال":"بعدی ←"}</button>
  </div>`;
  return head+`<div class="stack" style="gap:0">${body}</div>`+nav;
}
/* Pulls whatever inputs exist for the currently-rendered step into EPW — called before both a validated
   Next/Finish and a plain Back, so nothing typed is lost either way. */
function captureExamPrepStepInputs(){
  if(!EPW)return;
  const hoursEl=document.getElementById("ew-hours");
  if(hoursEl){const v=Number(toEnDigits(hoursEl.value));EPW.studyHours=hoursEl.value.trim()===""||isNaN(v)?null:v}
  examPrepEligibleSubjects().forEach(s=>{if(document.getElementById("ew-time-"+s.id+"-h"))EPW.times[s.id]=tpVal("ew-time-"+s.id,EPW.times[s.id])});
  if(document.getElementById("ew-wake-h"))EPW.sleepWake=tpVal("ew-wake",EPW.sleepWake);
  if(document.getElementById("ew-bed-h"))EPW.sleepBed=tpVal("ew-bed",EPW.sleepBed);
  if(document.getElementById("ew-len-h")){EPW.sessionLen=readHM("ew-len");EPW.breakLen=readHM("ew-brk")}
}
function validateExamPrepStep(){
  const name=EPW_STEPS[EPW.step];
  if(name==="school"){
    if(EPW.school==null){toast("لطفاً بگو در این بازه مدرسه می‌روی یا نه");return false}
    if(EPW.studyHours==null||!(EPW.studyHours>0&&EPW.studyHours<=16)){toast("ساعت مطالعهٔ روزانه را عددی بین ۰ تا ۱۶ وارد کن");return false}
    return true;
  }
  if(name==="subjects"){
    if(!examPrepEligibleSubjects().some(s=>EPW.picked[s.id])){toast("دست‌کم یک درس را انتخاب کن");return false}
    return true;
  }
  if(name==="pace"){
    if(!(EPW.sessionLen>=15&&EPW.sessionLen<=150)){toast("طول جلسه باید بین ۱۵ دقیقه و ۲ ساعت و ۳۰ دقیقه باشد");return false}
    if(!(EPW.breakLen>=0&&EPW.breakLen<=45)){toast("استراحت باید بین ۰ تا ۴۵ دقیقه باشد");return false}
    return true;
  }
  return true; // times/sleep steps use HH:MM pickers that always carry a valid value
}
function refreshExamPrepWizard(){
  const el=document.getElementById("examprep-wizard-el");if(!el)return;
  el.innerHTML=examPrepWizardHTML();bindExamPrepWizard(el);
}
function finishExamPrepWizard(){
  const EP=examPrepState();
  EP.school=EPW.school;EP.studyMinutes=Math.round(EPW.studyHours*60);
  EP.subjectIds=examPrepEligibleSubjects().filter(s=>EPW.picked[s.id]).map(s=>s.id);
  EP.examTimes=EP.examTimes||{};examPrepEligibleSubjects().forEach(s=>{if(EPW.picked[s.id])EP.examTimes[s.id]=EPW.times[s.id]});
  EP.sleep={wake:EPW.sleepWake,bed:EPW.sleepBed};EP.sessionLen=EPW.sessionLen;EP.breakLen=EPW.breakLen;
  EP.setupDone=true;save();EPW=null;closeModal();toast("برنامهٔ امتحانی آماده شد");render();
}
function bindExamPrepWizard(root){
  if(!root)return;
  root.querySelectorAll('[data-ew="close"]').forEach(b=>b.onclick=()=>{EPW=null;closeModal()});
  root.querySelectorAll('[data-ew="opensettings"]').forEach(b=>b.onclick=()=>{EPW=null;closeModal();openSettingsModal()});
  root.querySelectorAll('input[name="ew-school"]').forEach(i=>i.onchange=()=>{EPW.school=i.value==="1"});
  root.querySelectorAll('[data-ew-sub]').forEach(c=>c.onchange=()=>{EPW.picked[c.dataset.ewSub]=c.checked});
  root.querySelectorAll('[data-ew="back"]').forEach(b=>b.onclick=()=>{captureExamPrepStepInputs();EPW.step=Math.max(0,EPW.step-1);refreshExamPrepWizard()});
  root.querySelectorAll('[data-ew="next"]').forEach(b=>b.onclick=()=>{captureExamPrepStepInputs();if(!validateExamPrepStep())return;EPW.step++;refreshExamPrepWizard()});
  root.querySelectorAll('[data-ew="finish"]').forEach(b=>b.onclick=()=>{captureExamPrepStepInputs();if(!validateExamPrepStep())return;finishExamPrepWizard()});
}

/* ---------- AI ---------- */
let aiBusy=false,aiCtl=null;
function renderAI(){
  return `<div class="grid g-main"><section class="card chat"><div class="card-h"><h2><span class="ai-mark">Evono<i>AI</i></span> مشاور تحصیلی شما</h2>${S.chat.length?'<button class="btn sm ghost" data-act="clearchat">گفت‌وگوی تازه</button>':""}</div>
    ${subActive()?quotaBar():`<div class="trialbar"><span>${subLapsed()?"اشتراک <b class='brand-word'>EvonoAI</b> تمام شده است":"<b class='brand-word'>EvonoAI</b> به یکی از اشتراک‌ها نیاز دارد"}</span><button class="btn sm primary" data-tab="plans">${subLapsed()?"تمدید اشتراک":"خرید اشتراک"}</button></div>`}
    <div class="msgs" id="msgs">${S.chat.length?S.chat.map(renderMsg).join(""):`<div class="msg a">سلام${S.profile.name?" "+esc(S.profile.name):""}! من <b class='brand-word'>EvonoAI</b> هستم. برنامه، امتحان‌ها و نتایج شما را می‌بینم و می‌توانم برنامه را واقعاً تغییر دهم. بگویید امروز چه خبر است.</div>`}</div>
    <div class="quick">${QUICK.map(q=>`<button data-quick="${esc(q)}">${esc(q)}</button>`).join("")}</div>
    <form class="composer" id="composer"><textarea id="ai-in" placeholder="مثلاً: امشب نمی‌توانم درس بخوانم" aria-label="پیام به EvonoAI"></textarea>
      <button class="btn primary" id="ai-send" ${aiAllowed()?"":"disabled"}>${aiBusy?"توقف":"ارسال"}</button></form>
  </section>
  <aside class="stack"><section class="card"><h3><b class='brand-word'>EvonoAI</b> چه کارهایی می‌کند؟</h3><ul class="small" style="margin:8px 0 0;padding-inline-start:18px;line-height:2">
    <li>تغییر سبک برنامهٔ کل هفته</li><li>تنظیم زمان امروز و بازسازی برنامه</li><li>جابه‌جایی یا رد کردن جلسه‌ها</li><li>ثبت آزمون مدرسه و اولویت‌دادن به آن</li><li>ثبت نمرهٔ نمونه‌سؤال نهایی و آزمون آزمایشی</li><li>توضیح دلیل هر تصمیم</li></ul>
    <p class="small muted" style="margin-top:8px">هر تغییری که انجام شود زیر پیام با ✓ نشان داده می‌شود. اگر تیک نداشته باشد، تغییری ثبت نشده است.</p></section></aside></div>`;
}
function md(t){const lines=esc(t).split("\n");let out="",list=null;const inline=x=>x.replace(/\*\*(.+?)\*\*/g,"<b>$1</b>");
  const close=()=>{if(list){out+=`</${list}>`;list=null}};
  for(const raw of lines){const l=raw.trim();let m;
    if(/^#{1,4}\s+/.test(l)){close();out+=`<h4>${inline(l.replace(/^#{1,4}\s+/,""))}</h4>`}
    else if((m=l.match(/^[-•*]\s+(.*)/))){if(list!=="ul"){close();out+="<ul>";list="ul"}out+=`<li>${inline(m[1])}</li>`}
    else if((m=l.match(/^[0-9۰-۹]+[.)]\s+(.*)/))){if(list!=="ol"){close();out+="<ol>";list="ol"}out+=`<li>${inline(m[1])}</li>`}
    else if(!l){close()}
    else{close();out+=`<p>${inline(l)}</p>`}}
  close();return out}
function actChips(list){if(!list||!list.length)return "";const ok=list.filter(a=>a.ok);
  const shown=ok.length?ok:[{ok:false,text:"تغییری در برنامه اعمال نشد"+(/[a-z]{4,}/i.test(list[list.length-1].text)?"":": "+list[list.length-1].text)}];
  return `<div class="acts-done">${shown.map(a=>`<span class="${a.ok?"ok":"no"}">${esc(a.text)}</span>`).join("")}</div>`}
function renderMsg(m){if(m.role!=="user")return `<div class="msg a rich">${md(m.content)}${actChips(m.actions)}</div>`;return `<div class="msg ${m.role==="user"?"u":"a"}">${esc(m.content)}${m.actions&&m.actions.length?`<div class="acts-done">${m.actions.map(a=>`<span class="${a.ok?"ok":"no"}">${esc(a.text)}</span>`).join("")}</div>`:""}</div>`}
function aiContext(){
  const d=todayIso();const p=planFor(d);const ph=phase();const K=S.profile.konkurYear;const rs=ruleSet(K);
  const last7=[];for(let i=1;i<=7;i++){const iso=isoFromD(todayD()-i);const l=S.log.filter(x=>x.date===iso);last7.push({date:jShort(iso),done:l.filter(x=>x.status==="done").reduce((a,x)=>a+x.minutes,0),missed:l.filter(x=>x.status!=="done").reduce((a,x)=>a+x.minutes,0)})}
  return JSON.stringify({
    season_today:seasonOf(d),holiday_window:S.holiday,konkur_review:{applies:["11","12"].includes(S.profile.grade),...reviewPrefs(),max_review_sessions_per_week:{light:2,medium:3,heavy:4}[reviewPrefs().level],review_cutoff_active:konkurReviewCutoffActive()},
    exam_prep_tab:(()=>{const first=examPrepFirst();const fk=currentFinalKind();const EP=examPrepState();const eligible=examPrepEligibleSubjects();
      return{active:examPrepActive(),default_days_before:21,current_days_before:examPrepWindowDays(),days_until_nearest_final:first?daysUntil(first.date):null,
        setup_done:EP.setupDone,school_during:EP.school,daily_study_hours:EP.studyMinutes?Math.round(EP.studyMinutes/60*10)/10:null,session_len:EP.sessionLen,break_len:EP.breakLen,sleep:EP.sleep,
        eligible_subjects:fk?eligible.map(s=>{const ex=examFor(s.id,fk);return{subject_id:s.id,name:subName(s.id),exam_date:ex?jShort(ex.date):null,exam_time:(EP.examTimes&&EP.examTimes[s.id])||null,included:!EP.subjectIds||EP.subjectIds.includes(s.id)}}):[]}})(),
    today:{jalali:jShort(d).replace(/[۰-۹]/g,c=>"۰۱۲۳۴۵۶۷۸۹".indexOf(c)),weekday:WD[wdIdx(todayD())],now:hmA(nowMin()),window_left:p.minutes?`${p.start}-${hmA(toMin(p.start)+p.minutes)}`:"none",custom:!!p.custom,last_change:p.change?p.change.note:null,
      tasks:p.tasks.map(t=>({task_id:t.id,start:hmA(t.start),end:hmA(t.start+t.minutes),lesson:t.lesson||null,subject_id:t.subjectId,subject:subName(t.subjectId),minutes:t.minutes,target:t.bucket==="final"?"نهایی/مدرسه":"کنکور",type:t.type,status:t.status,reasons:(t.reasons||[]).slice(0,3)}))},
    student:{name:S.profile.name,grade:S.profile.grade,field:CATALOG[S.profile.field].label,konkur_year:K,session_len:S.profile.sessionLen,break_len:S.profile.breakLen,retake:S.profile.retake},
    rules:{sabeghe_percent:rs.sabeghe,test_percent:rs.test,grade12_percent:rs.g12,grade11_percent:rs.g11,confirmed:rs.confirmed,note:rs.note},
    phase:{label:ph.label,finals_share:ph.finals,why:ph.why},
    subjects:S.subjects.map(s=>({subject_id:s.id,name:subName(s.id),class_is_at:(()=>{const L=finalLessons(s);const P=prog(s);return L.length?(P.f>=L.length?"کتاب تمام شده":`${L[P.f]} (جلسهٔ ${P.f+1} از ${L.length})`):null})(),chapter_remaining_parts_today:(()=>{const c=chapterRemaining(s);return c?{chapter:c.title,parts_left:c.parts}:null})(),next_konkur_lesson:(()=>{const x=lessonFor(s,"konkur",todayIso(),[]);return x?x.label:null})(),self_level_1to5:s.level,counts_in_finals_this_year:countsInFinals(s),konkur_importance:s.kw,backlog_min:S.backlog[s.id]||0,last_practice_out_of_20:lastResult(s.id,"practice")?.score??null,last_mock_percent:lastResult(s.id,"mock")?.score??null})),
    upcoming_exams:upcoming().slice(0,8).map(e=>({title:e.title,date:jShort(e.date),days_left:daysUntil(e.date),kind:e.kind,estimated_date:!!e.estimated})),
    grade11_final_scores:S.finalScores,
    grade11_final_excluded_subjects:Object.keys(S.finalExcluded||{}),
    grade11_final_average:avgScores(),
    sleep:{school_days:{wake:S.sleep.wake,bed:S.sleep.bed},weekend:{wake:S.sleep.wakeOff,bed:S.sleep.bedOff},today:sleepFor(d)},
    week:weekDates().slice(1).map(d=>{const q=planFor(d);const w=availabilityFor(d);return{date:jShort(d).replace(/[۰-۹]/g,c=>"۰۱۲۳۴۵۶۷۸۹".indexOf(c)),weekday:WD[wdIdx(dFromIso(d))],window:w.minutes?`${w.start}-${w.end}`:"off",custom:!!q.custom,season:seasonOf(d),tasks:q.tasks.map(t=>({task_id:t.id,start:hmA(t.start),end:hmA(t.start+t.minutes),subject_id:t.subjectId,lesson:t.lesson||null,minutes:t.minutes,target:t.bucket,status:t.status}))}}),
    preferences:{...S.prefs,session_len:S.profile.sessionLen,break_len:S.profile.breakLen,availability:S.availability},
    last_7_days:last7,
    recent_reports:S.reports.slice(-3).map(r=>({date:jShort(r.date),minutes:r.minutes,energy:r.energy,focus:r.focus,hard:r.hard,note:r.note,screen_total_min:r.screenTotal}))
  });
}
const AI_RULES=`تو EvonoAI هستی: مشاور ارشد تحصیلی و برنامه‌ریز حرفه‌ای کنکور و امتحان نهایی در اپلیکیشن Evono، با سال‌ها تجربهٔ مشاورهٔ دانش‌آموزان ایرانی.
هدف: رساندن دانش‌آموز به بهترین نتیجه در سه امتحان سرنوشت‌ساز: امتحان نهایی پایه یازدهم، امتحان نهایی پایه دوازدهم و کنکور.

دانش تخصصی که باید به کار ببری:
- امتحان نهایی: مطالعهٔ خط‌به‌خط کتاب درسی، تمرین پاسخ تشریحی کامل، حل سؤالات امتحان نهایی سال‌های قبل، مرور جمع‌بندی در هفته‌های آخر.
- کنکور: چرخهٔ درسنامه ← تست آموزشی ← تست زمان‌دار ← تحلیل آزمون و دفتر خطا؛ اولویت با درس‌های پرضریب رشته.
- یادگیری: مرور فاصله‌دار (۱، ۳، ۷ و ۲۱ روز بعد)، یادآوری فعال، درس سنگین در ساعت اوج تمرکز، جلسه‌های ۴۵ تا ۹۰ دقیقه‌ای با استراحت کوتاه، خواب کافی (حدود ۷ تا ۹ ساعت) برای تثبیت حافظه.

قواعد رفتار:
1) داده‌محور باش: فقط از CONTEXT استفاده کن و عدد مشخص بده (ساعت، مدت، روز، درس). چیزی از خودت نساز. درصدها و قوانین کنکور را فقط از بخش rules بخوان.
2) هر درخواستی برای تغییر برنامه (امشب، امروز، فردا یا هر روز هفته) را حتماً با ابزار انجام بده، نه فقط با حرف. ابزار اصلی برای «برنامهٔ امشب/فردا را این‌طور کن» replace_day_plan است: برنامهٔ قبلی آن روز لغو می‌شود و جلسه‌های جدید با ساعت شروع، درس و مدت دقیق جایش می‌نشیند. اگر دانش‌آموز فقط گفت «امشب کمتر/بیشتر وقت دارم» یا «از ساعت X تا Y» از set_day_time استفاده کن. برای تغییر سبک کل هفته set_preferences، برای ساعت خواب و بیداری set_sleep_schedule، برای یک روز تعطیل set_day_time با off:true، برای هر چیزی داخل خودِ برنامهٔ امتحانی (نه برنامهٔ هفتهٔ عادی) set_exam_prep_plan.
3) هرگز نگو «تغییر دادم» مگر اینکه ابزار ok:true برگردانده باشد. اگر ابزار خطا داد (مثلاً ساعت گذشته، بعد از ساعت خواب، هم‌پوشانی)، خودت اصلاحش کن و دوباره صدا بزن.
4) ساعت خواب و بیداری (sleep) و ساعت فعلی (today.now) را رعایت کن؛ هیچ جلسه‌ای بعد از ساعت خواب یا در گذشته نگذار. برنامه باید واقع‌بینانه باشد و کار عقب‌افتاده را یک‌جا روی یک روز تلنبار نکن.
5) مدت‌ها را به صورت ساعت و دقیقه بنویس (مثلاً «۱ ساعت و ۳۰ دقیقه») و ساعت‌ها را مثل «ساعت ۱۹:۳۰».
6) بعد از هر تغییر، برنامهٔ جدید را مرتب نشان بده (هر خط: ساعت — درس — فصل/بخش — مدت — نوع مطالعه)، بگو برنامهٔ قبلی لغو شد و در یک جمله دلیلت را بگو.
7) برای سؤال‌های مشاوره‌ای جواب دقیق، ساختاریافته و عملی بده: تیتر کوتاه با «### »، فهرست با «- »، گام‌های مشخص و متناسب با داده‌های خودش. کوتاه و مفید: معمولاً ۸۰ تا ۱۸۰ کلمه. برای تغییر برنامه مستقیم سراغ ابزار برو و بعد فقط برنامهٔ جدید را فهرست کن.
13) ابزارها خودشان جلسه‌ها را مرتب می‌کنند (اگر ساعتی گذشته یا هم‌پوشان باشد جابه‌جا می‌کنند)؛ اگر adjustments برگرداند، آن‌ها را به دانش‌آموز بگو.
8) آمادگی نهایی (کتاب درسی، تشریحی) را از آمادگی کنکور (تست، زمان‌دار، تحلیل) جدا بدان و در جلسه‌ها target را درست بگذار (final یا konkur).
9) تاریخ‌ها را شمسی بنویس. در ابزارها تاریخ را "today"، "tomorrow" یا به شکل 1405/08/15 با ارقام انگلیسی و ساعت را HH:MM بده.
10) رتبه، نمره یا قبولی را تضمین نکن. دربارهٔ زمان استفاده از گوشی سرزنش نکن و ادعای پزشکی یا روان‌شناختی نکن.
11) فارسی، صمیمی و با «تو» حرف بزن؛ دقیق و حرفه‌ای مثل یک مشاور خوب.
15) درس‌به‌درس برنامه بریز: هر جلسه باید یک فصل/درس/بخش مشخص از کتاب درسی داشته باشد. از class_is_at (جایی که کلاس رسیده) و next_konkur_lesson در CONTEXT استفاده کن و در replace_day_plan فیلد lesson را دقیقاً با همان نام بگذار (مثل «فصل ۲: دینامیک و حرکت دایره‌ای — بخش ۱»). اگر دانش‌آموز گفت کلاسش به کجا رسیده، با set_subject_progress ثبتش کن. نام فصل‌ها را از خودت نساز؛ فقط از CONTEXT.
17) کنکور از هر سه پایه (دهم، یازدهم، دوازدهم) است. konkur_review نشان می‌دهد مرور پایه‌های قبل روشن است یا نه؛ جلسه‌های کنکور خودشان بین کتاب‌های پایه‌های قبل و پایهٔ فعلی می‌چرخند. برای دوازدهمی‌ها اگر مرور خاموش است، در یک جملهٔ ساده پیشنهاد بده که روشنش کنی و در صورت موافقتش خودت انجامش بده.
16) فصل‌ها: season_today و season هر روز را ببین. در تابستان (تیر تا شهریور)، نوروز و خرداد (فصل امتحانات) مدرسه و کلاس صبح نیست؛ از holiday_window استفاده کن و جلسه‌ها را از صبح بچین. در خرداد تمرکز روی امتحان‌های نهایی است و در تابستانِ بعد از دوازدهم روی کنکور.
18) سرعت پیشروی در فصل‌های چندبخشی را واقع‌بینانه نگه‌دار: یک فصل چندبخشی را در حدود یک هفته تمام نکن؛ Evono خودش این را با pace:"steady" کنترل می‌کند. مقدار پیش‌فرض pace بر اساس پایه و رشته خودکار تنظیم شده: پایه دهم فشار امتحان نهایی/کنکور ندارد پس برنامه‌اش سبک‌تر و آرام‌تر است، و رشتهٔ تجربی چون رقابت کنکورش سنگین‌تر است کمی فشرده‌تر و سخت‌تر از بقیه است — این‌ها را خودت دستی عوض نکن. فقط اگر دانش‌آموز خودش صریحاً خواست، با set_preferences مقدار pace را "fast" (سریع‌تر/سخت‌تر) یا "easy" (آسان‌تر/سبک‌تر) کن.
19) پایه دوازدهم و دانش‌آموختهٔ پشت‌کنکوری باید حجم زیادی تست بزنند: تست‌زنی یعنی حل تست‌های شبیه‌سازی‌شدهٔ کنکور از کتاب‌های کمک‌آموزشی (نه فقط تمرین کتاب درسی)، تا با فرم سؤال‌های کنکور آشنا شوند. Evono خودش بیشتر جلسه‌های کنکور این دانش‌آموزان را تست‌زنی/آزمون زمان‌دار می‌گذارد و پایان هر فصل نهایی را با یک «تست جامع پایان فصل» می‌بندد؛ در گفت‌وگو هم این را تشویق کن و اگر جلسه‌ای برای این دانش‌آموزان با replace_day_plan ساختی، بخش قابل‌توجهی تست‌زنی بگذار، نه فقط درسنامه.
20) وقتی دانش‌آموز گفت می‌خواهد یک فصل را همان روز کامل تمام کند: فصل‌های چندبخشی در کتاب چند «— بخش» پشت‌سرهم هستند و هر جلسه فقط یک بخش را پوشش می‌دهد؛ برای اینکه فصل واقعاً همان روز تمام شود باید همهٔ بخش‌های باقی‌ماندهٔ همان فصل، نه فقط بخش بعدی، جلسه‌های جداگانه در replace_day_plan همان روز باشند. فیلد chapter_remaining_parts_today آن درس در CONTEXT را ببین؛ اگر parts_left چند بخش دارد، برای هر کدام یک جلسه با همان متن دقیق بگذار (پشت‌سرهم با استراحت کوتاه). اگر مجموع زمانشان در آن روز جا نشود، صادقانه بگو کدام بخش‌ها جا نمی‌شوند و پیشنهاد بده کدام‌ها را به فردا منتقل کنی؛ به‌زور کوتاهشان نکن. بعد از این کار، چون دانش‌آموز صریحاً خواسته سریع‌تر برود، با set_preferences مقدار pace را "fast" کن تا هفتهٔ بعد دوباره کند نشود.
14) توصیهٔ همیشگی Evono: هر جلسهٔ مطالعه دست‌کم ۱ ساعت باشد (جلسهٔ کوتاه‌تر فقط برای مرور سریع یا وقتی واقعاً وقت نیست). دانش‌آموزی که می‌خواهد جدی بخواند باید روزی ۶ ساعت یا بیشتر درس بخواند؛ در پنجشنبه و جمعه بیشتر. این را منظم و با مهربانی یادآوری کن، مخصوصاً وقتی جلسه‌ها کوتاه‌اند یا مجموع روزش کمتر از ۶ ساعت است؛ وقتی برنامه می‌سازی جلسه‌ها را ۱ ساعته یا بیشتر بگذار، مگر خودش چیز دیگری بخواهد. زور نگو و ساعت خواب را رعایت کن.
12) روزهای هفته در availability: 0=شنبه، 1=یکشنبه، 2=دوشنبه، 3=سه‌شنبه، 4=چهارشنبه، 5=پنجشنبه، 6=جمعه.
21) «برنامهٔ امتحانی»: یک تب جداگانه که خودش ۳ هفته (۲۱ روز) پیش از نزدیک‌ترین امتحان نهایی برای پایهٔ یازدهم و دوازدهم ظاهر می‌شود (exam_prep_tab.active در CONTEXT) و فقط سه نوع جلسه دارد: خواندن تشریحی، نمونه سؤال امتحان نهایی سال‌های قبل، خلاصه‌نویسی — هیچ تست‌زنی و هیچ درسی از پایه‌های قبل در آن نیست، فقط کتاب امسال؛ و همیشه دست‌کم یک روز کامل پیش از امتحان هر درس تمام می‌شود. اگر دانش‌آموز خواست این تب زودتر ظاهر شود، فقط بپرس چند هفته یا چند روز مانده به امتحان می‌خواهد فعال شود؛ همین که عدد را گفت، خودت بی‌سروصدا با ابزار مربوطه تنظیمش کن و در یک جمله نتیجه را بگو (مثلاً «باشه، از ۴ هفته مونده بهش دسترسی داری»). ۲۱ روز کف مطلق است و کمتر نمی‌شود، فقط می‌توان زودتر (عدد بزرگ‌تر) خواستش؛ اگر عدد کمتر از ۲۱ روز خواست، همین را به زبان ساده بگو، نه با اصطلاح فنی.
   وقتی دانش‌آموز اولین‌بار وارد این تب می‌شود، خودِ اپ یک پنجرهٔ کوتاهِ اجباری نشانش می‌دهد (مدرسه‌رفتن یا نه، چند ساعت در روز، کدام درس‌ها، ساعت دقیق هر امتحان، ساعت خواب/بیداری، طول جلسه و استراحت) و جواب‌ها در exam_prep_tab (setup_done، school_during، daily_study_hours، session_len، break_len، sleep، eligible_subjects) قابل دیدن است؛ تو این پنجره را باز نمی‌کنی. اما بعد از آن، اگر دانش‌آموز در گفت‌وگو خواست چیزی از همین تنظیمات را عوض کند («امتحان ریاضی ساعت ۹ صبحه نه ۸»، «فقط شیمی و زیست بمونه»، «روزی ۸ ساعت بخونم»، «تو این بازه دیگه مدرسه نمیرم»، «جلسه‌ها رو ۴۵ دقیقه‌ای کن»)، خودت بی‌صدا با ابزار مربوطه (بخش دوم قواعد رفتار) عوضش کن، برنامه از نو ساخته می‌شود، و در یک جمله نتیجه را بگو — دیگر لازم نیست دانش‌آموز را به باز کردن دوبارهٔ آن پنجره ارجاع بدهی. اگر درسی که می‌خواهد حذف کند در exam_prep_tab.eligible_subjects نبود (یعنی اصلاً امتحان نهایی امسال ندارد)، همین را صادقانه بگو.
22) هرگز، تحت هیچ شرایطی، نام فنی توابع/ابزارهای داخلی (مثل replace_day_plan، set_exam_prep_start، set_konkur_review و بقیهٔ اسم‌های انگلیسی زیرخط‌دار در همین دستورها) را در پیامی که دانش‌آموز می‌بیند ننویس و حتی اشاره‌ای به «ابزار»، «تابع» یا «فراخوانی» به آن معنای فنی نکن. این‌ها فقط برای خودت‌اند تا کار را انجام دهی؛ برای دانش‌آموز همیشه به زبان فارسیِ ساده و طبیعی حرف بزن (مثلاً به‌جای گفتن اسم تابع، بگو «برات تنظیمش می‌کنم» یا «همین الان انجامش دادم»). اگر برای انجام کاری به یک عدد یا انتخاب از او نیاز داری (مثل چند هفته مانده)، فقط همان سؤال ساده را بپرس، بدون ذکر نام هیچ ابزاری.`;
const TOOL_DEFS=[
    {name:"set_daily_goal",description:"Set how many hours PER DAY the student wants to study, as an ongoing daily target (not just today), and rebuild the whole week to match it. Use this for requests like 'I want to study 6 hours a day' or 'make it 3 hours instead of 6'. If the current session/break rhythm and availability windows can't fit that many hours, the active-day windows are stretched automatically so the target is met exactly rather than silently studying less.",inputSchema:{type:"object",properties:{hours:{type:"number",description:"Hours per day, e.g. 6 or 4.5"}},required:["hours"]}},
    {name:"replace_day_plan",description:"Cancel the remaining plan of one day and replace it with exactly these sessions (done sessions are kept). Use for requests like 'change tonight's plan to...'. date: 'today' | 'tomorrow' | Jalali YYYY/MM/DD. Each session: subject_id, minutes, optional start 'HH:MM' (else placed after the previous one with a break), target 'final'|'konkur', optional type (e.g. 'تست‌زنی'), optional lesson (exact textbook lesson name from CONTEXT; if omitted the next lesson is filled in automatically). Validates against now, wake/bed time and overlaps; returns the new plan or an error to fix.",inputSchema:{type:"object",properties:{date:{type:"string"},note:{type:"string",description:"short Persian description of what the student asked"},sessions:{type:"array",items:{type:"object",properties:{subject_id:{type:"string"},minutes:{type:"number"},start:{type:"string"},target:{type:"string"},type:{type:"string"},lesson:{type:"string"}},required:["subject_id","minutes"]}}},required:["date","sessions"]}},
    {name:"set_day_time",description:"Set the study window of any day (start/end HH:MM) or make it a day off (off:true), then rebuild that day's plan automatically.",inputSchema:{type:"object",properties:{date:{type:"string"},start:{type:"string"},end:{type:"string"},off:{type:"boolean"}},required:["date"]}},
    {name:"set_today_time",description:"Set how many minutes the student can study TODAY (and optionally a start time HH:MM) and rebuild today's remaining plan. Completed sessions are kept. Returns the new task list.",inputSchema:{type:"object",properties:{minutes:{type:"number"},start:{type:"string"}},required:["minutes"]}},
    {name:"set_preferences",description:"Change how the student's plans are built and rebuild the whole week. All fields optional. order: hard_first|easy_first|mixed. daily_subjects: subject_ids to include every day. availability: object keyed 0..6 (0=Saturday..6=Friday) of {on:boolean,start:'HH:MM',minutes:number}. pace: steady (default; automatically lighter for grade 10 and a bit harder/denser for تجربی — do not override this default yourself) | fast (only when the student explicitly asks to move faster/harder) | easy (only when the student explicitly asks for a lighter/easier pace).",inputSchema:{type:"object",properties:{session_len:{type:"number"},break_len:{type:"number"},order:{type:"string"},max_subjects_per_day:{type:"number"},daily_subjects:{type:"array",items:{type:"string"}},notes:{type:"string"},availability:{type:"object"},pace:{type:"string",description:"easy|steady|fast"}}}},
    {name:"move_task",description:"Move a task (task_id from today or week in context) to a later day. to_date is Jalali YYYY/MM/DD.",inputSchema:{type:"object",properties:{task_id:{type:"string"},to_date:{type:"string"}},required:["task_id","to_date"]}},
    {name:"skip_task",description:"Mark one of today's tasks as skipped; its minutes become backlog spread over future days.",inputSchema:{type:"object",properties:{task_id:{type:"string"}},required:["task_id"]}},
    {name:"complete_task",description:"Mark one of today's tasks as done, optionally with actual minutes.",inputSchema:{type:"object",properties:{task_id:{type:"string"},actual_minutes:{type:"number"}},required:["task_id"]}},
    {name:"regenerate_today",description:"Rebuild today's remaining plan from current data.",inputSchema:{type:"object",properties:{}}},
    {name:"regenerate_week",description:"Rebuild the plan for today and the next 6 days from current data.",inputSchema:{type:"object",properties:{}}},
    {name:"restore_auto_plan",description:"Undo custom changes for a day and return it to Evono's automatic plan.",inputSchema:{type:"object",properties:{date:{type:"string"}},required:["date"]}},
    {name:"add_exam",description:"Add a school exam, mock exam or other exam. kind: school|mock|other. subject_id from context (optional). date Jalali YYYY/MM/DD. If it is within 3 days today's plan is rebuilt to prioritize it.",inputSchema:{type:"object",properties:{title:{type:"string"},subject_id:{type:"string"},date:{type:"string"},kind:{type:"string"}},required:["title","date","kind"]}},
    {name:"record_result",description:"Record a result. kind: practice (final-exam practice paper, score 0-20) | mock (mock Konkur percent -33..100) | official (official final score 0-20).",inputSchema:{type:"object",properties:{subject_id:{type:"string"},kind:{type:"string"},score:{type:"number"}},required:["subject_id","kind","score"]}},
    {name:"set_subject_progress",description:"Record where the student's class is in a subject's textbook. lesson_number is 1-based within the current grade book (see class_is_at). Future sessions continue from there. Rebuilds the week.",inputSchema:{type:"object",properties:{subject_id:{type:"string"},lesson_number:{type:"number"}},required:["subject_id","lesson_number"]}},
    {name:"set_subject_level",description:"Update the student's self-assessed level in a subject (1 weak .. 5 strong). Affects future plans.",inputSchema:{type:"object",properties:{subject_id:{type:"string"},level:{type:"number"}},required:["subject_id","level"]}},
    {name:"set_exam_prep_start",description:"Let the student start their «برنامهٔ امتحانی» tab (exam-prep: خواندن تشریحی + نمونه‌سؤال امتحان نهایی سال‌های قبل + خلاصه‌نویسی only — never تست and never a past grade's book) earlier than the global default of exactly 3 weeks (21 days) before their nearest امتحان نهایی. Only ever moves it EARLIER in the calendar (a bigger days_before/weeks_before number) — 21 days is the floor and cannot be reduced.",inputSchema:{type:"object",properties:{days_before:{type:"number",description:"Days before the nearest final exam to start showing the tab; must be >=21"},weeks_before:{type:"number",description:"Alternative to days_before, in weeks (e.g. 4 for 4 weeks out)"}}}},
    {name:"set_exam_prep_plan",description:"Change any part of the student's برنامهٔ امتحانی (exam-prep) setup — the same answers its one-time setup wizard collects (see exam_prep_tab in CONTEXT for current values and exam_prep_tab.eligible_subjects for valid subject_ids/current exam dates). All fields optional; only the given ones change and the exam-prep schedule (still always finishing at least 1 full day before each subject's امتحان نهایی, and still only خواندن تشریحی + نمونه‌سؤال + خلاصه‌نویسی) is rebuilt from the result immediately. Use this whenever the student wants to adjust their exam-prep plan in chat instead of reopening the wizard themselves.",inputSchema:{type:"object",properties:{school:{type:"boolean",description:"Whether the student still has school during these exam-prep weeks"},study_hours:{type:"number",description:"Hours per day to study during exam-prep, 0-16"},session_len:{type:"number",description:"Minutes per study session, 15-150"},break_len:{type:"number",description:"Minutes of rest between sessions, 0-45"},sleep:{type:"object",properties:{wake:{type:"string"},bed:{type:"string"}},description:"HH:MM wake/bed times to use during exam-prep"},subject_ids:{type:"array",items:{type:"string"},description:"Which eligible subjects stay included in the exam-prep plan (must include at least one)"},exam_times:{type:"array",items:{type:"object",properties:{subject_id:{type:"string"},time:{type:"string"}},required:["subject_id","time"]},description:"Exact HH:MM time of day of each subject's امتحان نهایی (the date itself is fixed, only the time is set here)"}}}},
    {name:"set_konkur_review",description:"Turn review of earlier grades on/off inside Konkur sessions (Konkur covers grades 10, 11 and 12) and cap how many review sessions happen per week across all subjects combined: light (max 2/week), medium (max 3/week), heavy (max 4/week). Review always stops automatically about 6 weeks before the Konkur exam so it is finished well before the exam, not still running the week of it. Rebuilds the week.",inputSchema:{type:"object",properties:{grade10:{type:"boolean"},grade11:{type:"boolean"},level:{type:"string",description:"light|medium|heavy"}}}},
    {name:"set_sleep_schedule",description:"Set wake-up and bed times (HH:MM) for school days and for weekend days (Thursday/Friday). No session is planned after bedtime minus 30 minutes. Rebuilds the week.",inputSchema:{type:"object",properties:{wake:{type:"string"},bed:{type:"string"},weekend_wake:{type:"string"},weekend_bed:{type:"string"}}}},
    {name:"set_holiday_window",description:"Set the study window (start/end HH:MM) used on days without school: summer (Tir–Shahrivar), Nowruz, and Khordad exam season. Rebuilds the week.",inputSchema:{type:"object",properties:{start:{type:"string"},end:{type:"string"}},required:["start","end"]}},
    {name:"add_session_today",description:"Put an extra session for a subject at the start of today's plan (total time stays the same; lower-priority sessions drop). bucket: final|konkur.",inputSchema:{type:"object",properties:{subject_id:{type:"string"},minutes:{type:"number"},bucket:{type:"string"}},required:["subject_id","minutes"]}},
];
function snapWeek(){const m={};weekDates().forEach(d=>{const p=S.plans[d];m[d]=p?p.tasks.map(t=>({...t})):[]});return m}
function markChanges(before,note){weekDates().forEach(d=>{const p=S.plans[d];if(!p)return;const oldT=before[d]||[];
  const newIds=new Set(p.tasks.map(t=>t.id)),oldIds=new Set(oldT.map(t=>t.id));
  const removed=oldT.filter(t=>!newIds.has(t.id)&&(t.status==="todo"||t.status==="doing"));const added=p.tasks.filter(t=>!oldIds.has(t.id));
  if(!removed.length&&!added.length)return;
  added.forEach(t=>t.fromChange=true);
  p.change={note:String(note||"").slice(0,200),at:Date.now(),cancelled:removed.map(t=>({...t,status:"cancelled",fromChange:false})).concat((p.change&&p.change.cancelled)||[]).slice(0,16)};p.custom=true;})}
function restorePrev(dateIso){const p=S.plans[dateIso];if(!p||!p.change)return;const keep=p.tasks.filter(t=>t.status==="done"||t.status==="skipped"||t.status==="doing");
  const back=p.change.cancelled.filter(t=>!(dateIso===todayIso()&&t.start+t.minutes<=nowMin())).map(t=>({...t,status:"todo"}));
  p.tasks=[...keep,...back.filter(b=>!keep.some(k=>b.start<k.start+k.minutes&&k.start<b.start+b.minutes))].sort((a,b)=>a.start-b.start);p.change=null;save()}
function runAction(name,args,log){
  try{const r=ACT[name](args||{});log.push({ok:true,text:r.message});return r}
  catch(e){log.push({ok:false,text:e.message});throw e}
}
const CHANGE_RX=/(عوض|تغییر|جابه|جا ?به|منتقل|حذف|اضافه|بذار|بگذار|کم ?کن|زیاد ?کن|کنسل|لغو|امشب|وقت ندارم|نمی‌تونم|نمی‌توانم|بیدار|بخوابم|خواب|برنامه(‌| )?(ی|ٔ)? ?(امروز|فردا|شنبه|یکشنبه|دوشنبه|سه‌شنبه|چهارشنبه|پنجشنبه|جمعه))/;
/* Anthropic's Messages API wants {name, description, input_schema}; TOOL_DEFS use `inputSchema` (this
   app's own naming, unchanged from before) so this just renames the field for the wire. */
const toApiTools=defs=>defs.map(t=>({name:t.name,description:t.description,input_schema:t.inputSchema}));
async function aiChat(messages,system,maxTokens,signal){
  return api("/api/ai/chat",{method:"POST",body:{messages,system,maxTokens},signal});
}
async function aiChatWithTools(messages,system,tools,signal){
  return api("/api/ai/chat-with-tools",{method:"POST",body:{messages,system,tools},signal});
}
const AI_ERR_FA={network_error:"سرورهای Evono در دسترس نیستند؛ اتصال اینترنت را بررسی کن.",ai_call_failed:"خطا در ارتباط با سرور EvonoAI. کمی بعد دوباره امتحان کن.",not_authenticated:"نشستت منقضی شده؛ دوباره وارد شو.",invalid_token:"نشستت منقضی شده؛ دوباره وارد شو.",cancelled:"متوقف شد."};
async function sendAI(text){
  if(aiBusy||!text.trim())return;
  if(!aiAllowed()){paywall();return}
  const userText=text.trim();S.chat.push({role:"user",content:userText});aiBusy=true;render();
  const box=$("#msgs");const bubble=document.createElement("div");bubble.className="msg a thinking";box.appendChild(bubble);box.scrollTop=box.scrollHeight;
  const t0=Date.now();let thinkLabel="EvonoAI در حال فکر کردن…";const setThinking=()=>{bubble.innerHTML=`${thinkLabel}<span class="think-t">${fa(Math.round((Date.now()-t0)/1000))} ثانیه</span>`};setThinking();
  const thinkTimer=setInterval(()=>{if(bubble.classList.contains("thinking"))setThinking()},1000);
  const actLog=[];aiCtl=new AbortController();const before=snapWeek();
  const apiTools=toApiTools(TOOL_DEFS);
  /* Runs the agentic tool-use loop client-side (the backend's /api/ai/chat-with-tools makes exactly one
     model call per request — see backend/src/routes/ai.js): call the model, and while it comes back
     asking to use a tool, execute that tool ourselves against local app state (ACT/runAction — the same
     functions the old in-artifact sample({tools}) call invoked automatically) and send the result back
     as a tool_result, until it replies with plain text. */
  const call=async(extraTurns)=>{
    const hist=S.chat.slice(-8).map(m=>({role:m.role,content:m.content.slice(0,1200)}));if(extraTurns)hist.push(...extraTurns);
    let msgs=[{role:"user",content:"CONTEXT (JSON):\n"+aiContext()+"\n\n— پایان دستورها. گفت‌وگو از اینجا شروع می‌شود —"},...hist];
    for(let loop=0;loop<6;loop++){
      const result=await aiChatWithTools(msgs,AI_RULES,apiTools,aiCtl.signal);
      if(result.text){bubble.classList.remove("thinking");bubble.innerHTML=md(result.text);box.scrollTop=box.scrollHeight}
      if(!result.toolUse||!result.toolUse.length)return result.text;
      thinkLabel="در حال اعمال تغییر در برنامه…";bubble.classList.add("thinking");setThinking();
      msgs.push({role:"assistant",content:(result.raw&&result.raw.content)||[]});
      const toolResults=result.toolUse.map(tu=>{
        try{const r=runAction(tu.name,tu.input,actLog);return{type:"tool_result",tool_use_id:tu.id,content:JSON.stringify(r)}}
        catch(e){return{type:"tool_result",tool_use_id:tu.id,content:JSON.stringify({error:e.message}),is_error:true}}
      });
      msgs.push({role:"user",content:toolResults});
    }
    return "";
  };
  try{
    let reply=await call(null);
    if(CHANGE_RX.test(userText)&&!actLog.some(a=>a.ok)){
      thinkLabel="برنامه هنوز تغییر نکرده؛ در حال اعمال تغییر…";bubble.classList.add("thinking");setThinking();
      reply=await call([{role:"assistant",content:reply||"…"},{role:"user",content:"[پیام سیستم Evono، نه دانش‌آموز] در پاسخ قبلی هیچ ابزاری با موفقیت اجرا نشد"+(actLog.length?" (خطاها: "+actLog.map(a=>a.text).join("؛ ")+")":"")+" و برنامه تغییر نکرد. اگر دانش‌آموز تغییری در برنامه خواسته، همین حالا با ابزار مناسب (معمولاً replace_day_plan یا set_day_time) انجامش بده، خطاها را اصلاح کن و بعد برنامهٔ جدید را مرتب نشان بده. اگر واقعاً تغییری نخواسته بود، فقط به سؤالش جواب بده."}]);
    }
    markChanges(before,userText);
    S.chat.push({role:"assistant",content:reply||"…",actions:actLog});useAI();
    if(actLog.some(a=>a.ok))toast("برنامه به‌روز شد ✓");
  }catch(e){
    markChanges(before,userText);
    const msg=(e&&AI_ERR_FA[e.code])||"خطا در ارتباط با سرور؛ دوباره امتحان کن.";
    S.chat.push({role:"assistant",content:msg,actions:actLog});
  }finally{clearInterval(thinkTimer);aiBusy=false;aiCtl=null;save();render();const m=$("#msgs");if(m)m.scrollTop=m.scrollHeight}
}

/* ---------- Daily report + screen time ---------- */
function renderReport(){
  const d=todayIso();const r=S.reports.find(x=>x.date===d)||{};const p=S.plans[d];
  const doneMin=p?p.tasks.filter(t=>t.status==="done").reduce((a,t)=>a+(t.actual||t.minutes),0):0;
  const apps=[["instagram","اینستاگرام"],["youtube","یوتیوب"],["telegram","تلگرام"],["games","بازی"],["other","سایر"]];
  return `<div class="grid g-main"><form class="card stack" id="rep">
    <div class="card-h"><div><h2>گزارش روزانه</h2><p class="small muted">${jLabel(d)}</p></div>${r.date?'<span class="pill p-good">ثبت شده</span>':""}</div>
    <div class="fgrid">${hmInput("r-min",r.minutes??doneMin,"امروز چقدر درس خواندی؟")}
    <label class="field"><span>انرژی (۱ تا ۵)</span><input type="text" inputmode="numeric" data-pfa id="r-en" maxlength="1" value="${faStr(r.energy??3)}"></label>
    <label class="field"><span>تمرکز (۱ تا ۵)</span><input type="text" inputmode="numeric" data-pfa id="r-fo" maxlength="1" value="${faStr(r.focus??3)}"></label></div>
    <label class="field"><span>چه چیزی سخت بود یا نفهمیدید؟</span><textarea id="r-hard" placeholder="مثلاً: ۷۰ دقیقه ریاضی خواندم ولی بیشتر سؤال‌ها را حل نکردم">${esc(r.hard||"")}</textarea></label>
    <label class="field"><span>یادداشت</span><textarea id="r-note">${esc(r.note||"")}</textarea></label>
    <h3 style="margin-top:6px">زمان استفاده از گوشی</h3>
    <div class="fgrid">${apps.map(([k,l])=>hmInput("st-"+k,(r.screen&&r.screen[k])||0,l)).join("")}</div>
    <div class="row"><button class="btn primary" type="submit">ثبت گزارش</button><button class="btn" type="button" data-act="analyze">تحلیل با <b class='brand-word'>EvonoAI</b></button></div>
    ${S.insights[d]?`<div><span class="label">تحلیل <b class='brand-word'>EvonoAI</b></span><div class="ai-out" style="margin-top:6px">${esc(S.insights[d])}</div></div>`:""}
  </form>
  <aside class="stack"><section class="card"><h3>گزارش‌های اخیر</h3>${S.reports.slice(-7).reverse().map(x=>`<div style="padding:8px 0;border-top:1px solid var(--line)"><div class="row" style="justify-content:space-between"><b class="small">${jLabel(x.date)}</b><span class="small num">${durLabel(x.minutes)} درس | ${durLabel(x.screenTotal||0)} گوشی</span></div>${x.hard?`<p class="small muted">${esc(x.hard)}</p>`:""}</div>`).join("")||'<p class="small muted">هنوز گزارشی ثبت نشده.</p>'}</section></aside></div>`;
}

/* ---------- Results ---------- */
function renderResults(){
  const g=S.profile.grade;
  const showG11=(g==="12"||g==="grad");
  return `<div class="stack">
  ${showG11?`<section class="card"><div class="card-h"><div><h2>نمره‌های رسمی امتحان نهایی پایه یازدهم</h2><p class="small muted">این نمره‌ها بخشی از سوابق تحصیلی شما در کنکور هستند.</p></div><span class="pill p-final num">معدل ${fa2(avgScores())}</span></div>
    <div class="fgrid">${S.subjects.filter(s=>s.names[1]).map(s=>{const cancelled=!!(S.finalExcluded&&S.finalExcluded[s.id]);return `<label class="field"><span>${esc(s.names[1])}</span><input type="text" inputmode="decimal" data-pfa="dec" data-fs="${s.id}" value="${S.finalScores[s.id]!=null?faStr(S.finalScores[s.id]):""}" placeholder="از ۲۰" ${cancelled?"disabled":""}><label class="row small" style="margin-top:4px;gap:6px"><input type="checkbox" data-fx="${s.id}" ${cancelled?"checked":""} onchange="this.closest('.field').querySelector('input[data-fs]').disabled=this.checked"> <span class="tiny muted">لغو شد</span></label></label>`}).join("")}</div>
    <div class="row" style="margin-top:10px"><button class="btn primary" data-act="savefs">ذخیرهٔ نمره‌ها</button>${g==="grad"?`<label class="row small"><input type="checkbox" id="retake" ${S.profile.retake?"checked":""}> برای ترمیم معدل برنامه‌ریزی کن</label>`:""}</div></section>`:""}
  <div class="grid g-main">
  <section class="card"><div class="card-h"><h2>ثبت نتیجه</h2></div>
    <form class="fgrid" id="resf"><label class="field"><span>درس</span><select id="rs-sub">${S.subjects.map(s=>`<option value="${s.id}">${esc(subName(s.id))}</option>`).join("")}</select></label>
    <label class="field"><span>نوع</span><select id="rs-kind"><option value="practice">نمونه‌سؤال نهایی (از ۲۰)</option><option value="mock">آزمون آزمایشی کنکور (درصد)</option><option value="official">نمرهٔ رسمی نهایی (از ۲۰)</option></select></label>
    <label class="field"><span>نمره / درصد</span><input type="text" inputmode="decimal" data-pfa="dec" id="rs-score"></label>
    <div class="field" style="justify-content:flex-end"><button class="btn primary">ثبت</button></div></form>
    <div class="tscroll" style="margin-top:14px"><table><thead><tr><th>تاریخ</th><th>درس</th><th>نوع</th><th>نتیجه</th></tr></thead><tbody>
    ${S.results.slice(-15).reverse().map(r=>`<tr><td class="num">${jShort(r.date)}</td><td>${esc(subName(r.subjectId))}</td><td>${r.kind==="mock"?'<span class="pill p-konkur">آزمایشی</span>':r.kind==="official"?'<span class="pill p-good">رسمی</span>':'<span class="pill p-final">تمرین نهایی</span>'}</td><td class="num">${fa(r.score)}${r.kind==="mock"?"٪":" / ۲۰"}</td></tr>`).join("")||'<tr><td colspan="4" class="muted">هنوز نتیجه‌ای ثبت نشده.</td></tr>'}
    </tbody></table></div></section>
  <section class="card"><div class="card-h"><h2>امتحان‌ها</h2></div>
    <form class="stack" id="exf"><div class="fgrid"><label class="field"><span>عنوان</span><input type="text" id="ex-title" placeholder="میان‌ترم شیمی"></label>
    <label class="field"><span>تاریخ (شمسی)</span><input type="text" id="ex-date" placeholder="1405/08/15" inputmode="numeric"></label></div>
    <div class="fgrid"><label class="field"><span>درس</span><select id="ex-sub"><option value="">—</option>${S.subjects.map(s=>`<option value="${s.id}">${esc(subName(s.id))}</option>`).join("")}</select></label>
    <label class="field"><span>نوع</span><select id="ex-kind"><option value="school">امتحان مدرسه</option><option value="mock">آزمون آزمایشی</option><option value="other">سایر</option></select></label></div>
    <button class="btn primary" style="align-self:flex-start">افزودن امتحان</button></form>
    <div style="margin-top:12px">${upcoming().map(e=>`<div class="row" style="justify-content:space-between;padding:6px 0;border-top:1px solid var(--line)"><div><b class="small">${esc(e.title)}</b><div class="small muted">${jLabel(e.date)}${e.estimated?" | تخمینی":""}</div></div><div class="row"><span class="small num">${fa(daysUntil(e.date))} روز</span>${["school","mock","other"].includes(e.kind)?`<button class="btn sm ghost" data-delex="${e.id}" aria-label="حذف">حذف</button>`:""}</div></div>`).join("")}</div>
  </section></div></div>`;
}

/* ---------- Weekly review ---------- */
function weekData(){
  const days=[];for(let i=6;i>=0;i--){const d=todayD()-i;const iso=isoFromD(d);const p=S.plans[iso];
    const planned=p?p.tasks.reduce((a,t)=>a+t.minutes,0):0;const done=S.log.filter(x=>x.date===iso&&x.status==="done").reduce((a,x)=>a+x.minutes,0);
    const rep=S.reports.find(r=>r.date===iso);days.push({iso,label:WD[wdIdx(d)],planned,done,screen:rep?rep.screenTotal||0:null})}
  return days;
}
function renderReview(){
  const days=weekData();const P=days.reduce((a,d)=>a+d.planned,0),D=days.reduce((a,d)=>a+d.done,0);
  const log=S.log.filter(x=>x.date>=days[0].iso&&x.status==="done");
  const bySub={};log.forEach(l=>bySub[l.subjectId]=(bySub[l.subjectId]||0)+l.minutes);
  const fin=log.filter(l=>l.bucket==="final").reduce((a,l)=>a+l.minutes,0),kon=D-fin;
  const ph=phase();
  const maxH=Math.max(1,Math.ceil(Math.max(...days.map(d=>Math.max(d.planned,d.done)))/60));const step=maxH<=2?0.5:maxH<=6?1:2;const top=Math.ceil(maxH/step)*step;const max=top*60;
  const W=680,H=240,pr=64,pl=10,pb=34,pt=12,bw=(W-pr-pl)/7;
  const y=v=>H-pb-(v/max)*(H-pb-pt);
  const ticks=[];for(let v=0;v<=top+1e-9;v+=step)ticks.push(v*60);
  const tickLbl=m=>m===0?"۰ ساعت":durLabel(Math.round(m));
  const xOf=i=>W-pr-(i+1)*bw; /* right-to-left: oldest day on the right, today on the left end */
  const svg=`<svg viewBox="0 0 ${W} ${H}" role="img" aria-label="ساعت‌های برنامه‌ریزی‌شده و انجام‌شده در ۷ روز اخیر" style="direction:ltr"><defs><linearGradient id="silv" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#F4F6F8"/><stop offset="1" stop-color="#8E959E"/></linearGradient></defs>
    ${ticks.map(t=>`<line x1="${pl}" x2="${W-pr+4}" y1="${y(t)}" y2="${y(t)}" stroke="var(--line)" stroke-width="1"/><text x="${W-pr+10}" y="${y(t)+4}" font-size="11.5" text-anchor="start" direction="rtl" fill="var(--muted)">${tickLbl(t)}</text>`).join("")}
    ${days.map((d,i)=>{const cx=xOf(i)+bw/2,w=Math.min(26,bw*0.3);return `<g><title>${d.label}: برنامه ${durLabel(d.planned)}، انجام ${durLabel(d.done)}</title>
      <rect x="${xOf(i)}" y="${pt}" width="${bw}" height="${H-pb-pt}" fill="transparent"/>
      <rect class="b" x="${cx+1}" y="${y(d.planned)}" width="${w}" height="${Math.max(0,H-pb-y(d.planned))}" rx="4" fill="var(--planned)"/>
      <rect class="b" style="animation-delay:${i*50+100}ms" x="${cx-w-1}" y="${y(d.done)}" width="${w}" height="${Math.max(0,H-pb-y(d.done))}" rx="4" fill="url(#silv)"/>
      <text x="${cx}" y="${H-12}" font-size="12" text-anchor="middle" direction="rtl" fill="${i===6?"var(--ink)":"var(--muted)"}" font-weight="${i===6?700:400}">${i===6?"امروز":d.label}</text></g>`}).join("")}
  </svg>`;
  const scr=days.filter(d=>d.screen!=null);
  return `<div class="stack">
  <section class="card"><div class="card-h"><h2>هفتهٔ اخیر</h2><span class="small muted">${jLabel(days[0].iso)} تا ${jLabel(days[6].iso)}</span></div>
    <div class="stats"><div class="stat"><span class="label">درس خوانده‌شده</span><b class="num">${durLabel(D)}</b></div>
    <div class="stat"><span class="label">برنامه‌ریزی‌شده</span><b class="num">${durLabel(P)}</b></div>
    <div class="stat"><span class="label">درصد انجام</span><b class="num">${P?fa(Math.round(D/P*100)):"—"}٪</b></div>
    <div class="stat"><span class="label">میانگین گوشی</span><b class="num">${scr.length?durLabel(Math.round(scr.reduce((a,d)=>a+d.screen,0)/scr.length)):"—"}</b><span class="small muted">در روز (از گزارش‌ها)</span></div></div>
    <div class="chart" style="margin-top:16px">${svg}</div>
    <div class="legend"><span><i style="background:var(--planned)"></i>برنامه</span><span><i style="background:var(--accent)"></i>انجام‌شده</span></div>
  </section>
  <div class="grid g-main">
  <section class="card"><div class="card-h"><h2>تقسیم زمان</h2></div>
    <p class="small">واقعی: ${S.profile.grade==="10"?"مدرسه":"نهایی"} ${D?fa(Math.round(fin/D*100)):"۰"}٪ | کنکور ${D?fa(Math.round(kon/D*100)):"۰"}٪ — هدف فاز «${esc(ph.label)}»: ${fa(Math.round(ph.finals*100))}٪ / ${fa(100-Math.round(ph.finals*100))}٪</p>
    <div class="stack" style="margin-top:12px;gap:8px">${Object.entries(bySub).sort((a,b)=>b[1]-a[1]).map(([id,m])=>`<div><div class="row small" style="justify-content:space-between"><span>${esc(subName(id))}</span><span class="num">${durLabel(m)}</span></div><div class="bar"><i style="width:${Math.round(m/Math.max(...Object.values(bySub))*100)}%;background:var(--accent)"></i></div></div>`).join("")||'<p class="small muted">این هفته هنوز جلسه‌ای انجام نشده.</p>'}</div>
  </section>
  <section class="card"><div class="card-h"><h2><span class="ai-mark">Evono<i>AI</i></span> مرور هفته</h2><button class="btn sm primary" data-act="weekly">ساخت مرور هفته</button></div>
    ${S.insights["week-"+todayIso()]?`<div class="ai-out">${esc(S.insights["week-"+todayIso()])}</div>`:`<p class="small muted"><b class='brand-word'>EvonoAI</b> آمار این هفته، نتایج و امتحان‌های پیش رو را بررسی می‌کند و اولویت‌های هفتهٔ بعد را می‌گوید.</p>`}
  </section></div></div>`;
}

/* ---------- Settings ---------- */
function fmtWhen(ms){const dt=new Date(ms);const dn=g2d(dt.getFullYear(),dt.getMonth()+1,dt.getDate());const j=d2j(dn);
  const hh=String(dt.getHours()).padStart(2,"0"),mm=String(dt.getMinutes()).padStart(2,"0");
  return `${fa(j.jd)} ${JM[j.jm-1]} ${faStr(j.jy)} — ساعت ${faStr(hh)}:${faStr(mm)}`}
function txStatusLabel(x){
  if(x.status==="success")return{text:"تراکنش موفق",cls:"ok"};
  if(x.status==="failed")return{text:x.reason?`تراکنش ناموفق — ${x.reason}`:"تراکنش ناموفق",cls:"fail"};
  if(x.status==="canceled")return{text:"لغو شده توسط کاربر",cls:"fail"};
  return{text:"در انتظار تکمیل پرداخت",cls:"pending"};
}
function txHistory(){
  const rows=[];
  (S.intents||[]).forEach(x=>{const p=PLANS.find(pl=>pl.id===x.plan);const st=txStatusLabel(x);
    const amt=x.amount!=null?x.amount:(p?p.amount:null);
    rows.push({at:x.at,order:x.order?`#${faStr(x.order)}`:"—",title:(p?`خرید اشتراک ${p.name}`:"خرید اشتراک")+(x.discLabel?` (${x.discLabel})`:""),amount:amt!=null?`${fa(amt)} تومان`:"—",status:st.text,statusClass:st.cls})});
  return rows.sort((a,b)=>b.at-a.at);
}
function renderProfile(){
  const pr=S.profile;const tx=txHistory();
  return `<div class="stack">
  <section class="card stack">
    <div class="row" style="align-items:center;gap:16px">
      <div class="avatar">${pr.avatar?`<img src="${pr.avatar}" alt="">`:esc((pr.name||"؟").trim().charAt(0)||"؟")}<span class="chg">تغییر عکس</span><input type="file" accept="image/*" id="pf-avatar" title="تغییر عکس پروفایل" style="position:absolute;inset:0;opacity:0;cursor:pointer"></div>
      <div><h2 style="margin:0">${esc(pr.name||"—")}</h2><p class="small muted" style="margin-top:2px">${({"10":"پایه دهم","11":"پایه یازدهم","12":"پایه دوازدهم","grad":"دانش‌آموخته / پشت‌کنکوری"})[pr.grade]} • ${esc(CATALOG[pr.field].label)} • کنکور ${faStr(pr.konkurYear)}</p>${pr.avatar?`<button type="button" class="linkbtn small" data-act="rmavatar" style="margin-top:4px">حذف عکس</button>`:""}</div></div>
  </section>
  <section class="card stack"><h2>جزئیات حساب</h2>
    <div class="fgrid">
      <label class="field"><span>نام</span><input type="text" id="pf-name" value="${esc(pr.name)}" disabled></label>
      <label class="field"><span>شماره موبایل</span><input type="text" dir="ltr" value="${pr.phone?esc(fmtPhone(pr.phone)):"ثبت نشده"}" disabled></label>
    </div>
    <p class="small muted">برای تغییر نام یا شماره موبایل با پشتیبانی تماس بگیرید.</p>
    <div class="row"><button class="btn primary" data-act="saveprofile">ذخیره</button><button class="btn ghost" data-act="logout">خروج از حساب</button></div>
  </section>
  <section class="card stack"><h2>ظاهر</h2><p class="small muted">تم نمایش اپ را انتخاب کن.</p>
    <div class="theme-grid">${THEMES.map(([id,label])=>`<button type="button" class="theme-opt t-${id}" data-theme-pick="${id}" aria-pressed="${(pr.theme||"silver")===id}"><span class="sw"><i></i><i></i><i></i></span><span class="tl">${label}</span></button>`).join("")}</div>
  </section>
  <section class="card stack"><h2>تنظیمات برنامهٔ مطالعه</h2><p class="small muted">برای خواب, بیداری, روزهای هفته و فصل‌ها به بخش تنظیمات کامل برو.</p>
    <div class="fgrid">${hmInput("pf-len",pr.sessionLen,"طول هر جلسه")}${hmInput("pf-brk",pr.breakLen,"استراحت بین جلسه‌ها")}</div>
    <div class="stack" style="margin-top:6px"><span class="label">چند ساعت در روز می‌خواهی درس بخوانی؟</span>
      <div class="lvl">${[3,4,5,6,7,8].map(h=>`<button type="button" data-pfhrs="${h}" aria-pressed="${Math.round((pr.dailyGoal||240)/60)===h}">${fa(h)}</button>`).join("")}</div>
      ${Math.round((pr.dailyGoal||240)/60)<5?`<p class="small muted">پیشنهاد Evono برای ${({"10":"پایه دهم","11":"پایه یازدهم","12":"پایه دوازدهم","grad":"پشت‌کنکوری"})[pr.grade]}${pr.field==="tajrobi"?" (تجربی)":""}: ${fa(recommendedHours(pr.grade,pr.field))} ساعت در روز.</p>`:""}</div>
    <div class="stack" style="margin-top:6px"><span class="label">سرعت پیشروی فصل‌های چندبخشی</span>
      <div class="seg">${[["easy","آسان‌تر"],["steady","معمولی و کنترل‌شده"],["fast","سریع‌تر"]].map(([v,l])=>`<label><input type="radio" name="pf-pace" value="${v}" ${(S.prefs.pace||"steady")===v?"checked":""}><span>${l}</span></label>`).join("")}</div>
      <p class="small muted">معمولی یک فصل چندبخشی را در یک هفته تمام نمی‌کند؛ برای پایه دهم به‌طور پیش‌فرض آرام‌تر و برای رشتهٔ تجربی کمی فشرده‌تر تنظیم شده. اگر می‌خواهی سریع‌تر یا آسان‌تر جلو بروی، از گزینه‌های بالا انتخاب کن.</p></div>
    <div class="row"><button class="btn primary" data-act="saveprofile">ذخیره</button><button class="btn ghost" data-act="opensettings">تنظیمات کامل (خواب، روزهای هفته، فصل‌ها) ←</button></div>
  </section>
  <section class="card stack"><h2>اشتراک</h2>
    <div class="sub-card${subActive()?" active":""}">
    ${subActive()?`<div class="row" style="justify-content:space-between;align-items:center;flex-wrap:wrap;gap:10px 14px"><div class="row" style="align-items:center;gap:8px;flex-wrap:wrap"><h3 style="margin:0">اشتراک <b>${esc((PLANS.find(x=>x.id===subPlan())||{}).name||"")}</b> فعال است</h3>${S.sub.demo?'<span class="pill">آزمایشی</span>':""}</div><span class="active-sub"><span class="dot" aria-hidden="true"></span><b>اشتراک شما</b></span></div>
      <p class="small muted">تا ${faDateMs(S.sub.until)} ادامه دارد${aiQuota()?` | ${fa(aiLeft())} از ${fa(aiQuota())} پیام <b class='brand-word'>EvonoAI</b> ${periodLabel()} باقی مانده`:" پیام <b class='brand-word'>EvonoAI</b> بدون سقف"}.</p>
      ${subQueue().map((planId,i)=>`<p class="small muted" style="margin-top:6px">اشتراک بعدی: <b>${esc((PLANS.find(x=>x.id===planId)||{}).name||"")}</b> — از <b>${faDateMs(queueSlotStart(i))}</b> شروع می‌شود.</p>`).join("")}`
      :`<h3 style="margin:0 0 6px">${subLapsed()?"اشتراکت تمام شده؛ برای ادامهٔ <b class='brand-word'>EvonoAI</b> تمدید کن":"برای استفاده از <b class='brand-word'>EvonoAI</b> یکی از اشتراک‌ها را بخر"}</h3>`}
    <div class="row" style="margin-top:14px"><button class="btn primary" data-goto="plans">${subActive()?"مدیریت اشتراک":"خرید اشتراک"} ←</button></div>
    </div>
  </section>
  <section class="card stack"><h2>تاریخچهٔ تراکنش‌ها</h2>
    ${tx.length?`<div class="tscroll"><table><thead><tr><th>تاریخ</th><th>سفارش</th><th>شرح</th><th>مبلغ</th><th>وضعیت</th></tr></thead><tbody>${(TX_EXPANDED?tx:tx.slice(0,5)).map(x=>`<tr><td class="small num">${fmtWhen(x.at)}</td><td class="small num">${esc(x.order)}</td><td>${esc(x.title)}</td><td class="num">${esc(x.amount)}</td><td><span class="tx-status ${x.statusClass}">${esc(x.status)}</span></td></tr>`).join("")}</tbody></table></div>
    ${tx.length>5?(TX_EXPANDED?`<button class="btn sm" data-act="txless" style="align-self:center">نمایش کمتر</button>`:`<button class="btn sm" data-act="txmore" style="align-self:center">نمایش بیشتر</button>`):""}`
      :`<p class="small muted">هنوز تراکنشی ثبت نشده.</p>`}
  </section>
  </div>`;
}
function renderSettings(){
  const pr=S.profile;
  return `<div class="stack">
  <section class="card stack"><h2>پروفایل</h2>
    <div class="fgrid"><label class="field"><span>نام</span><input type="text" id="s-name" value="${esc(pr.name)}" disabled></label>
    <label class="field"><span>پایه</span><select id="s-grade" disabled>${[["10","دهم"],["11","یازدهم"],["12","دوازدهم"],["grad","دانش‌آموخته / پشت‌کنکوری"]].map(([v,l])=>`<option value="${v}" ${pr.grade===v?"selected":""}>${l}</option>`).join("")}</select></label>
    <label class="field"><span>رشته</span><select id="s-field" disabled>${Object.entries(CATALOG).map(([k,v])=>`<option value="${k}" ${pr.field===k?"selected":""}>${v.label}</option>`).join("")}</select></label>
    <label class="field"><span>سال کنکور</span><input type="text" inputmode="numeric" data-pfa id="s-k" value="${faStr(pr.konkurYear)}" disabled></label>
    ${hmInput("s-len",pr.sessionLen,"طول هر جلسه")}${hmInput("s-brk",pr.breakLen,"استراحت بین جلسه‌ها")}</div>
    <p class="small muted">نام، پایه، رشته و سال کنکور بعد از تنظیم اولیه قابل تغییر نیستند. برای تغییر نام با پشتیبانی تماس بگیر؛ برای پایه/رشته/سال کنکور از «شروع دوباره از اول» استفاده کن.</p>
    <div class="stack" style="margin-top:6px"><span class="label">چند ساعت در روز می‌خواهی درس بخوانی؟</span>
      <div class="lvl">${[3,4,5,6,7,8].map(h=>`<button type="button" data-s-hrs="${h}" aria-pressed="${Math.round((pr.dailyGoal||240)/60)===h}">${fa(h)}</button>`).join("")}</div>
      ${Math.round((pr.dailyGoal||240)/60)<5?`<p class="small muted">پیشنهاد Evono برای ${({"10":"پایه دهم","11":"پایه یازدهم","12":"پایه دوازدهم","grad":"پشت‌کنکوری"})[pr.grade]}${pr.field==="tajrobi"?" (تجربی)":""}: ${fa(recommendedHours(pr.grade,pr.field))} ساعت در روز.</p>`:""}</div>
  </section>
  <section class="card stack"><h2>خواب و بیداری</h2><p class="small muted">ساعت‌ها ۲۴ساعته‌اند. هیچ جلسه‌ای دیرتر از ۳۰ دقیقه قبل از ساعت خواب برنامه‌ریزی نمی‌شود.</p>
    <div class="fgrid"><div class="field"><span>بیداری — روزهای مدرسه</span>${tp("sl-wake",S.sleep.wake)}</div><div class="field"><span>خواب — روزهای مدرسه</span>${tp("sl-bed",S.sleep.bed)}</div>
    <div class="field"><span>بیداری — روزهای تعطیل</span>${tp("sl-wake2",S.sleep.wakeOff)}</div><div class="field"><span>خواب — روزهای تعطیل</span>${tp("sl-bed2",S.sleep.bedOff)}</div></div></section>
  <section class="card stack"><h2>زمان درس خواندن در روزهای مدرسه</h2><p class="small muted">از مهر تا اردیبهشت. پنجشنبه و جمعه معمولاً مدرسه تعطیل است.</p>
    <div class="tscroll"><table class="avtable"><thead><tr><th>روز</th><th>فعال</th><th>از ساعت</th><th>تا ساعت</th><th>مدت</th></tr></thead><tbody>
    ${WD.map((w,i)=>{const a=S.availability[i];return `<tr><td>${w}</td><td><input type="checkbox" data-av-on="${i}" ${a.on?"checked":""} aria-label="${w} فعال"></td><td>${tp("av-s-"+i,a.start)}</td><td>${tp("av-e-"+i,a.end)}</td><td class="small num" id="avd-${i}">${durCell(a.start,a.end)}</td></tr>`}).join("")}
    </tbody></table></div></section>
  <section class="card stack"><h2>تابستان، نوروز و فصل امتحانات</h2><p class="small muted">وقتی مدرسه تعطیل است (تیر تا شهریور، تعطیلات نوروز و خرداد که کلاس عادی نیست)، Evono از این بازه استفاده می‌کند و صبح‌ها هم برنامه می‌گذارد.</p>
    <div class="fgrid"><div class="field"><span>از ساعت</span>${tp("hol-s",S.holiday.start)}</div><div class="field"><span>تا ساعت</span>${tp("hol-e",S.holiday.end)}</div><div class="field"><span>مدت</span><b class="num" id="hold" style="padding-top:8px">${durCell(S.holiday.start,S.holiday.end)}</b></div></div></section>
  <section class="card stack"><h2>یادآورها</h2><p class="small muted">وقتی Evono باز است، سر وقت صدای زنگ و پیام نشان داده می‌شود؛ اگر مرورگر اجازه دهد، اعلان سیستم هم می‌آید. وضعیت اعلان: <b>${notifState()}</b></p>
    <p class="tiny muted">نکته: زیر عنوان اعلان سیستم، مرورگر یک آدرس فنی نشان می‌دهد (نه بخشی از پیام Evono) — این را خود مرورگر برای امنیت اضافه می‌کند و قابل حذف نیست.</p>
    <div class="remind-list">${[["session","شروع هر جلسه"],["pre","۵ دقیقه قبل از هر جلسه"],["wake","صبح بخیر و برنامهٔ امروز (ساعت بیداری)"],["report","ثبت گزارش بعد از تمام شدن برنامهٔ امشب"],["bed","وقت خواب (۳۰ دقیقه قبل)"]].map(([k,l])=>`<label><span>${l}</span><input type="checkbox" data-rem="${k}" ${S.remind[k]!==false?"checked":""}></label>`).join("")}</div>
    <div class="row"><button class="btn" data-notif="1">فعال‌کردن اعلان‌ها</button><button class="btn ghost" data-testrem="1">پخش یادآور آزمایشی</button></div></section>

  <section class="card stack"><h2>درس‌ها و فصل‌ها</h2><p class="small muted">خودارزیابی ۱ (ضعیف) تا ۵ (قوی)، و اینکه کلاست در هر کتاب به کجا رسیده. Evono جلسه‌ها را درس‌به‌درس از همین نقطه جلو می‌برد. هر درس را هر وقت خواستی می‌توانی از برنامه‌ریزی کنار بگذاری — پیشرفتت در آن حفظ می‌شود و هر وقت خواستی می‌توانی برش‌گردانی.</p>
    <div class="tscroll"><table><thead><tr><th>درس</th><th>سطح</th><th>کلاس به کجا رسیده</th><th>فهرست فصل‌ها</th><th>اهمیت در کنکور</th><th>در برنامه‌ریزی</th></tr></thead><tbody>
    ${S.subjects.map(s=>`<tr class="${s.off?"sub-off":""}"><td>${esc(subName(s.id))}${s.off?'<br><span class="badge ghost" style="margin-top:4px">حذف‌شده از برنامه</span>':""}</td><td><div class="lvl">${[1,2,3,4,5].map(l=>`<button type="button" data-lvl="${s.id}:${l}" aria-pressed="${s.level===l}" ${s.off?"disabled":""}>${fa(l)}</button>`).join("")}</div></td><td>${(()=>{const L=finalLessons(s);if(!L.length)return '<span class="small muted">—</span>';const P=prog(s);return `<select data-pos="${s.id}" style="max-width:260px" ${s.off?"disabled":""}>${L.map((l,ix)=>`<option value="${ix}" ${ix===Math.min(P.f,L.length-1)?"selected":""}>${esc(l)}</option>`).join("")}${`<option value="${L.length}" ${P.f>=L.length?"selected":""}>کتاب تمام شده (مرور)</option>`}</select>`})()}</td><td><button type="button" class="btn sm ghost" data-editcurr="${s.id}">ویرایش</button></td><td><input type="text" inputmode="decimal" data-pfa="dec" data-kw="${s.id}" value="${faStr(s.kw)}" style="max-width:80px" ${s.off?"disabled":""}></td><td><button type="button" class="btn sm ${s.off?"primary":"ghost"}" data-toggleoff="${s.id}">${s.off?"بازگرداندن":"حذف از برنامه"}</button></td></tr>`).join("")}
    </tbody></table></div></section>
  <section class="card stack"><h2>تاریخ امتحان‌های اصلی</h2><p class="small muted">این تاریخ‌ها تخمینی‌اند. وقتی برنامهٔ رسمی آموزش‌وپرورش و سازمان سنجش منتشر شد، اینجا به‌روز کنید.</p>
    <div class="fgrid">${S.exams.filter(e=>["final11","final12","konkur"].includes(e.kind)).map(e=>`<label class="field"><span>${esc(e.title)}</span><input type="text" data-exd="${e.id}" value="${jShort(e.date).replace(/[۰-۹]/g,c=>"۰۱۲۳۴۵۶۷۸۹".indexOf(c))}" inputmode="numeric"></label>`).join("")}</div></section>
  <div class="row"><button class="btn primary" data-act="savesettings">ذخیره و بازسازی برنامه</button><button class="btn ghost" data-act="reset">شروع دوباره از اول</button><button class="btn ghost" data-act="logout">خروج از حساب</button></div>
  <p class="small muted">Evono | نسخهٔ اول. داده‌های شما ${STORE==="account"?"در حساب Claude شما ذخیره می‌شود و فقط خودتان آن را می‌بینید":"در همین مرورگر ذخیره می‌شود"}.</p>
  </div>`;
}

/* ================= Settings — big popup opened from Profile ================= */
function settingsModalHTML(){
  return `<div class="settings-modal-inner">
    <div class="row" style="justify-content:space-between;align-items:flex-start;margin-bottom:6px">
      <h2 style="margin:0">تنظیمات کامل</h2>
      <button type="button" class="x-close" data-m="close" aria-label="بستن" title="بستن">×</button>
    </div>
    ${renderSettings()}
  </div>`;
}
function openSettingsModal(){
  closeModal();
  const o=document.createElement("div");o.className="modal-bg";
  o.innerHTML=`<div class="modal wide settings-modal" role="dialog" aria-modal="true" id="settings-modal-el">${settingsModalHTML()}</div>`;
  document.body.appendChild(o);
  o.addEventListener("click",e=>{if(e.target===o)closeModal()});
  bindSettingsModal(document.getElementById("settings-modal-el"));
  const f=o.querySelector(".btn.primary,.btn");if(f)f.focus();
}
function refreshSettingsModal(){
  const el=document.getElementById("settings-modal-el");if(!el)return;
  const sc=el.scrollTop;el.innerHTML=settingsModalHTML();el.scrollTop=sc;
  bindSettingsModal(el);
}
function doLogout(){
  // Fire-and-forget: clears the httpOnly session cookie /otp/verify set (see backend/src/lib/auth.js's
  // SESSION_COOKIE), so the landing page's header stops showing this student as signed in too. Never
  // awaited/blocking — the local logout below must work instantly even offline, same as always.
  api("/api/otp/logout",{method:"POST"}).catch(()=>{});
  setAuthToken("");PH={step:"phone",phone:S.profile.phone||"",sentAt:0,err:"",busy:false};LOGGED_OUT=true;render()
}
function doResetFlow(btn){
  if(btn.dataset.sure){
    const keepPhone=S.profile.phone||"",keepEmail=S.profile.email||"",keepAvatar=S.profile.avatar||null,keepSub=S.sub,keepIntents=S.intents,keepTheme=S.profile.theme,keepOrderSeq=S.orderSeq,keepName=S.profile.name||"",keepFname=S.profile.fname||"",keepLname=S.profile.lname||"";
    CARRY={phone:keepPhone,email:keepEmail,avatar:keepAvatar,sub:keepSub,intents:keepIntents,theme:keepTheme,orderSeq:keepOrderSeq,name:keepName,fname:keepFname,lname:keepLname};
    S=freshState();S.profile.phone=keepPhone;S.profile.email=keepEmail;S.profile.avatar=keepAvatar;S.profile.theme=keepTheme;S.sub=keepSub;S.intents=keepIntents;S.orderSeq=keepOrderSeq;
    // نام روی این شماره قبلاً ثبت شده — دوباره‌سازیِ برنامه نباید اجازهٔ تغییرش را بدهد؛ فقط با پشتیبانی می‌شود عوضش کرد
    OB={name:keepName,fname:keepFname,lname:keepLname,nameLocked:!!(keepFname||keepLname),grade:"12",field:"tajrobi",levels:{},scores:{},av:DEFAULT_AV(),sleep:DEFAULT_SLEEP(),holiday:{start:"09:00",end:"18:00"},sessionLen:60,breakLen:10,dailyHours:null,prefs:null,retake:false,summary:"",phone:keepPhone,phoneOk:!!keepPhone};
    OB_MODE="form";OB_STEP=0;save();return true;
  }
  btn.dataset.sure="1";btn.textContent="مطمئنید؟ برنامهٔ مطالعه پاک می‌شود — دوباره بزنید";return false;
}
function bindSettingsModal(root){
  if(!root)return;
  root.querySelectorAll("[data-m='close']").forEach(b=>b.onclick=()=>closeModal());
  root.querySelectorAll("[data-editcurr]").forEach(b=>b.onclick=()=>editCurr(b.dataset.editcurr));
  root.querySelectorAll("[data-notif]").forEach(b=>b.onclick=async()=>{unlockAudio();await askNotify();toast(notifState());refreshSettingsModal()});
  root.querySelectorAll("[data-testrem]").forEach(b=>b.onclick=()=>{unlockAudio();chime();notify("یادآور Evono","اعلان‌ها کار می‌کنند ✓");toast("یادآور آزمایشی پخش شد")});
  root.querySelectorAll("[data-lvl]").forEach(b=>b.onclick=()=>{const [id,l]=b.dataset.lvl.split(":");subById(id).level=+l;save();refreshSettingsModal()});
  // Take a subject out of planning at any time (reversible — progress, level and chapter position are
  // all left untouched, just skipped when tasks get generated; see the S.subjects.forEach(...) filter
  // in the day-planning function). Toggling it back on picks up exactly where it left off.
  root.querySelectorAll("[data-toggleoff]").forEach(b=>b.onclick=()=>{
    const sub=subById(b.dataset.toggleoff);if(!sub)return;
    sub.off=!sub.off;save();regenerateWeek();
    toast(sub.off?`${subName(sub.id)} از برنامه‌ریزی حذف شد`:`${subName(sub.id)} به برنامه‌ریزی برگشت`);
    refreshSettingsModal();render();
  });
  root.querySelectorAll("[data-s-hrs]").forEach(b=>b.onclick=()=>{
    const h=+b.dataset.sHrs,targetMinutes=h*60,pr=S.profile;
    maybeWarnSchedule(S.availability,pr.sessionLen,pr.breakLen,targetMinutes,{
      onProceed:()=>{pr.dailyGoal=targetMinutes;save();regenerateWeek();toast(`هدف روزانه: ${fa(h)} ساعت`);refreshSettingsModal()},
      onAutoAdjust:extendedAv=>{pr.dailyGoal=targetMinutes;S.availability=extendedAv;normAv(S.availability);sanitizeTimes(S.sleep,S.availability,S.holiday);save();regenerateWeek();toast(`هدف روزانه: ${fa(h)} ساعت`);refreshSettingsModal()},
      onEdit:()=>{}
    });
  });
  root.querySelectorAll("[data-act]").forEach(b=>b.onclick=()=>{const a=b.dataset.act;
    if(a==="savesettings"){saveSettings()} // saveSettings() closes the settings popup itself once it actually finishes — it may first pop the schedule-fit warning over it
    else if(a==="reset"){if(doResetFlow(b)){closeModal();render()}}
    else if(a==="logout"){closeModal();doLogout()}
  });
}

/* ================= Tickets — support chat ================= */
function renderTicketMsg(m){
  const img=m.img?`<img class="msg-img" src="${m.img}" alt="تصویر">`:"";
  if(m.from==="me")return `<div class="msg u">${img}${m.text?esc(m.text):""}<span class="msg-time">${fmtWhen(m.at)}</span></div>`;
  return `<div class="msg a"><div class="msg-sender"><span class="av-sm">${m.avatar?`<img src="${m.avatar}" alt="">`:esc((m.name||"پ").trim().charAt(0)||"پ")}</span>${esc(m.name||"پشتیبانی Evono")}</div>${img}${m.text?esc(m.text):""}<span class="msg-time">${fmtWhen(m.at)}</span></div>`;
}
function renderTicketChat(t){
  return `<div class="grid g-main"><section class="card chat">
    <div class="card-h">
      <button type="button" class="btn sm ghost" data-act="closeticketview" aria-label="بازگشت به فهرست تیکت‌ها">→ بازگشت</button>
      <h2 style="flex:1;min-width:120px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${esc(t.subject)}</h2>
      <span class="tx-status ${t.status==="closed"?"ok":"pending"}">${t.status==="closed"?"بسته شده":"باز"}</span>
      ${t.status!=="closed"?'<button type="button" class="btn sm ghost" data-act="closeticket">بستن تیکت</button>':""}
    </div>
    <div class="msgs" id="tmsgs">${t.messages.map(renderTicketMsg).join("")}</div>
    ${t.status==="closed"
      ?`<div class="note" style="display:flex;align-items:center;justify-content:space-between;gap:10px;flex-wrap:wrap"><span>این تیکت بسته شده است.</span><button type="button" class="btn sm primary" data-act="reopenticket">بازکردن دوباره</button></div>`
      :`<form class="composer" id="ticket-composer">
        <label class="btn sm ghost attach-btn" title="پیوست تصویر">📎<input type="file" accept="image/*" id="ticket-img" style="position:absolute;inset:0;opacity:0;cursor:pointer"></label>
        ${TICKET_IMG?`<span class="img-preview"><img src="${TICKET_IMG}" alt=""><button type="button" id="ticket-img-rm" title="حذف تصویر">✕</button></span>`:""}
        <textarea id="ticket-in" placeholder="پیامت رو بنویس…" aria-label="پیام به پشتیبانی">${esc(TICKET_DRAFT)}</textarea>
        <button class="btn primary" id="ticket-send">ارسال</button>
      </form>`}
  </section>
  <aside class="stack"><section class="card"><h3>نکته</h3><p class="small muted">پاسخ پشتیبانی معمولاً در همان روز کاری داده می‌شود. برای مسائل مربوط به پرداخت یا اشتراک هم می‌توانی همین‌جا تیکت بزنی.</p></section></aside></div>`;
}
function renderTickets(){
  if(OPEN_TICKET){
    const t=S.tickets.find(x=>x.id===OPEN_TICKET);
    if(t)return renderTicketChat(t);
    OPEN_TICKET=null;
  }
  const list=[...S.tickets].sort((a,b)=>b.updatedAt-a.updatedAt);
  const openTicket=S.tickets.find(t=>t.status!=="closed");
  return `<div class="grid g-main"><section class="card stack">
    <div class="card-h"><h2>تیکت‌های پشتیبانی</h2>${NEW_TICKET_OPEN||openTicket?"":'<button type="button" class="btn primary sm" data-act="newticket">+ تیکت جدید</button>'}</div>
    <p class="small muted" style="margin-top:-6px">اینجا می‌تونی با پشتیبانی و مدیران Evono چت کنی و هر مشکلی رو مطرح کنی.</p>
    ${openTicket&&!NEW_TICKET_OPEN?`<div class="note" style="display:flex;align-items:center;justify-content:space-between;gap:10px;flex-wrap:wrap"><span>یک تیکت باز داری؛ تا وقتی بسته نشده، فقط می‌تونی همون رو ادامه بدی.</span><button type="button" class="btn sm primary" data-open-ticket="${openTicket.id}">رفتن به تیکت باز</button></div>`:""}
    ${NEW_TICKET_OPEN?`<div class="stack" style="animation:pop .35s var(--ease) both;background:var(--surface-2);border:1px solid var(--line-2);border-radius:16px;padding:16px">
      <label class="field"><span>موضوع</span><input type="text" id="nt-subject" placeholder="مثلاً: مشکل در پرداخت اشتراک" maxlength="80" value="${esc(NT_PREFILL_SUBJECT)}"></label>
      <label class="field"><span>پیام</span><textarea id="nt-msg" rows="4" placeholder="مشکلت رو با جزئیات بنویس…">${esc(NT_PREFILL_MSG)}</textarea></label>
      <div class="row"><button type="button" class="btn primary" data-act="submitnewticket">ارسال تیکت</button><button type="button" class="btn ghost" data-act="cancelnewticket">انصراف</button></div>
    </div>`:""}
    ${list.length?`<div class="tick-list">${list.map((t,i)=>{
      const last=t.messages[t.messages.length-1];
      return `<button type="button" class="tick-item" data-open-ticket="${t.id}" style="animation-delay:${i*40}ms">
        <div class="tick-item-top"><b>${esc(t.subject)}</b><span class="tx-status ${t.status==="closed"?"ok":"pending"}">${t.status==="closed"?"بسته شده":"باز"}</span></div>
        ${last?`<p class="small muted tick-preview">${last.text?esc(last.text):"📷 تصویر"}</p>`:""}
        <span class="small muted tick-time">${fmtWhen(t.updatedAt)}</span>
      </button>`;
    }).join("")}</div>`:`<p class="small muted" style="padding:20px 0;text-align:center">هنوز تیکتی نداری. اگر سؤالی یا مشکلی داری، یک تیکت جدید بزن تا با پشتیبانی Evono در ارتباط باشی.</p>`}
  </section>
  <aside class="stack"><section class="card"><h3>پشتیبانی Evono چطور کار می‌کند؟</h3><ul class="small" style="margin:8px 0 0;padding-inline-start:18px;line-height:2">
    <li>هر بار فقط یک تیکت باز می‌تونی داشته باشی</li><li>پیام‌هایت مستقیم برای تیم پشتیبانی و مدیران ارسال می‌شود</li><li>هر وقت خواستی می‌توانی به گفت‌وگو برگردی</li><li>وقتی مشکل حل شد، تیکت بسته می‌شود و می‌تونی تیکت تازه بزنی</li>
  </ul></section></aside></div>`;
}
function submitNewTicket(){
  if(S.tickets.some(t=>t.status!=="closed")){toast("یک تیکت باز داری؛ اول همون رو ببند یا تمومش کن");NEW_TICKET_OPEN=false;render();return}
  const subjEl=$("#nt-subject"),msgEl=$("#nt-msg");
  const subject=(subjEl&&subjEl.value||"").trim(), text=(msgEl&&msgEl.value||"").trim();
  if(!subject||!text){toast("موضوع و پیام رو پر کن");return}
  const t={id:uid(),subject,status:"open",createdAt:Date.now(),updatedAt:Date.now(),messages:[{id:uid(),from:"me",text,at:Date.now()}]};
  S.tickets.unshift(t);save();
  NEW_TICKET_OPEN=false;OPEN_TICKET=t.id;NT_PREFILL_SUBJECT="";NT_PREFILL_MSG="";render();
  simulateTicketAck(t.id);
}
function simulateTicketAck(ticketId){
  setTimeout(()=>{
    const box=$("#tmsgs");if(!box)return;
    const bubble=document.createElement("div");bubble.className="msg a thinking";bubble.textContent="در حال تایپ";box.appendChild(bubble);box.scrollTop=box.scrollHeight;
    setTimeout(()=>{
      const t=S.tickets.find(x=>x.id===ticketId);if(!t)return;
      t.messages.push({id:uid(),from:"support",name:"پشتیبانی Evono",avatar:null,text:"سلام! پیامت رو دریافت کردیم؛ یکی از همکارهای پشتیبانی به‌زودی همین‌جا بهت جواب می‌ده 🌙",at:Date.now()});
      t.updatedAt=Date.now();save();
      if(TAB==="tickets"&&OPEN_TICKET===ticketId)render();
    },1300);
  },500);
}
function sendTicketMsg(){
  const inp=$("#ticket-in");if(!inp)return;
  const text=(inp.value||"").trim();
  if(!text&&!TICKET_IMG)return;
  const t=S.tickets.find(x=>x.id===OPEN_TICKET);if(!t)return;
  t.messages.push({id:uid(),from:"me",text,img:TICKET_IMG||null,at:Date.now()});t.updatedAt=Date.now();
  TICKET_IMG=null;TICKET_DRAFT="";save();render();
  const box=$("#tmsgs");if(box)box.scrollTop=box.scrollHeight;
}

/* ---------- Bindings ---------- */
function bindView(){
  const v=$("#view");
  v.querySelectorAll("[data-goto]").forEach(b=>b.onclick=()=>{TAB=b.dataset.goto;render()});
  v.querySelectorAll("[data-start]").forEach(b=>b.onclick=()=>startSession(todayIso(),b.dataset.start));
  v.querySelectorAll("[data-tip]").forEach(b=>b.onclick=()=>{if(b.dataset.tip==="len60"){S.profile.sessionLen=60;regenerateWeek();toast("جلسه‌ها ۱ ساعته شدند و هفته بازسازی شد");render()}
    else{TAB="ai";ANIM=true;render();if(aiAllowed())sendAI("می‌خواهم جدی‌تر بخوانم و روزی ۶ ساعت یا بیشتر درس بخوانم. با توجه به ساعت مدرسه و خوابم، برنامه‌ام را تنظیم کن.");else{const i=$("#ai-in");if(i)i.value="می‌خواهم روزی ۶ ساعت درس بخوانم؛ برنامه‌ام را تنظیم کن."}}});
  v.querySelectorAll("[data-editcurr]").forEach(b=>b.onclick=()=>editCurr(b.dataset.editcurr));
  v.querySelectorAll("[data-wk]").forEach(b=>b.onclick=()=>{
    const g=$("#weekgrid");if(!g)return;
    // instant (non-smooth) scroll: avoids the iOS Safari bug where rapid taps stack up
    // in-flight smooth-scroll animations and the view overshoots way past the intended card
    g.scrollBy({left:(+b.dataset.wk)*(g.clientWidth*0.8),behavior:"instant"});
  });
  v.querySelectorAll("[data-rv]").forEach(i=>i.onchange=()=>{const k=i.dataset.rv;ACT.set_konkur_review(k==="g10"?{grade10:i.checked}:{grade11:i.checked});toast("برنامهٔ هفته با مرور جدید بازسازی شد");render()});
  v.querySelectorAll('input[name="rvlvl"]').forEach(i=>i.onchange=()=>{ACT.set_konkur_review({level:i.value});toast("سهم مرور تغییر کرد");render()});
  v.querySelectorAll("[data-wkoff]").forEach(b=>b.onclick=()=>{WEEK_OFF=+b.dataset.wkoff;ANIM=true;render()});
  v.querySelectorAll("[data-wkview]").forEach(b=>b.onclick=()=>{S.prefs.weekView=S.prefs.weekView==="full"?"cards":"full";save();render()});
  v.querySelectorAll("[data-restore]").forEach(b=>b.onclick=()=>{restorePrev(b.dataset.restore);toast("برنامهٔ قبلی برگشت");render()});
  v.querySelectorAll("[data-auto]").forEach(b=>b.onclick=()=>{ACT.restore_auto_plan({date:b.dataset.auto});toast("برنامهٔ خودکار Evono برگشت");render()});
  v.querySelectorAll("[data-notif]").forEach(b=>b.onclick=async()=>{unlockAudio();await askNotify();toast(notifState());render()});
  v.querySelectorAll("[data-theme-pick]").forEach(b=>b.onclick=()=>{S.profile.theme=b.dataset.themePick;save();applyTheme();render();toast("تم تغییر کرد")});
  v.querySelectorAll("[data-testrem]").forEach(b=>b.onclick=()=>{unlockAudio();chime();notify("یادآور Evono","اعلان‌ها کار می‌کنند ✓");toast("یادآور آزمایشی پخش شد")});
  v.querySelectorAll("[data-buy]").forEach(b=>b.onclick=()=>showCheckout(b.dataset.buy));
  {const tr=$("#topup-range");
    if(tr){
      // Update the count/price/button label in place on every drag tick (input) without a full
      // render() — re-rendering #view mid-drag would recreate this very <input>, which throws the
      // browser's own drag tracking away out from under the pointer. Only the final release
      // (change) triggers a real render, to refresh disabled-state text etc.
      tr.oninput=()=>{const n=+tr.value;TOPUP.n=n;
        const cnt=$("#topup-count");if(cnt)cnt.textContent=fa(n);
        const unit=TOPUP.rate&&TOPUP.rate.unitPriceToman;
        const price=$("#topup-price");if(price)price.textContent=unit?fa(n*unit)+" تومان":"…";
        const btn=$("#topup-buy-btn");if(btn)btn.textContent=`خرید ${fa(n)} پیام`;
      };
      tr.onchange=()=>render();
    }
    const tb=$("[data-topup-buy]");if(tb)tb.onclick=()=>buyTopup();
    const trBtn=$("[data-topup-retry]");if(trBtn)trBtn.onclick=()=>{ensureTopupRate(true);render()};
  }
  v.querySelectorAll("[data-pfhrs]").forEach(b=>b.onclick=()=>{
    const h=+b.dataset.pfhrs,targetMinutes=h*60,pr=S.profile;
    maybeWarnSchedule(S.availability,pr.sessionLen,pr.breakLen,targetMinutes,{
      onProceed:()=>{pr.dailyGoal=targetMinutes;save();regenerateWeek();toast(`هدف روزانه: ${fa(h)} ساعت`);render()},
      onAutoAdjust:extendedAv=>{pr.dailyGoal=targetMinutes;S.availability=extendedAv;normAv(S.availability);sanitizeTimes(S.sleep,S.availability,S.holiday);save();regenerateWeek();toast(`هدف روزانه: ${fa(h)} ساعت`);render()},
      onEdit:()=>{}
    });
  });
  const av=$("#pf-avatar");if(av)av.onchange=()=>{const f=av.files&&av.files[0];if(!f)return;
    if(!f.type.startsWith("image/")){toast("فقط فایل تصویر قابل قبول است");return}
    const img=new Image();const url=URL.createObjectURL(f);
    img.onload=()=>{const size=200;const cv=document.createElement("canvas");cv.width=size;cv.height=size;const cx=cv.getContext("2d");
      const s=Math.max(size/img.width,size/img.height);const w=img.width*s,h=img.height*s;
      cx.drawImage(img,(size-w)/2,(size-h)/2,w,h);
      S.profile.avatar=cv.toDataURL("image/jpeg",.85);URL.revokeObjectURL(url);save();toast("عکس پروفایل تغییر کرد");render()};
    img.onerror=()=>{toast("این فایل باز نشد");URL.revokeObjectURL(url)};img.src=url};
  v.querySelectorAll('input[name="pf-pace"]').forEach(i=>i.onchange=()=>{ACT.set_preferences({pace:i.value});toast("سرعت پیشروی تغییر کرد");render()});
  v.querySelectorAll("[data-quick]").forEach(b=>b.onclick=()=>{if(!aiAllowed()){paywall();return}if(TAB!=="ai"){TAB="ai";render()}sendAI(b.dataset.quick)});
  v.querySelectorAll("[data-act]").forEach(b=>b.onclick=async(ev)=>{const a=b.dataset.act,id=b.dataset.id,d=todayIso();
    if(a==="start"){const p=S.plans[d];const k=p.tasks.find(x=>x.id===id);if(k.status==="doing"&&S.timer&&S.timer.taskId===id){stopTimer()}else startSession(d,id)}
    if(a==="regenweek"){confirmImportant({title:"برنامهٔ هفته از نو ساخته شود؟",body:"جلسه‌های نخوانده‌ی باقی‌ماندهٔ این هفته (به‌جز روزهایی که خودت دستی تغییرشان داده‌ای) پاک می‌شوند و از نو، با درس و ترتیب احتمالاً متفاوت، ساخته می‌شوند. جلسه‌های انجام‌شده دست‌نخورده می‌مانند.",confirmLabel:"بله، از نو بساز",onYes:()=>{regenerateWeek();toast("برنامهٔ هفته دوباره ساخته شد");render()}})}
    if(a==="dismiss"){S.dismissed=S.dismissed||{};S.dismissed[id]=true;save();render()}
    if(a==="done"){setTaskStatus(d,id,"done");toast("انجام شد ✓");render();maybeReport()}
    if(a==="skip"){setTaskStatus(d,id,"skipped");toast("رد شد؛ در روزهای بعد پخش می‌شود");render();maybeReport()}
    if(a==="why"){OPEN_WHY=OPEN_WHY===id?null:id;render()}
    if(a==="regen"){regenerateKeepingDone(d);toast("برنامهٔ امروز بازسازی شد");render()}
    if(a==="clearchat"){S.chat=[];save();render()}
    if(a==="savefs"){S.finalExcluded=S.finalExcluded||{};v.querySelectorAll("[data-fx]").forEach(c=>{if(c.checked){S.finalExcluded[c.dataset.fx]=true;delete S.finalScores[c.dataset.fx]}else delete S.finalExcluded[c.dataset.fx]});v.querySelectorAll("[data-fs]").forEach(i=>{if(S.finalExcluded[i.dataset.fs])return;const x=toEnDigits(i.value).trim();if(x==="")delete S.finalScores[i.dataset.fs];else{const n=Number(x);if(n>=0&&n<=20)S.finalScores[i.dataset.fs]=n}});const r=$("#retake");if(r)S.profile.retake=r.checked;save();toast("نمره‌ها ذخیره شد");render()}
    if(a==="analyze")analyzeDay(b);
    if(a==="weekly")weeklyAI(b);
    if(a==="savesettings")saveSettings();
    if(a==="saveprofile")saveProfile();
    if(a==="rmavatar"){S.profile.avatar=null;save();toast("عکس پروفایل حذف شد");render()}
    if(a==="reset"){if(doResetFlow(b))render()}
    if(a==="logout"){doLogout()}
    if(a==="txmore"){TX_EXPANDED=true;render()}
    if(a==="txless"){TX_EXPANDED=false;render()}
    if(a==="opensettings")openSettingsModal();
    if(a==="examprepwizard")openExamPrepWizard();
    if(a==="newticket"){
      if(S.tickets.some(t=>t.status!=="closed")){toast("یک تیکت باز داری؛ اول همون رو ببند یا تمومش کن");render()}
      else{NT_PREFILL_SUBJECT="";NT_PREFILL_MSG="";NEW_TICKET_OPEN=true;render();const el=$("#nt-subject");if(el)el.focus()}
    }
    if(a==="cancelnewticket"){NEW_TICKET_OPEN=false;NT_PREFILL_SUBJECT="";NT_PREFILL_MSG="";render()}
    if(a==="submitnewticket")submitNewTicket();
    if(a==="closeticketview"){OPEN_TICKET=null;TICKET_IMG=null;TICKET_DRAFT="";render()}
    if(a==="closeticket"){const t=S.tickets.find(x=>x.id===OPEN_TICKET);if(t){t.status="closed";t.updatedAt=Date.now();save()}render()}
    if(a==="reopenticket"){const t=S.tickets.find(x=>x.id===OPEN_TICKET);if(t){t.status="open";t.updatedAt=Date.now();save()}render()}
  });
  v.querySelectorAll("[data-open-ticket]").forEach(b=>b.onclick=()=>{OPEN_TICKET=b.dataset.openTicket;TICKET_IMG=null;TICKET_DRAFT="";render();const m=$("#tmsgs");if(m)m.scrollTop=m.scrollHeight});
  const comp=$("#composer");if(comp){const inp=$("#ai-in");comp.onsubmit=e=>{e.preventDefault();if(aiBusy){aiCtl&&aiCtl.abort();return}const t=inp.value;inp.value="";sendAI(t)};
    inp.onkeydown=e=>{if(e.key==="Enter"&&!e.shiftKey){e.preventDefault();comp.requestSubmit()}};const m=$("#msgs");if(m)m.scrollTop=m.scrollHeight;
    if(aiBusy){$("#ai-send").disabled=false}}
  const tcomp=$("#ticket-composer");if(tcomp){const tinp=$("#ticket-in");tcomp.onsubmit=e=>{e.preventDefault();sendTicketMsg()};
    tinp.oninput=()=>{TICKET_DRAFT=tinp.value};
    tinp.onkeydown=e=>{if(e.key==="Enter"&&!e.shiftKey){e.preventDefault();tcomp.requestSubmit()}};const tm=$("#tmsgs");if(tm)tm.scrollTop=tm.scrollHeight;
    const timg=$("#ticket-img");
    if(timg)timg.onchange=()=>{
      const f=timg.files&&timg.files[0];if(!f)return;
      if(!f.type.startsWith("image/"))return;
      const img=new Image();const url=URL.createObjectURL(f);
      img.onload=()=>{
        const maxW=900;const s=Math.min(1,maxW/img.width);const w=img.width*s,h=img.height*s;
        const cv=document.createElement("canvas");cv.width=w;cv.height=h;
        cv.getContext("2d").drawImage(img,0,0,w,h);
        TICKET_IMG=cv.toDataURL("image/jpeg",.82);URL.revokeObjectURL(url);render();
      };
      img.onerror=()=>URL.revokeObjectURL(url);img.src=url;
    };
    const timgrm=$("#ticket-img-rm");
    if(timgrm)timgrm.onclick=()=>{TICKET_IMG=null;render()};
  }
  const rep=$("#rep");if(rep)rep.onsubmit=e=>{e.preventDefault();saveReport();toast("گزارش ثبت شد");render()};
  const resf=$("#resf");if(resf)resf.onsubmit=e=>{e.preventDefault();const log=[];try{runAction("record_result",{subject_id:$("#rs-sub").value,kind:$("#rs-kind").value,score:toEnDigits($("#rs-score").value)},log);toast(log[0].text);render()}catch(err){toast("نمره معتبر نیست")}};
  const exf=$("#exf");if(exf)exf.onsubmit=e=>{e.preventDefault();const log=[];try{runAction("add_exam",{title:$("#ex-title").value||"امتحان",date:$("#ex-date").value,subject_id:$("#ex-sub").value||undefined,kind:$("#ex-kind").value},log);toast(log[0].text);render()}catch(err){toast("تاریخ را به شکل ۱۴۰۵/۰۸/۱۵ وارد کنید")}};
  v.querySelectorAll("[data-delex]").forEach(b=>b.onclick=()=>{S.exams=S.exams.filter(e=>e.id!==b.dataset.delex);save();render()});
  v.querySelectorAll("[data-lvl]").forEach(b=>b.onclick=()=>{const [id,l]=b.dataset.lvl.split(":");subById(id).level=+l;save();render()});
  bindDragReorder(v);
}
/* Drag a card up/down among the OTHER not-yet-started cards in the same list (today's session list, or
   one day's list in the week view) to pick what to read first. Reordering only ever happens among "todo"
   cards — a fixed card (done/skipped/doing) is simply not part of the drag list, so a dragged card can
   slide past it visually but can never swap places with it. */
function beginCardDrag(card,captureEl,e){
  const dateIso=card.dataset.dragDate||todayIso();
  const parent=card.parentElement;
  const others=()=>Array.from(parent.children).filter(el=>el.hasAttribute("data-drag-id")&&el!==card);
  const rect=card.getBoundingClientRect();
  const offX=e.clientX-rect.left,offY=e.clientY-rect.top;

  // An empty dashed placeholder holds the card's spot in the list — the floating card itself follows the
  // pointer exactly and settles into wherever the placeholder currently sits the moment it's released.
  const placeholder=card.cloneNode(false);
  placeholder.removeAttribute("data-drag-id");
  placeholder.classList.add("drag-placeholder");
  placeholder.classList.remove("dragging");
  placeholder.style.height=rect.height+"px";
  parent.insertBefore(placeholder,card);

  card.classList.add("dragging");
  card.style.animation="none"; // a card grabbed mid entrance-animation must not keep animating its own transform while it floats
  // Float free of the list entirely (onto <body>) so position:fixed always tracks the real viewport — staying
  // nested under an ancestor card that's still mid entrance-animation would otherwise hijack the fixed origin.
  document.body.appendChild(card);
  card.style.position="fixed";
  card.style.left=rect.left+"px";
  card.style.top=rect.top+"px";
  card.style.width=rect.width+"px";
  card.style.margin="0";
  card.style.pointerEvents="none";

  const pid=e.pointerId;try{captureEl.setPointerCapture(pid)}catch(err){}
  const onMove=ev=>{
    card.style.left=(ev.clientX-offX)+"px";
    card.style.top=(ev.clientY-offY)+"px";
    const cy=ev.clientY;
    let ref=null;
    for(const item of others()){
      const r=item.getBoundingClientRect();
      if(cy<r.top+r.height/2){ref=item;break}
    }
    if(ref!==placeholder.nextElementSibling)parent.insertBefore(placeholder,ref);
  };
  const onUp=()=>{
    try{captureEl.releasePointerCapture(pid)}catch(err){}
    document.removeEventListener("pointermove",onMove);
    document.removeEventListener("pointerup",onUp);
    parent.insertBefore(card,placeholder);
    placeholder.remove();
    card.classList.remove("dragging");
    card.style.position="";card.style.left="";card.style.top="";card.style.width="";card.style.margin="";card.style.pointerEvents="";card.style.animation="";
    const order=Array.from(parent.children).filter(el=>el.hasAttribute("data-drag-id")).map(el=>el.dataset.dragId);
    const ok=reorderTasks(dateIso,order);
    if(ok)render();
  };
  document.addEventListener("pointermove",onMove);
  document.addEventListener("pointerup",onUp);
}
function bindDragReorder(v){
  // امروز: a dedicated bigger grip next to the time — grabbing it starts the drag immediately.
  v.querySelectorAll(".t-grip").forEach(grip=>{
    grip.onpointerdown=e=>{
      if(e.button!=null&&e.button!==0)return;
      const card=grip.closest("[data-drag-id]");if(!card)return;
      e.preventDefault();beginCardDrag(card,grip,e);
    };
  });
  // برنامهٔ هفته: cover the whole card and hold — just a brief beat, not a long press, is enough to tell
  // a hold-to-drag apart from a scroll/tap, so touching a card still scrolls the page normally unless the
  // student actually holds still on it.
  v.querySelectorAll(".week:not(.full) .wtask[data-drag-id]").forEach(card=>{
    card.onpointerdown=e=>{
      if(e.button!=null&&e.button!==0)return;
      if(e.target.closest("button,a,input,select,textarea"))return;
      const startX=e.clientX,startY=e.clientY;
      const timer=setTimeout(()=>{cleanup();beginCardDrag(card,card,e)},140);
      const onEarlyMove=ev=>{if(Math.hypot(ev.clientX-startX,ev.clientY-startY)>10){clearTimeout(timer);cleanup()}};
      const onEarlyUp=()=>{clearTimeout(timer);cleanup()};
      const cleanup=()=>{document.removeEventListener("pointermove",onEarlyMove);document.removeEventListener("pointerup",onEarlyUp)};
      document.addEventListener("pointermove",onEarlyMove);
      document.addEventListener("pointerup",onEarlyUp);
    };
  });
}
function saveReport(){
  const d=todayIso();const g=id=>$(id)?.value;const screen={};let tot=0;["instagram","youtube","telegram","games","other"].forEach(k=>{const n=readHM("st-"+k);if(n>0){screen[k]=n;tot+=n}});
  const r={date:d,minutes:readHM("r-min"),energy:Number(toEnDigits(g("#r-en")))||3,focus:Number(toEnDigits(g("#r-fo")))||3,hard:g("#r-hard")||"",note:g("#r-note")||"",screen,screenTotal:tot};
  S.reports=S.reports.filter(x=>x.date!==d);S.reports.push(r);save();return r;
}
async function analyzeDay(btn){
  if(!aiAllowed()){paywall();return}
  const r=saveReport();btn.disabled=true;btn.textContent="EvonoAI در حال تحلیل…";
  const prevScreen=S.reports.filter(x=>x.date<r.date).slice(-7);const avgPrev=prevScreen.length?Math.round(prevScreen.reduce((a,x)=>a+(x.screenTotal||0),0)/prevScreen.length):null;
  try{
    const {text}=await aiChat([{role:"user",content:"CONTEXT:\n"+aiContext()+"\n\nگزارش امروز دانش‌آموز: "+JSON.stringify(r)+"\nمیانگین زمان گوشی ۷ گزارش قبلی (دقیقه): "+avgPrev+
      "\n\nگزارش امروز را تحلیل کن: زمان مطالعه در برابر برنامه، کیفیت (مثلاً اگر زمان خوب بوده ولی سؤال‌ها حل نشده، احتمالاً مشکل مفهومی است نه زمانی)، انرژی و تمرکز، و پیامد عملی زمان گوشی بدون سرزنش. در پایان ۲ یا ۳ پیشنهاد مشخص برای فردا بده. حداکثر ۱۴۰ کلمه، فارسی. ادعا نکن برنامه را تغییر داده‌ای."}],AI_RULES);
    S.insights[r.date]=text;useAI();save();
  }catch(e){toast("خطا در ارتباط با سرور؛ تحلیل انجام نشد")}
  render();
}
async function weeklyAI(btn){
  if(!aiAllowed()){paywall();return}
  btn.disabled=true;btn.textContent="در حال ساخت…";
  const days=weekData();
  try{
    const {text}=await aiChat([{role:"user",content:"CONTEXT:\n"+aiContext()+"\n\nآمار ۷ روز: "+JSON.stringify(days.map(d=>({day:d.label,planned:d.planned,done:d.done,screen:d.screen})))+
      "\n\nمرور هفتگی بنویس: درصد انجام، قوی‌ترین پیشرفت، ضعیف‌ترین بخش، تعادل نهایی/کنکور نسبت به هدف فاز، امتحان‌های پیش رو، و ۳ اولویت هفتهٔ بعد. حداکثر ۱۸۰ کلمه، فارسی، با تیترهای کوتاه."}],AI_RULES);
    S.insights["week-"+todayIso()]=text;useAI();save();
  }catch(e){toast("خطا در ارتباط با سرور؛ مرور ساخته نشد")}
  render();
}
function saveSettings(){
  const pr=S.profile;const oldKey=pr.grade+pr.field+pr.konkurYear;
  // Read every pending value from the (possibly about-to-close) settings form up front, so the eventual
  // finalize() below never depends on that DOM still being there — showScheduleWarning may be popped over it.
  // نام اینجا دیگر قابل ویرایش نیست (فیلد #s-name غیرفعال است) — دانش‌آموز برای تغییرش باید با پشتیبانی تماس بگیرد
  const pendingSessionLen=Math.max(15,Math.min(150,readHM("s-len")||60));
  const pendingBreakLen=Math.max(0,Math.min(45,readHM("s-brk")));
  const pendingSleep={wake:tpVal("sl-wake",S.sleep.wake),bed:tpVal("sl-bed",S.sleep.bed),wakeOff:tpVal("sl-wake2",S.sleep.wakeOff),bedOff:tpVal("sl-bed2",S.sleep.bedOff)};
  const pendingHoliday={start:tpVal("hol-s",S.holiday.start),end:tpVal("hol-e",S.holiday.end)};
  const pendingRemind={};document.querySelectorAll("[data-rem]").forEach(i=>pendingRemind[i.dataset.rem]=i.checked);
  const pendingAv=JSON.parse(JSON.stringify(S.availability));
  document.querySelectorAll("[data-av-on]").forEach(i=>pendingAv[i.dataset.avOn].on=i.checked);
  for(let i=0;i<7;i++){pendingAv[i].start=tpVal("av-s-"+i,pendingAv[i].start);pendingAv[i].end=tpVal("av-e-"+i,pendingAv[i].end)}
  normAv(pendingAv);
  const pendingPos={};document.querySelectorAll("[data-pos]").forEach(i=>pendingPos[i.dataset.pos]=+i.value);
  const pendingKw={};document.querySelectorAll("[data-kw]").forEach(i=>pendingKw[i.dataset.kw]=Math.max(0,Math.min(5,+toEnDigits(i.value)||0)));
  const pendingExd={};document.querySelectorAll("[data-exd]").forEach(i=>pendingExd[i.dataset.exd]=i.value);

  const finalize=avOverride=>{
    pr.sessionLen=pendingSessionLen;pr.breakLen=pendingBreakLen;
    S.sleep=pendingSleep;S.holiday=pendingHoliday;
    Object.entries(pendingRemind).forEach(([k,v])=>S.remind[k]=v);
    S.availability=avOverride||pendingAv;normAv(S.availability);
    Object.entries(pendingPos).forEach(([id,v])=>{const s=subById(id);if(s)prog(s).f=v});
    Object.entries(pendingKw).forEach(([id,v])=>{const s=subById(id);if(s)s.kw=v});
    if(oldKey!==pr.grade+pr.field+pr.konkurYear)buildMainExams();
    else Object.entries(pendingExd).forEach(([id,val])=>{const e=S.exams.find(x=>x.id===id);const iso=parseJ(val);if(e&&iso&&iso!==e.date){e.date=iso;e.estimated=false}});
    const fixN=sanitizeTimes(S.sleep,S.availability,S.holiday);normAv(S.availability);
    closeModal(); // closes the settings popup (if this save came from there) now that it's actually finalized — never before, or the schedule-fit warning above it would get wiped out too
    regenerateWeek();toast(fixN.length?"ذخیره شد؛ "+fa(fixN.length)+" ساعتِ اشتباه اصلاح شد":"ذخیره شد و برنامهٔ هفته بازسازی شد");render();
  };

  maybeWarnSchedule(pendingAv,pendingSessionLen,pendingBreakLen,pr.dailyGoal,{
    onProceed:()=>finalize(),
    onAutoAdjust:extendedAv=>finalize(extendedAv), // keeps the daily-hours goal as asked; stretches whichever day(s) were too short
    onEdit:()=>{}
  });
}
function saveProfile(){
  const pr=S.profile;
  // نام اینجا دیگر قابل ویرایش نیست (فیلد #pf-name غیرفعال است) — دانش‌آموز برای تغییرش باید با پشتیبانی تماس بگیرد
  const finish=()=>{save();regenerateWeek();toast("پروفایل ذخیره شد");render()};
  if($("#pf-len-h")){
    const pendingSessionLen=Math.max(15,Math.min(150,readHM("pf-len")||60));
    const pendingBreakLen=Math.max(0,Math.min(45,readHM("pf-brk")));
    maybeWarnSchedule(S.availability,pendingSessionLen,pendingBreakLen,pr.dailyGoal,{
      onProceed:()=>{pr.sessionLen=pendingSessionLen;pr.breakLen=pendingBreakLen;finish()},
      onAutoAdjust:extendedAv=>{pr.sessionLen=pendingSessionLen;pr.breakLen=pendingBreakLen;S.availability=extendedAv;normAv(S.availability);sanitizeTimes(S.sleep,S.availability,S.holiday);finish()}, // keeps the daily-hours goal as asked; stretches whichever day(s) were too short
      onEdit:()=>{}
    });
    return;
  }
  finish();
}

/* ================= Onboarding ================= */
let OB={name:"",fname:"",lname:"",grade:"12",field:"tajrobi",levels:{},scores:{},av:DEFAULT_AV(),sleep:DEFAULT_SLEEP(),holiday:{start:"09:00",end:"18:00"},sessionLen:60,breakLen:10,dailyHours:null,prefs:null,retake:false,summary:"",trialStart:null};
/* Evono's rule of thumb (see AI_RULES #14): a serious konkur-year student should study ~6h/day or more; a bit less
   for earlier grades who mainly have school + light prep. Shown as a starting suggestion, never enforced. */
function recommendedHours(grade,field){
  let h=grade==="12"||grade==="grad"?6:grade==="11"?5:3; // grade 10: no national final/konkur pressure yet, keep it light
  if(field==="tajrobi"&&grade!=="10")h+=1; // تجربی: harder konkur competition, suggest a bit more
  return Math.min(9,h);
}
let OB_MODE="form";let PH={step:"phone",phone:"",sentAt:0,err:"",busy:false};let OBC={turns:[],busy:false,done:false};
const toEnDigits=v=>String(v||"").replace(/[۰-۹]/g,c=>"۰۱۲۳۴۵۶۷۸۹".indexOf(c)).replace(/[٠-٩]/g,c=>"٠١٢٣٤٥٦٧٨٩".indexOf(c));
function normPhone(v){let d=toEnDigits(v).replace(/\D/g,"");if(d.startsWith("0098"))d="0"+d.slice(4);else if(d.startsWith("98")&&d.length===12)d="0"+d.slice(2);else if(d.length===10&&d.startsWith("9"))d="0"+d;return d}
const phoneOk=d=>/^09\d{9}$/.test(d);
const fmtPhone=d=>faStr(d.replace(/^(\d{4})(\d{3})(\d{4})$/,"$1 $2 $3"));
const OTP_ERR_FA={invalid_phone:"شمارهٔ موبایل معتبر نیست.",sms_send_failed:"ارسال پیامک ناموفق بود؛ کمی بعد دوباره امتحان کن.",wrong_or_expired_code:"کد اشتباه یا منقضی شده است؛ دوباره امتحان کن.",invalid_request:"اطلاعات وارد شده کامل نیست.",network_error:"ارتباط با سرور برقرار نشد؛ اتصال اینترنت را بررسی کن.",too_soon:"کد قبلی هنوز معتبر است؛ کمی صبر کن و دوباره امتحان کن.",too_many_requests:"تلاش‌های زیادی انجام شده؛ چند دقیقه دیگر دوباره امتحان کن."};
function renderPhone(){
  const left=Math.max(0,120-Math.floor((Date.now()-PH.sentAt)/1000));
  return `<div class="ob"><div class="card login">
    <div class="hero-ob"><div class="brandbig">Evono</div><h1>${PH.step==="phone"?"ورود یا ثبت‌نام":"کد تأیید را وارد کن"}</h1>
    <p class="muted">${PH.step==="phone"?"شمارهٔ موبایلت را وارد کن تا کد تأیید برایت پیامک شود.":`کد ۵ رقمی به <span dir="ltr">${fmtPhone(PH.phone)}</span> فرستاده شد. <button class="linkbtn" data-ph="edit">ویرایش شماره</button>`}</p></div>
    ${PH.step==="phone"?`<label class="field"><span>شمارهٔ موبایل</span><div class="phone-in"><span class="cc">۹۸+</span><input type="tel" id="ph-in" inputmode="numeric" autocomplete="tel" dir="ltr" placeholder="۰۹۱۲ ۳۴۵ ۶۷۸۹" value="${esc(PH.phone?fmtPhone(PH.phone):"")}" maxlength="16"></div></label>`
      :`<div class="otp" dir="ltr">${[0,1,2,3,4].map(i=>`<input type="text" inputmode="numeric" autocomplete="one-time-code" maxlength="1" data-otp="${i}" aria-label="رقم ${fa(i+1)}">`).join("")}</div>
       <p class="small muted" style="text-align:center">${left?`ارسال دوباره تا <span id="ph-left" class="num">${fa(left)}</span> ثانیه`:`<button class="linkbtn" data-ph="resend">ارسال دوباره کد</button>`}</p>`}
    ${PH.err?`<p class="ph-err">${esc(PH.err)}</p>`:""}
    <div class="ob-foot" style="justify-content:flex-end"><button class="btn primary" data-ph="${PH.step==="phone"?"send":"verify"}" ${PH.busy?"disabled":""}>${PH.busy?"در حال ارسال…":PH.step==="phone"?"ارسال کد":"تأیید و ادامه"}</button></div>
    <p class="small muted" style="text-align:center;margin-top:14px">با ادامه، <span class="ai-mark">Evono</span> فقط برای ورود و یادآورها از شمارهٔ تو استفاده می‌کند.</p>
  </div></div>`}
async function sendOtp(){
  const d=normPhone($("#ph-in").value);
  if(!phoneOk(d)){PH.err="شمارهٔ موبایل باید ۱۱ رقم باشد و با ۰۹ شروع شود؛ مثل ۰۹۱۲۳۴۵۶۷۸۹";render();return}
  PH.busy=true;PH.err="";render();
  try{
    await api("/api/otp/send",{method:"POST",body:{phone:d}});
    PH.phone=d;PH.sentAt=Date.now();PH.step="code";
  }catch(e){PH.err=OTP_ERR_FA[e.code]||"ارسال کد ناموفق بود؛ دوباره امتحان کن."}
  finally{PH.busy=false;render()}
}
async function verifyOtp(code){
  PH.busy=true;PH.err="";render();
  try{
    const r=await api("/api/otp/verify",{method:"POST",body:{phone:PH.phone,code}});
    setAuthToken(r.token);
    if(LOGGED_OUT){LOGGED_OUT=false;PH.err="";toast("خوش آمدی ✓");render();return}
    OB.phone=PH.phone;OB.phoneOk=true;PH.err="";toast("شماره تأیید شد ✓");render();
  }catch(e){PH.err=OTP_ERR_FA[e.code]||"تأیید کد ناموفق بود؛ دوباره امتحان کن.";render()}
  finally{PH.busy=false}
}
function bindPhone(){
  const inp=$("#ph-in");if(inp){inp.focus();inp.oninput=()=>{const d=normPhone(inp.value);inp.value=faStr(d);PH.err=""};inp.onkeydown=e=>{if(e.key==="Enter")document.querySelector('[data-ph="send"]').click()}}
  const boxes=[...document.querySelectorAll("[data-otp]")];
  boxes.forEach((b,i)=>{b.oninput=()=>{const v=toEnDigits(b.value).replace(/\D/g,"");if(v.length>1){v.slice(0,5).split("").forEach((c,k)=>{if(boxes[k])boxes[k].value=faStr(c)});boxes[Math.min(4,v.length-1)].focus()}else{b.value=v?faStr(v):"";if(v&&boxes[i+1])boxes[i+1].focus()}
      if(boxes.every(x=>x.value))document.querySelector('[data-ph="verify"]').click()};
    b.onkeydown=e=>{if(e.key==="Backspace"&&!b.value&&boxes[i-1])boxes[i-1].focus()}});
  if(boxes[0])boxes[0].focus();
  document.querySelectorAll("[data-ph]").forEach(b=>b.onclick=()=>{const a=b.dataset.ph;if(PH.busy)return;
    if(a==="send")sendOtp();
    if(a==="resend")sendOtp();
    if(a==="edit"){PH.step="phone";PH.err="";render()}
    if(a==="verify"){const v=boxes.map(x=>toEnDigits(x.value)).join("");if(v.length<5){PH.err="کد ۵ رقمی را کامل وارد کن";render();return}
      verifyOtp(v)}});
}
setInterval(()=>{const el=document.getElementById("ph-left");if(!el)return;const left=Math.max(0,120-Math.floor((Date.now()-PH.sentAt)/1000));if(left)el.textContent=fa(left);else render()},1000);
function renderOnboarding(){
  if(!OB.phoneOk)return renderPhone();
  if(OB_MODE==="chat")return renderOBChat();
  const steps=5;const bar=`<div class="ob-steps">${Array.from({length:steps},(_,i)=>`<i class="${i<=OB_STEP?"on":""}"></i>`).join("")}</div>`;
  const areas=CATALOG[OB.field].areas;const gi=OB.grade==="10"?0:OB.grade==="11"?1:2;
  const body=[
  ()=>`<div class="hero-ob"><div class="brandbig">Evono</div><h1>مشاور تحصیلی هوشمند برای سه امتحان مهم</h1>
    <p class="muted"><b class='brand-word'>Evono</b> برنامهٔ درسی شما را می‌سازد و هر روز با واقعیت زندگی‌تان تنظیمش می‌کند؛ همه‌چیز حول سه امتحانی که آینده‌تان را می‌سازند:</p></div>
    <div class="three"><div><b>امتحان نهایی یازدهم</b><p class="small muted">کشوری، کتبی، خرداد</p></div><div><b>امتحان نهایی دوازدهم</b><p class="small muted">بیشترین سهم سوابق تحصیلی</p></div><div><b>کنکور</b><p class="small muted">آزمون تستی سراسری</p></div></div>
    <div class="feat">${[["◆︎","برنامهٔ هفتگی درس‌به‌درس","هر جلسه با فصل و بخش دقیق کتاب درسی"],["✦︎","<b class='brand-word'>EvonoAI</b>","بگو چه شده؛ برنامه همان لحظه عوض می‌شود"],["⏱︎","تایمر و یادآور","شروع جلسه، استراحت و گزارش پایان شب"],["☀︎","هماهنگ با فصل‌ها","سال تحصیلی، تابستان، نوروز و فصل امتحانات"]].map(([i,t,d])=>`<div><span class="fi">${i}</span><span><b>${t}</b><small>${d}</small></span></div>`).join("")}</div>
    <div class="fgrid" style="margin-top:16px"><label class="field"><span>نام</span><input type="text" id="ob-fname" value="${esc(OB.fname||"")}" placeholder="مثلاً سارا" ${OB.nameLocked?"disabled":""}></label><label class="field"><span>نام خانوادگی</span><input type="text" id="ob-lname" value="${esc(OB.lname||"")}" placeholder="مثلاً محمدی" ${OB.nameLocked?"disabled":""}></label></div>${OB.nameLocked?`<p class="small muted" style="margin-top:8px">نام روی این شماره ثبت شده و قابل تغییر نیست؛ برای اصلاح آن با پشتیبانی تماس بگیرید.</p>`:""}`,
  ()=>`<h1>پایه و رشته</h1><p class="muted">بر این اساس، امتحان‌های اصلی و قوانین سال کنکورتان ساخته می‌شود.</p>
    <div class="stack" style="margin-top:14px"><span class="label">پایه</span><div class="seg">${[["10","دهم"],["11","یازدهم"],["12","دوازدهم"],["grad","دانش‌آموخته / پشت‌کنکوری"]].map(([v,l])=>`<label><input type="radio" name="ob-grade" value="${v}" ${OB.grade===v?"checked":""}><span>${l}</span></label>`).join("")}</div>
    <span class="label">رشته</span><div class="seg">${Object.entries(CATALOG).map(([k,v])=>`<label><input type="radio" name="ob-field" value="${k}" ${OB.field===k?"checked":""}><span>${v.label}</span></label>`).join("")}</div>
    <div class="note">سال کنکور شما: <b>${faStr(konkurYearFor(OB.grade))}</b>. ${OB.grade==="10"?"پایه دهم امتحان نهایی کشوری ندارد و مستقیم در کنکور اثر ندارد، ولی پایهٔ همه‌چیز است.":OB.grade==="11"?"امتحان‌های نهایی یازدهم امسال بخشی از سوابق تحصیلی کنکور شما می‌شود.":OB.grade==="12"?"امسال امتحان‌های نهایی دوازدهم (بزرگ‌ترین سهم سوابق) و کنکور را پیش رو دارید.":"تمرکز روی کنکور؛ در صورت نیاز ترمیم معدل هم برنامه‌ریزی می‌شود."}</div></div>`,
  ()=>`<h1>هر درس را چقدر بلدید؟</h1><p class="muted">۱ یعنی ضعیف، ۵ یعنی قوی. درس‌های ضعیف‌تر زمان بیشتری می‌گیرند.</p>
    <div class="tscroll" style="margin-top:12px"><table><tbody>${areas.map(a=>{const nm=a.names[gi]||a.name;const l=OB.levels[a.id]||3;return `<tr><td>${esc(nm)} ${a.kw?'<span class="pill p-konkur">کنکور</span>':""}</td><td><div class="lvl">${[1,2,3,4,5].map(x=>`<button type="button" data-oblvl="${a.id}:${x}" aria-pressed="${l===x}">${fa(x)}</button>`).join("")}</div></td></tr>`}).join("")}</tbody></table></div>
    ${OB.grade==="12"||OB.grade==="grad"?`<h3 style="margin-top:16px">نمره‌های امتحان نهایی پایه یازدهم (اختیاری)</h3><p class="small muted">این نمره‌ها بخشی از سوابق تحصیلی شماست. اگر هنوز ندارید، بعداً وارد کنید.</p>
      <div class="fgrid" style="margin-top:8px">${areas.filter(a=>a.names[1]).map(a=>`<label class="field"><span>${esc(a.names[1])}</span><input type="text" inputmode="decimal" data-pfa="dec" data-obs="${a.id}" value="${OB.scores[a.id]!=null?faStr(OB.scores[a.id]):""}" placeholder="از ۲۰"></label>`).join("")}</div>`:""}`,
  ()=>{const rec=recommendedHours(OB.grade,OB.field);return `<h1>زمان‌بندی روزهایت</h1><p class="muted">ساعت‌ها ۲۴ساعته‌اند (مثلاً ۱۶ یعنی ۴ عصر). ساعت خواب و بیداری، بازهٔ درس خواندن در روزهای مدرسه و بازهٔ روزهای تعطیل را انتخاب کن.</p>
    <h3 style="margin-top:16px">چند ساعت در روز می‌خواهی درس بخوانی؟</h3>
    <p class="small muted">پیشنهاد Evono برای ${({"10":"پایهٔ دهم","11":"پایهٔ یازدهم","12":"پایهٔ دوازدهم","grad":"دانش‌آموختهٔ پشت‌کنکوری"})[OB.grade]}: <b class="num">${fa(rec)} ساعت</b> در روز${rec>=6?" یا بیشتر":""}. هر عددی را بزنی، بازهٔ روزهای فعال زیر خودش را با همان مدت (از همان ساعت شروع) تنظیم می‌کند؛ بعداً هر روز را جدا هم می‌شود دستی تغییر داد.</p>
    <div class="lvl" style="margin-top:10px">${[3,4,5,6,7,8].map(h=>`<button type="button" data-obhrs="${h}" aria-pressed="${OB.dailyHours===h}">${fa(h)}</button>`).join("")}</div>
    <h3 style="margin-top:20px">خواب و بیداری</h3>
    <div class="fgrid" style="margin-top:8px"><div class="field"><span>بیداری (روز مدرسه)</span>${tp("ob-wake",OB.sleep.wake)}</div><div class="field"><span>خواب (روز مدرسه)</span>${tp("ob-bed",OB.sleep.bed)}</div>
    <div class="field"><span>بیداری (روز تعطیل)</span>${tp("ob-wake2",OB.sleep.wakeOff)}</div><div class="field"><span>خواب (روز تعطیل)</span>${tp("ob-bed2",OB.sleep.bedOff)}</div></div>
    <h3 style="margin-top:18px">روزهای مدرسه (مهر تا اردیبهشت)</h3>
    <div class="tscroll" style="margin-top:8px"><table class="avtable"><thead><tr><th>روز</th><th>فعال</th><th>از ساعت</th><th>تا ساعت</th><th>مدت</th></tr></thead><tbody>${WD.map((w,i)=>`<tr><td>${w}</td><td><input type="checkbox" data-obon="${i}" ${OB.av[i].on?"checked":""} aria-label="${w}"></td><td>${tp("ob-s-"+i,OB.av[i].start)}</td><td>${tp("ob-e-"+i,OB.av[i].end)}</td><td class="small num" id="obd-${i}">${durCell(OB.av[i].start,OB.av[i].end)}</td></tr>`).join("")}</tbody></table></div>
    <h3 style="margin-top:18px">تابستان، نوروز و فصل امتحانات</h3><p class="small muted">وقتی مدرسه نیست، از چه ساعتی تا چه ساعتی درس می‌خوانی؟</p>
    <div class="fgrid" style="margin-top:8px"><div class="field"><span>از ساعت</span>${tp("ob-hs",OB.holiday.start)}</div><div class="field"><span>تا ساعت</span>${tp("ob-he",OB.holiday.end)}</div><div class="field"><span>مدت</span><b class="num" id="obhd" style="padding-top:8px">${durCell(OB.holiday.start,OB.holiday.end)}</b></div></div>
    <div class="fgrid" style="margin-top:14px">${hmInput("ob-len",OB.sessionLen,"طول هر جلسه (پیشنهاد: ۱ ساعت)")}${hmInput("ob-brk",OB.breakLen,"استراحت بین جلسه‌ها")}</div>`},
  ()=>{const K=konkurYearFor(OB.grade);const rs=ruleSet(K);const tot=Object.values(OB.av).reduce((a,x)=>a+(x.on?x.minutes:0),0);
    const weak=areas.filter(a=>(OB.levels[a.id]||3)<=2).map(a=>a.names[gi]||a.name);
    const P=OB.prefs;
    return `<h1>ارزیابی اولیهٔ <b class='brand-word'>EvonoAI</b></h1><p class="muted">قبل از ساختن برنامه، این تصویر اولیه از وضعیت شماست.</p>
    <div class="stack" style="margin-top:14px">
    ${OB.summary?`<div class="card flat"><span class="label"><span class="ai-mark">Evono<i>AI</i></span> خلاصهٔ گفت‌وگو</span><p style="white-space:pre-wrap">${esc(OB.summary)}</p></div>`:""}
    ${P?`<div class="card flat"><span class="label">برنامه‌هایت این شکلی می‌شود</span><p>جلسه‌های ${durLabel(OB.sessionLen)} با ${durLabel(OB.breakLen)} استراحت | ${({hard_first:"اول درس سخت",easy_first:"اول درس آسان",mixed:"یکی سخت، یکی آسان"})[P.order]} | حداکثر ${fa(P.maxSubjects)} درس در روز${P.dailySubjects.length?" | هر روز: "+P.dailySubjects.map(id=>esc((CATALOG[OB.field].areas.find(a=>a.id===id)||{}).name||id)).join("، "):""}</p></div>`:""}
    ${(()=>{const bad=[];const sl=OB.sleep;const bl=(b=>b<180?b+1440:b)(toMin(fixBed(sl.bed)))-30;
      for(let i=0;i<5;i++){const a=OB.av[i];if(!a.on)continue;const st0=toMin(a.start);const st=Math.max(st0,toMin(fixWake(sl.wake))),en=Math.min(fixEnd(st0,toMin(a.end)),bl);if(en-st<30)bad.push(WD[i])}
      return bad.length?`<div class="alert"><b>روزهای ${bad.join("، ")} تقریباً هیچ زمانی برای درس ندارند.</b> معمولاً یعنی ساعت پایان قبل از شروع است یا ساعت خواب زودتر از بازهٔ درس. به مرحلهٔ قبل برگرد و ساعت‌ها را درست کن.</div>`:""})()}
    <div class="card flat"><span class="label">روزهای مدرسه</span><p>${WD.slice(0,5).map((w,i)=>{const a=OB.av[i];return `${w}: ${a.on?`${faStr(a.start)}–${faStr(a.end)}`:"تعطیل"}`}).join(" | ")}</p><p class="small muted" style="margin-top:4px">تابستان، نوروز و فصل امتحانات: ${faStr(OB.holiday.start)} تا ${faStr(OB.holiday.end)}</p></div>
    <div class="card flat"><span class="label">زمان در دسترس</span><p><b class="num">${durLabel(tot)}</b> در هفته | ${durLabel(OB.av[5].on?OB.av[5].minutes:0)} پنجشنبه و ${durLabel(OB.av[6].on?OB.av[6].minutes:0)} جمعه برای جلسه‌های عمیق‌تر | بیداری ${faStr(OB.sleep.wake)} و خواب ${faStr(OB.sleep.bed)}</p></div>
    <div class="card flat"><span class="label">اولویت‌ها</span><p>${weak.length?`درس‌هایی که زمان بیشتری می‌گیرند: <b>${weak.map(esc).join("، ")}</b>.`:"سطح درس‌ها متعادل است؛ زمان بر اساس اهمیت در امتحان‌ها تقسیم می‌شود."}</p></div>
    <div class="card flat"><span class="label">کنکور ${faStr(K)}</span><p>طبق آخرین قوانین${rs.confirmed?"":" (پیش‌نویس)"}: حدود ${fa(rs.sabeghe)}٪ سوابق تحصیلی (نهایی دوازدهم ~${fa(rs.g12)}٪، نهایی یازدهم ~${fa(rs.g11)}٪) و ${fa(rs.test)}٪ آزمون. ${OB.grade==="12"?"برای همین آمادگی امتحان نهایی دوازدهم در برنامهٔ شما وزن بالایی دارد.":OB.grade==="11"?"درس‌های نهایی یازدهم امسال مستقیم در کنکور شما اثر دارد.":""}</p></div>
    <div class="note">تاریخ امتحان‌ها تخمینی ساخته می‌شود؛ وقتی برنامهٔ رسمی اعلام شد در تنظیمات اصلاح کنید. Evono رتبه یا نمره را تضمین نمی‌کند؛ هدف، برنامه‌ای واقع‌بینانه است که با شما تغییر کند.</div></div>`}
  ][OB_STEP]();
  return `<div class="ob"><div class="card${OB_STEP===0?" ob-hero-bg":""}">${OB_STEP===0?'<span class="ob-bg" aria-hidden="true"></span>':""}${bar}${body}
    <div class="ob-foot"${OB_STEP?"":` style="justify-content:flex-end"`}>${OB_STEP?`<button class="btn" data-ob="back">قبلی</button>`:""}
    <div class="row"><button class="btn primary" data-ob="next">${OB_STEP===4?"ساختن برنامهٔ هفتهٔ من":"ادامه"}</button></div></div>
    ${OB_STEP===0?`<p class="small muted" style="margin-top:14px;text-align:center">برنامهٔ هفتگی، تایمر و گزارش‌ها از همین حالا رایگان در دسترس‌اند؛ برای گفت‌وگو با <b class='brand-word'>EvonoAI</b> لازم است یکی از اشتراک‌ها را تهیه کنی.</p>`:""}</div></div>`;
}
function collectOB(){
  const fn=$("#ob-fname"),ln=$("#ob-lname");if(fn||ln){if(fn)OB.fname=fn.value.trim();if(ln)OB.lname=ln.value.trim();OB.name=[OB.fname,OB.lname].filter(Boolean).join(" ")}
  const g=document.querySelector("input[name=ob-grade]:checked");if(g)OB.grade=g.value;
  const f=document.querySelector("input[name=ob-field]:checked");if(f)OB.field=f.value;
  document.querySelectorAll("[data-obs]").forEach(i=>{const x=toEnDigits(i.value).trim();if(x==="")delete OB.scores[i.dataset.obs];else OB.scores[i.dataset.obs]=Number(x)});
  document.querySelectorAll("[data-obon]").forEach(i=>OB.av[i.dataset.obon].on=i.checked);
  if($("#ob-s-0-h")){for(let i=0;i<7;i++){OB.av[i].start=tpVal("ob-s-"+i,OB.av[i].start);OB.av[i].end=tpVal("ob-e-"+i,OB.av[i].end)}normAv(OB.av)}
  if($("#ob-hs-h"))OB.holiday={start:tpVal("ob-hs",OB.holiday.start),end:tpVal("ob-he",OB.holiday.end)};
  if($("#ob-len-h"))OB.sessionLen=Math.max(15,Math.min(150,readHM("ob-len")||60));if($("#ob-brk-h"))OB.breakLen=Math.max(0,Math.min(45,readHM("ob-brk")));
  if($("#ob-wake-h"))OB.sleep={wake:tpVal("ob-wake","06:30"),bed:tpVal("ob-bed","23:00"),wakeOff:tpVal("ob-wake2","08:30"),bedOff:tpVal("ob-bed2","23:30")};
}
function finishOB(){
  S=freshState();
  S.profile={...S.profile,phone:OB.phone||"",name:OB.name,fname:OB.fname||"",lname:OB.lname||"",grade:OB.grade,field:OB.field,konkurYear:konkurYearFor(OB.grade),sessionLen:OB.sessionLen,breakLen:OB.breakLen,dailyGoal:(OB.dailyHours||recommendedHours(OB.grade,OB.field))*60};
  if(CARRY){ // restore what "شروع دوباره از اول" preserved: subscription, account details — never lost on re-onboarding
    if(CARRY.email)S.profile.email=CARRY.email;
    if(CARRY.avatar)S.profile.avatar=CARRY.avatar;
    if(CARRY.theme)S.profile.theme=CARRY.theme;
    S.sub=CARRY.sub;S.intents=CARRY.intents||[];S.orderSeq=CARRY.orderSeq;
    CARRY=null;
  }
  S.availability=normAv(JSON.parse(JSON.stringify(OB.av)));S.sleep={...OB.sleep};S.holiday={...OB.holiday};const fixNotes=sanitizeTimes(S.sleep,S.availability,S.holiday);if(OB.progress)S.progress=JSON.parse(JSON.stringify(OB.progress));
  S.subjects=buildSubjects(OB.field,OB.grade);S.subjects.forEach(s=>{if(OB.levels[s.id])s.level=OB.levels[s.id]});
  Object.entries(OB.scores).forEach(([k,v])=>{if(v>=0&&v<=20)S.finalScores[k]=v});
  if(OB.prefs)S.prefs={...S.prefs,...OB.prefs};S.profile.retake=!!OB.retake;
  if(OBC.turns.length)S.chat=OBC.turns.slice(-10).map(t=>({role:t.role,content:t.content}));
  buildMainExams();S.onboarded=true;planFor(todayIso(),true);ensureWeek();save();TAB="week";ANIM=true;render();
  if(fixNotes.length)showModal(`<div class="modal-icon">✓</div><h2>چند ساعت را درست کردیم</h2><p class="muted">به نظر می‌رسید این ساعت‌ها به‌اشتباه ۱۲ساعته وارد شده‌اند:</p><p class="small" style="margin-top:10px;line-height:2">${fixNotes.map(esc).join("<br>")}</p><p class="small muted" style="margin-top:8px">اگر درست نیست، از تنظیمات عوضش کن.</p><div class="row" style="justify-content:center;margin-top:18px"><button class="btn primary" data-m="close">باشه</button></div>`);
}
function bindOnboarding(){
  const oc=$("#obc");if(oc){const inp=$("#obc-in");oc.onsubmit=e=>{e.preventDefault();const t=inp.value;inp.value="";sendOB(t)};inp.onkeydown=e=>{if(e.key==="Enter"&&!e.shiftKey){e.preventDefault();oc.requestSubmit()}};const m=$("#obmsgs");if(m)m.scrollTop=m.scrollHeight;inp.focus()}
  document.querySelectorAll("[data-oblvl]").forEach(b=>b.onclick=()=>{collectOB();const [id,l]=b.dataset.oblvl.split(":");OB.levels[id]=+l;render()});
  document.querySelectorAll("[data-obhrs]").forEach(b=>b.onclick=()=>{collectOB();const h=+b.dataset.obhrs;OB.dailyHours=h;
    for(let i=0;i<7;i++)if(OB.av[i].on)OB.av[i].end=hmA(toMin(OB.av[i].start)+h*60);
    normAv(OB.av);render()});
  document.querySelectorAll("input[name=ob-grade],input[name=ob-field]").forEach(i=>i.onchange=()=>{collectOB();render()});
  document.querySelectorAll("[data-ob]").forEach(b=>b.onclick=()=>{const a=b.dataset.ob;collectOB();
    if(a==="back")OB_STEP=Math.max(0,OB_STEP-1);
    if((a==="next"||a==="chat")&&OB_STEP===0&&!(OB.fname||"").trim()){toast("لطفاً اسمت را وارد کن تا ادامه بدهیم");const el=$("#ob-fname");if(el)el.focus();return}
    if((a==="next"||a==="chat")&&OB_STEP===0&&!(OB.lname||"").trim()){toast("لطفاً نام خانوادگی‌ات را هم وارد کن تا ادامه بدهیم");const el=$("#ob-lname");if(el)el.focus();return}
    if(a==="next"&&OB_STEP===3){const bad=[0,1,2,3,4,5,6].filter(i=>OB.av[i].on&&toMin(OB.av[i].end)<=toMin(OB.av[i].start));
      if(bad.length){toast(`ساعت پایانِ ${bad.map(i=>WD[i]).join("، ")} قبل از شروع است؛ درستش کن`);return}
      if(toMin(OB.holiday.end)<=toMin(OB.holiday.start)){toast("بازهٔ روزهای تعطیل درست نیست");return}}
    if(a==="next"){if(OB_STEP===4){
      const targetMinutes=(OB.dailyHours||recommendedHours(OB.grade,OB.field))*60;
      maybeWarnSchedule(OB.av,OB.sessionLen,OB.breakLen,targetMinutes,{
        onProceed:()=>finishOB(),
        onAutoAdjust:(extendedAv)=>{OB.av=extendedAv;finishOB()}, // keeps the requested dailyHours intact; stretches whichever day(s) were too short
        onEdit:()=>{OB_STEP=3;render()}
      });
      return;
    }OB_STEP++}
    if(a==="chat"){startOBChat();return}
    if(a==="form"){OB_MODE="form";OB_STEP=1}
    if(a==="demo"){OB={...OB,name:"سارا (نمونه)",grade:"12",field:"tajrobi",levels:{bio:4,chem:2,phys:2,math:3,ar:2,en:4,fa:4,din:3},scores:{bio:17.5,chem:14.25,phys:15,math:16,geo:18,fa:18.5,ar:13.75,din:19,en:17}};finishOB();
      S.results.push({id:uid(),subjectId:"chem",kind:"practice",score:13,date:isoFromD(todayD()-3)},{id:uid(),subjectId:"phys",kind:"mock",score:22,date:isoFromD(todayD()-5)});
      S.exams.push({id:uid(),kind:"school",subjectId:"chem",title:"میان‌ترم شیمی ۳",date:isoFromD(todayD()+2),estimated:false});
      regenerateWeek();render();return}
    render();window.scrollTo({top:0})});
}

/* ================= Onboarding chat with EvonoAI ================= */
const SAVE_PROFILE_DEF={name:"save_profile",description:"Save the student's profile and plan preferences once you know enough. Builds their first week plan. Use sensible defaults for anything not mentioned.",
  inputSchema:{type:"object",properties:{
    grade:{type:"string",description:"10|11|12|grad"},field:{type:"string",description:"tajrobi|riazi|ensani"},
    levels:{type:"object",description:"subject_id -> self level 1 (weak) .. 5 (strong)"},
    availability:{type:"object",description:"keys 0..6 (0=Saturday..6=Friday) -> {on:boolean,start:'HH:MM',end:'HH:MM'}"},
    holiday_start:{type:"string",description:"study window start on no-school days (summer, Nowruz, exam season) HH:MM"},holiday_end:{type:"string"},
    progress:{type:"object",description:"subject_id -> lesson/chapter number (1-based) the class has reached in the current grade book, if the student said"},
    wake:{type:"string",description:"school-day wake time HH:MM"},bed:{type:"string",description:"school-day bed time HH:MM"},weekend_wake:{type:"string"},weekend_bed:{type:"string"},
    session_len:{type:"number"},break_len:{type:"number"},order:{type:"string",description:"hard_first|easy_first|mixed"},
    max_subjects_per_day:{type:"number"},daily_subjects:{type:"array",items:{type:"string"}},
    final_scores:{type:"object",description:"grade-11 final exam scores out of 20, subject_id -> score (grade 12 / graduates only)"},
    retake:{type:"boolean"},summary:{type:"string",description:"2-4 sentence Persian summary of the student and how their plan will look"}},
  required:["grade","field","summary"]}};
function onbRules(){
  const ids=Object.entries(CATALOG).map(([k,v])=>`${k} (${v.label}): `+v.areas.map(a=>`${a.id}=${a.name}`).join("، ")).join("\n");
  return `تو EvonoAI هستی، مشاور تحصیلی هوشمند اپلیکیشن Evono برای دانش‌آموزان ایرانی. این اولین گفت‌وگو با دانش‌آموزی به نام «${OB.name||"دانش‌آموز"}» است تا برنامهٔ درسی شخصی‌اش را بسازی.
لحن: صمیمی، گرم، کوتاه، فارسی، با «تو». در هر پیام حداکثر دو سؤال بپرس. اگر چیزی را خودش گفت دوباره نپرس.
باید بفهمی:
۱) پایه (دهم، یازدهم، دوازدهم یا دانش‌آموخته) و رشته (تجربی، ریاضی، انسانی)
۲) درس‌های قوی و ضعیفش
۳) ساعت بیداری و خواب (روزهای مدرسه و پنجشنبه/جمعه) و بازهٔ درس خواندن هر روز: از چه ساعتی تا چه ساعتی؛ پنجشنبه و جمعه (معمولاً تعطیل‌اند)
۳ب) در تابستان، نوروز و فصل امتحانات (وقتی مدرسه نیست) از چه ساعتی تا چه ساعتی درس می‌خواند (holiday_start/holiday_end).
۳ج) کلاسش در درس‌های اصلی به کدام فصل رسیده (اختیاری؛ اگر اول سال است از فصل ۱).
۴) دوست دارد برنامه‌اش چطور باشد: هر جلسه چند دقیقه، استراحت چقدر، اول درس سخت یا آسان، چند درس در روز، درسی که بخواهد هر روز باشد
۵) فقط برای پایه دوازدهم یا دانش‌آموخته: نمره‌های امتحان نهایی یازدهم اگر یادش هست (اختیاری)
هدف Evono آمادگی برای امتحان نهایی یازدهم، نهایی دوازدهم و کنکور است. رتبه یا نمره را تضمین نکن.
بپرس چقدر جدی می‌خواهد درس بخواند. توصیهٔ Evono: هر جلسهٔ مطالعه دست‌کم ۱ ساعت باشد، و کسی که می‌خواهد جدی بخواند روزی ۶ ساعت یا بیشتر درس بخواند (در پنجشنبه و جمعه بیشتر). این را با مهربانی پیشنهاد بده و بازهٔ درس خواندنش را بر همین اساس تنظیم کن، ولی ساعت خواب و مدرسه‌اش را رعایت کن.
وقتی اطلاعات کافی داری (معمولاً بعد از ۴ تا ۶ پیام)، یک خلاصهٔ کوتاه بگو و ابزار save_profile را صدا بزن. هر چیزی را که نگفت با پیش‌فرض معقول پر کن (جلسه ۱ ساعت، استراحت ۱۰ دقیقه، اول درس سخت، حداکثر ۴ درس در روز).
شناسهٔ درس‌ها:
${ids}
در availability: 0=شنبه، 1=یکشنبه، 2=دوشنبه، 3=سه‌شنبه، 4=چهارشنبه، 5=پنجشنبه، 6=جمعه؛ هر روز {on, start, end}. ساعت را HH:MM با ارقام انگلیسی بده. مدت‌ها را در صحبت به صورت ساعت و دقیقه بگو.`;
}
function applyOBProfile(p){
  const g=String(p&&p.grade||"");if(!["10","11","12","grad"].includes(g))throw new Error("پایه نامعتبر است");
  const f=String(p.field||"");if(!CATALOG[f])throw new Error("رشته نامعتبر است");
  OB.grade=g;OB.field=f;const ids=CATALOG[f].areas.map(a=>a.id);
  OB.levels={};Object.entries(p.levels||{}).forEach(([k,v])=>{if(ids.includes(k))OB.levels[k]=Math.max(1,Math.min(5,Math.round(+v)||3))});
  const okT=v=>/^\d{1,2}:\d{2}$/.test(String(v||""));
  OB.av=DEFAULT_AV();Object.entries(p.availability||{}).forEach(([k,v])=>{const i=+k;if(i>=0&&i<=6&&v&&typeof v==="object"){const st=okT(v.start)?hmA(toMin(v.start)):OB.av[i].start;
    const en=okT(v.end)?hmA(toMin(v.end)):v.minutes!=null?hmA(toMin(st)+Math.max(0,Math.round(+v.minutes)||0)):OB.av[i].end;OB.av[i]={on:v.on!==false,start:st,end:en}}});normAv(OB.av);
  OB.sleep={wake:okT(p.wake)?hmA(toMin(p.wake)):"06:30",bed:okT(p.bed)?hmA(toMin(p.bed)):"23:00",wakeOff:okT(p.weekend_wake)?hmA(toMin(p.weekend_wake)):(okT(p.wake)?hmA(toMin(p.wake)+120):"08:30"),bedOff:okT(p.weekend_bed)?hmA(toMin(p.weekend_bed)):(okT(p.bed)?hmA(toMin(p.bed)+30):"23:30")};
  if(p.session_len!=null)OB.sessionLen=Math.max(15,Math.min(150,Math.round(+p.session_len)||60));
  if(p.break_len!=null)OB.breakLen=Math.max(0,Math.min(45,Math.round(+p.break_len)||0));
  OB.prefs={order:["hard_first","easy_first","mixed"].includes(p.order)?p.order:"hard_first",maxSubjects:Math.max(1,Math.min(8,Math.round(+p.max_subjects_per_day)||4)),
    dailySubjects:(Array.isArray(p.daily_subjects)?p.daily_subjects:[]).map(String).filter(x=>ids.includes(x)),notes:String(p.summary||"").slice(0,300)};
  OB.scores={};Object.entries(p.final_scores||{}).forEach(([k,v])=>{if(ids.includes(k)&&+v>=0&&+v<=20)OB.scores[k]=+v});
  if(okT(p.holiday_start)&&okT(p.holiday_end)&&toMin(p.holiday_end)>toMin(p.holiday_start))OB.holiday={start:hmA(toMin(p.holiday_start)),end:hmA(toMin(p.holiday_end))};
  OB.progress={};Object.entries(p.progress||{}).forEach(([k,v])=>{if(ids.includes(k)&&+v>=1)OB.progress[k]={f:Math.round(+v)-1,k:0}});
  OB.retake=!!p.retake;OB.summary=String(p.summary||"").slice(0,700);OBC.done=true;
  return{ok:true,message:"پروفایل ذخیره شد؛ برنامهٔ هفته ساخته می‌شود"};
}
function startOBChat(){
  OB_MODE="chat";if(!OB.trialStart)OB.trialStart=Date.now();
  if(!OBC.turns.length)OBC.turns.push({role:"assistant",content:`سلام${OB.name?" "+OB.name:""}! 👋 من EvonoAI هستم، مشاور تحصیلی‌ات.\nمی‌خواهم با چند سؤال کوتاه بشناسمت تا برنامه‌ای بسازم که واقعاً به کارت بیاید.\n\nاول بگو: کلاس چندمی و چه رشته‌ای می‌خوانی؟`});
  ANIM=true;render();
}
function renderOBChat(){
  return `<div class="ob ob-chat"><section class="card chat">
    <div class="card-h"><div><h2><span class="ai-mark">Evono<i>AI</i></span> آشنایی</h2><p class="small muted">بگو برنامه‌ات را چطور دوست داری؛ بقیه‌اش با من.</p></div>
      <div class="row"><span class="badge ghost">۷ روز رایگان</span><button class="btn sm ghost" data-ob="form">با فرم ادامه می‌دهم</button></div></div>
    <div class="msgs" id="obmsgs">${OBC.turns.map(renderMsg).join("")}</div>
    <div class="quick">${["پایه دوازدهم تجربی هستم","شیمی و فیزیکم ضعیفه","بعد از مدرسه از ساعت ۵ تا ۱۰ وقت دارم","دوست دارم جلسه‌ها کوتاه باشند"].map(q=>`<button type="button" data-obq="${esc(q)}">${esc(q)}</button>`).join("")}</div>
    <form class="composer" id="obc"><textarea id="obc-in" placeholder="جوابت را بنویس…" aria-label="پیام به EvonoAI"></textarea><button class="btn primary" ${OBC.busy?"disabled":""}>ارسال</button></form>
  </section></div>`;
}
async function sendOB(text){
  if(OBC.busy||!text.trim())return;
  OBC.turns.push({role:"user",content:text.trim()});OBC.busy=true;render();
  const box=$("#obmsgs");const bubble=document.createElement("div");bubble.className="msg a thinking";bubble.textContent="در حال فکر کردن…";box.appendChild(bubble);box.scrollTop=box.scrollHeight;
  const apiTools=toApiTools([SAVE_PROFILE_DEF]);
  let msgs=OBC.turns.map(m=>({role:m.role,content:m.content}));
  try{
    let reply="";
    for(let loop=0;loop<4;loop++){
      const result=await aiChatWithTools(msgs,onbRules(),apiTools);
      if(result.text){reply=result.text;bubble.classList.remove("thinking");bubble.textContent=result.text;box.scrollTop=box.scrollHeight}
      if(!result.toolUse||!result.toolUse.length)break;
      bubble.textContent="در حال ساختن برنامه…";
      msgs.push({role:"assistant",content:(result.raw&&result.raw.content)||[]});
      const toolResults=result.toolUse.map(tu=>{
        try{const r=applyOBProfile(tu.input);return{type:"tool_result",tool_use_id:tu.id,content:JSON.stringify(r)}}
        catch(e){return{type:"tool_result",tool_use_id:tu.id,content:JSON.stringify({error:e.message}),is_error:true}}
      });
      msgs.push({role:"user",content:toolResults});
    }
    OBC.turns.push({role:"assistant",content:reply||"…"});
  }catch(e){
    OBC.turns.push({role:"assistant",content:"خطا در ارتباط با سرور؛ دوباره بفرست یا با فرم ادامه بده."});
  }finally{OBC.busy=false;if(OBC.done){OB_MODE="form";OB_STEP=4;ANIM=true}render()}
}
document.addEventListener("click",e=>{const q=e.target.closest&&e.target.closest("[data-obq]");if(q){const i=$("#obc-in");if(i){i.value=q.dataset.obq;i.focus()}}});

/* ================= Session timer ================= */
const BASE_TITLE="Evono";
const fmtClock=ms=>{const s=Math.max(0,Math.ceil(ms/1000));const h=Math.floor(s/3600),m=Math.floor(s%3600/60),x=s%60;return faStr(h?`${h}:${String(m).padStart(2,"0")}:${String(x).padStart(2,"0")}`:`${String(m).padStart(2,"0")}:${String(x).padStart(2,"0")}`)};
function timerLeft(){const T=S.timer;if(!T)return 0;return T.paused?T.remaining:T.endAt-Date.now()}
function renderTimerBar(){
  const T=S.timer;
  if(!T){const nxt=(S.plans[todayIso()]?.tasks||[]).find(x=>x.status==="todo");return nxt?`<div class="nexthint">جلسهٔ بعد: <b>${esc(taskSubName(nxt))}</b> | ساعت ${hm(nxt.start)} | ${durLabel(nxt.minutes)} <button class="btn sm" data-start-top="${nxt.id}">شروع</button></div>`:""}
  const frac=Math.max(0,Math.min(1,1-timerLeft()/(T.minutes*60000)));
  return `<div class="timerbar ${T.paused?"paused":""}" role="timer" aria-live="off"><span class="tdot" aria-hidden="true"></span><span class="tlabel">${T.kind==="break"?"استراحت":esc(T.label)}</span>
    <strong id="tleft">${fmtClock(timerLeft())}</strong><span class="small muted">${T.paused?"متوقف":"زمان باقی‌مانده"}</span>
    <span class="tacts"><button class="btn sm" data-timer="pause">${T.paused?"ادامه":"توقف موقت"}</button><button class="btn sm ghost" data-timer="stop">${T.kind==="break"?"پایان استراحت":"پایان جلسه"}</button></span>
    <i id="tprog" class="tprog" style="transform:scaleX(${frac})"></i></div>`;
}
let AC=null;
function unlockAudio(){try{AC=AC||new (window.AudioContext||window.webkitAudioContext)();if(AC.state==="suspended")AC.resume()}catch(e){}}
function chime(){try{if(!AC)return;const t0=AC.currentTime+.05;[0,.25,.5,1.1,1.35,1.6].forEach((d,i)=>{const o=AC.createOscillator(),g=AC.createGain();o.type="sine";o.frequency.value=[880,1175,1568,880,1175,1568][i];
  g.gain.setValueAtTime(.0001,t0+d);g.gain.exponentialRampToValueAtTime(.22,t0+d+.02);g.gain.exponentialRampToValueAtTime(.0001,t0+d+.55);o.connect(g);g.connect(AC.destination);o.start(t0+d);o.stop(t0+d+.6)})}catch(e){}}
async function askNotify(){try{if("Notification" in window&&Notification.permission==="default")await Notification.requestPermission()}catch(e){}}
const NOTIF_ICON="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 64 64'%3E%3Crect width='64' height='64' rx='14' fill='%2323262B'/%3E%3Ctext x='32' y='43' font-family='Arial,Helvetica,sans-serif' font-size='32' font-weight='700' fill='%23fff' text-anchor='middle'%3EE%3C/text%3E%3C/svg%3E";
function notify(title,body){try{if("Notification" in window&&Notification.permission==="granted")new Notification(title,{body,icon:NOTIF_ICON,badge:NOTIF_ICON})}catch(e){}try{navigator.vibrate&&navigator.vibrate([250,120,250])}catch(e){}}
function startSession(dateIso,id){
  const p=S.plans[dateIso];const k=p&&p.tasks.find(x=>x.id===id);if(!k)return;
  if(S.timer&&S.timer.kind==="study"&&S.timer.taskId!==id){const q=S.plans[S.timer.date]?.tasks.find(x=>x.id===S.timer.taskId);if(q&&q.status==="doing")q.status="todo"}
  k.status="doing";k.startedAt=Date.now();
  S.timer={kind:"study",date:dateIso,taskId:id,label:taskSubName(k)+(k.lesson?" | "+k.lesson.split(" — ")[0]:""),minutes:k.minutes,endAt:Date.now()+k.minutes*60000,paused:false};
  unlockAudio();askNotify();save();toast(`تایمر ${durLabel(k.minutes)} شروع شد`);render();
}
function startBreak(){const B=+S.profile.breakLen||0;if(!B)return;unlockAudio();S.timer={kind:"break",label:"استراحت",minutes:B,endAt:Date.now()+B*60000,paused:false};save();render()}
function pauseTimer(){const T=S.timer;if(!T)return;if(T.paused){T.endAt=Date.now()+T.remaining;T.paused=false}else{T.remaining=T.endAt-Date.now();T.paused=true}save();render()}
function stopTimer(){
  const T=S.timer;if(!T)return;S.timer=null;
  if(T.kind==="study"){const k=S.plans[T.date]?.tasks.find(x=>x.id===T.taskId);const left=T.paused?T.remaining:T.endAt-Date.now();const mins=Math.round((T.minutes*60000-left)/60000);
    if(k&&k.status==="doing"){if(mins>=5){setTaskStatus(T.date,T.taskId,"done",mins);toast(`${durLabel(mins)} ثبت شد ✓`)}else{k.status="todo";toast("جلسه متوقف شد")}}}
  save();render();maybeReport();
}
function timerEnd(silent){
  const T=S.timer;if(!T)return;S.timer=null;
  const nxt=()=> (S.plans[todayIso()]?.tasks||[]).find(x=>x.status==="todo");
  if(T.kind==="study"){
    const k=S.plans[T.date]?.tasks.find(x=>x.id===T.taskId);if(k&&k.status==="doing")setTaskStatus(T.date,T.taskId,"done");
    const n=nxt();if(!n&&maybeReport()){document.title=BASE_TITLE;save();render();return}
    if(!silent){chime();notify("زمان جلسه تمام شد ✓",`${T.label} | ${durLabel(T.minutes)} ثبت شد`)}
    showModal(`<div class="modal-icon">✓</div><h2>زمان جلسه تمام شد</h2><p class="muted">${esc(T.label)} | ${durLabel(T.minutes)} در برنامهٔ تو ثبت شد. آفرین!</p>
      ${n?`<p class="small" style="margin-top:10px">بعدی: <b>${esc(taskSubName(n))}</b> | ${durLabel(n.minutes)}</p>`:`<p class="small" style="margin-top:10px">جلسه‌های امروز تمام شد. گزارش روزانه را ثبت کن.</p>`}
      <div class="row" style="justify-content:center;margin-top:20px">${n&&+S.profile.breakLen>0?`<button class="btn primary" data-m="break">استراحت ${fa(S.profile.breakLen)} دقیقه‌ای</button>`:""}${n?`<button class="btn" data-m="next" data-id="${n.id}">شروع جلسهٔ بعد</button>`:`<button class="btn primary" data-m="report">گزارش روزانه</button>`}<button class="btn ghost" data-m="close">بستن</button></div>`);
  }else{
    const n=nxt();if(!silent){chime();notify("استراحت تمام شد","وقت جلسهٔ بعد است")}
    showModal(`<div class="modal-icon">⏱</div><h2>استراحت تمام شد</h2>${n?`<p class="muted">جلسهٔ بعد: ${esc(taskSubName(n))} | ${durLabel(n.minutes)}</p>`:""}
      <div class="row" style="justify-content:center;margin-top:20px">${n?`<button class="btn primary" data-m="next" data-id="${n.id}">شروع جلسه</button>`:""}<button class="btn ghost" data-m="close">بستن</button></div>`);
  }
  document.title=BASE_TITLE;save();render();
}
let LASTMIN=-1;const FIRED=new Set();
function notifState(){try{if(!("Notification" in window))return "این مرورگر اعلان سیستم ندارد (یادآور داخل Evono کار می‌کند)";return {granted:"فعال",denied:"مسدود — از تنظیمات مرورگر فعال کن",default:"هنوز فعال نشده"}[Notification.permission]||"نامشخص"}catch(e){return "در دسترس نیست"}}
function maybeReport(){
  const d=todayIso();const p=S.plans[d];if(!p||!S.onboarded||(S.remind&&S.remind.report===false))return false;
  if(S.reports.some(r=>r.date===d)||FIRED.has(d+"|report"))return false;
  if(p.tasks.some(t=>t.status==="todo"||t.status==="doing"))return false;
  const done=p.tasks.filter(t=>t.status==="done");if(!done.length)return false;
  FIRED.add(d+"|report");const mins=done.reduce((a,t)=>a+(t.actual||t.minutes),0);
  chime();notify("برنامهٔ امشب تمام شد 🎉",`امروز ${durLabel(mins)} درس خواندی؛ گزارش روزانه را ثبت کن`);
  showModal(`<div class="modal-icon">✓</div><h2>برنامهٔ امشب تمام شد</h2><p class="muted">آفرین! امروز <b>${durLabel(mins)}</b> در ${fa(done.length)} جلسه درس خواندی.</p>
    <p class="small" style="margin-top:10px">حالا گزارش امروز را ثبت کن تا <b class='brand-word'>EvonoAI</b> برنامهٔ فردا را دقیق‌تر بسازد.</p>
    <div class="row" style="justify-content:center;margin-top:20px"><button class="btn primary" data-m="report">ثبت گزارش</button><button class="btn ghost" data-m="close">بعداً</button></div>`);
  return true;
}
function checkReminders(){
  const m=nowMin();if(m===LASTMIN)return;LASTMIN=m;if(!S.onboarded)return;
  const d=todayIso(),R=S.remind||{},sl=sleepFor(d),p=S.plans[d];
  const fire=(key,fn)=>{const k=d+"|"+key;if(FIRED.has(k))return;FIRED.add(k);fn()};
  if(R.wake!==false&&m===toMin(sl.wake))fire("wake",()=>{const q=planFor(d);const tot=q.tasks.reduce((a,t)=>a+t.minutes,0);chime();notify("صبح بخیر ☀",tot?`امروز ${durLabel(tot)} برنامه داری؛ اولین جلسه ساعت ${faStr(hmA(q.tasks[0].start))}`:"امروز روز استراحت است");toast(tot?`صبح بخیر! امروز ${durLabel(tot)} برنامه داری`:"صبح بخیر! امروز روز استراحت است")});
  const bed=toMin(sl.bed)<180?toMin(sl.bed)+1440:toMin(sl.bed);
  if(R.bed!==false&&m===(bed-30)%1440)fire("bed",()=>{chime();notify("وقت خواب نزدیک است ☾","۳۰ دقیقه تا ساعت خواب؛ گوشی را کنار بگذار. خواب کافی به حافظه کمک می‌کند.");toast("۳۰ دقیقه تا وقت خواب ☾")});
  if(p&&!S.timer)p.tasks.forEach(t=>{if(t.status!=="todo")return;
    if(R.pre!==false&&m===t.start-5)fire("pre"+t.id,()=>{notify("۵ دقیقه تا جلسهٔ بعد",`${taskSubName(t)} ساعت ${faStr(hmA(t.start))}`);toast(`۵ دقیقه تا ${taskSubName(t)}`)});
    if(R.session!==false&&m===t.start)fire("s"+t.id,()=>{chime();notify("وقت شروع جلسه است ⏱",`${taskSubName(t)} | ${durLabel(t.minutes)}`);showModal(`<div class="modal-icon">⏱</div><h2>وقت ${esc(taskSubName(t))} است</h2><p class="muted">${esc(t.type)} | ${durLabel(t.minutes)}</p><div class="row" style="justify-content:center;margin-top:20px"><button class="btn primary" data-m="next" data-id="${t.id}">شروع تایمر</button><button class="btn ghost" data-m="close">بعداً</button></div>`)})});
}
document.addEventListener("pointerdown",()=>unlockAudio(),{once:true});
function tick(){
  try{checkReminders()}catch(e){}
  const T=S.timer;if(!T){if(document.title!==BASE_TITLE)document.title=BASE_TITLE;return}
  const left=timerLeft();const el=document.getElementById("tleft");if(el)el.textContent=fmtClock(left);
  const pr=document.getElementById("tprog");if(pr)pr.style.transform=`scaleX(${Math.max(0,Math.min(1,1-left/(T.minutes*60000)))})`;
  document.title=`${fmtClock(left)} | ${T.kind==="break"?"استراحت":T.label}`;
  if(!T.paused&&left<=0)timerEnd(false);
}
setInterval(tick,1000);
document.addEventListener("visibilitychange",tick);
document.addEventListener("click",e=>{const b=e.target.closest&&e.target.closest("[data-start-top]");if(b)startSession(todayIso(),b.dataset.startTop)});

function editCurr(id){const s=subById(id);if(!s)return;const gi=curGi();const L=bookLessons(id,gi);
  showModal(`<div class="modal-inner"><h2>فهرست فصل‌ها و درس‌های ${esc(courseName(s,S.profile.grade==="grad"?"12":S.profile.grade))}</h2><p class="small muted" style="margin:6px 0 12px">هر خط یک جلسهٔ درسی است (مثلاً «فصل ۲: دینامیک — بخش ۱»). اگر کتاب شما با این فهرست فرق دارد، اینجا درستش کن.</p>
    <textarea class="edit-ta" id="curr-ta">${esc(L.join("\n"))}</textarea>
    <div class="row" style="justify-content:flex-start;margin-top:14px"><button class="btn primary" data-m="savecurr" data-id="${id}">ذخیره</button><button class="btn" data-m="resetcurr" data-id="${id}">بازگشت به فهرست پیش‌فرض</button><button class="btn ghost" data-m="close">انصراف</button></div></div>`,true)}
/* ================= Modal ================= */
function showModal(html,wide){closeModal();const o=document.createElement("div");o.className="modal-bg";o.innerHTML=`<div class="modal ${wide?"wide":""}" role="dialog" aria-modal="true">${html}</div>`;document.body.appendChild(o);
  o.addEventListener("click",e=>{if(e.target===o){closeModal();return}const b=e.target.closest("[data-m]");if(!b)return;const m=b.dataset.m;
    if(m==="retrybuy"){closeModal();showCheckout(b.dataset.id);return}
    if(m==="savecurr"||m==="resetcurr"){const id=b.dataset.id,gi=curGi();S.currOv=S.currOv||{};S.currOv[id]=S.currOv[id]||{};
      if(m==="savecurr"){const lines=($("#curr-ta").value||"").split("\n").map(x=>x.trim()).filter(Boolean).slice(0,200);S.currOv[id][gi]=lines}else delete S.currOv[id][gi];
      const sb=subById(id);if(sb){const P=prog(sb);P.f=Math.min(P.f,finalLessons(sb).length)}closeModal();regenerateWeek();toast("فهرست فصل‌ها ذخیره شد و برنامه به‌روز شد");render();return}
    closeModal();
    if(m==="break")startBreak();if(m==="next")startSession(todayIso(),b.dataset.id);if(m==="plans"){TAB="plans";ANIM=true;render()}if(m==="report"){TAB="report";ANIM=true;render()}});
  const f=o.querySelector(".btn.primary,.btn");if(f)f.focus()}
function closeModal(){document.querySelectorAll(".modal-bg").forEach(x=>x.remove())}
document.addEventListener("keydown",e=>{if(e.key==="Escape")closeModal()});

/* ================= Schedule-feasibility warning =================
   Session length + break length + daily availability window can conflict with the daily study-hours
   target the student asked for (e.g. wants 6h/day but only picked a 6h window with a 1.5h/15m rhythm,
   which eats time on breaks and can't actually deliver 6 full hours). Used from onboarding's final step
   and from Profile/Settings saves — never mid-typing, only right when the values are about to be locked in. */
function scheduleFits(av,sessionLen,breakLen){
  const sl=+sessionLen||0,bl=+breakLen||0;const cycle=sl+bl;
  let minCap=null,worstDay=null;
  for(let i=0;i<7;i++){
    const a=av&&av[i];if(!a||!a.on)continue;
    const win=Math.max(0,toMin(a.end)-toMin(a.start));
    const cap=cycle>0?Math.min(win,Math.max(0,Math.floor((win+bl)/cycle))*sl):win;
    if(minCap===null||cap<minCap){minCap=cap;worstDay=i}
  }
  return minCap===null?{maxMinutes:Infinity,worstDay:null}:{maxMinutes:minCap,worstDay};
}
// Minimum availability-window length needed to actually deliver `targetMinutes` of net study time
// with this session/break rhythm (n sessions back-to-back need only n-1 breaks between them).
function requiredWindowMinutes(sessionLen,breakLen,targetMinutes){
  const s=+sessionLen||0,b=+breakLen||0;
  if(s<=0||targetMinutes<=0)return 0;
  const n=Math.ceil(targetMinutes/s);
  return n*s+Math.max(0,n-1)*b;
}
// "Auto-fix" keeps the student's requested daily-hours target exactly as asked and instead stretches
// whichever day(s) are too short to fit it — never quietly lowers the target itself.
function extendAvToFit(av,sessionLen,breakLen,targetMinutes){
  const need=requiredWindowMinutes(sessionLen,breakLen,targetMinutes);
  const out=JSON.parse(JSON.stringify(av||{}));
  for(let i=0;i<7;i++){
    const a=out[i];if(!a||!a.on)continue;
    const win=Math.max(0,toMin(a.end)-toMin(a.start));
    if(win<need)a.end=hmA(toMin(a.start)+need);
  }
  return normAv(out);
}
function maybeWarnSchedule(av,sessionLen,breakLen,targetMinutes,cbs){
  const fit=scheduleFits(av,sessionLen,breakLen);
  if(!(targetMinutes>fit.maxMinutes+0.5)){cbs.onProceed();return}
  const extendedAv=extendAvToFit(av,sessionLen,breakLen,targetMinutes);
  showScheduleWarning({targetMinutes,maxMinutes:fit.maxMinutes,worstDay:fit.worstDay,sessionLen,breakLen,extendedAv,...cbs});
}
function showScheduleWarning(cfg){
  const {targetMinutes,maxMinutes,worstDay,sessionLen,breakLen,extendedAv,onProceed,onAutoAdjust,onEdit}=cfg;
  document.querySelectorAll(".modal-bg.sched-warn").forEach(x=>x.remove()); // don't touch any other open modal (e.g. Settings) behind it
  const dayNote=worstDay!=null?`روزِ ${WD[worstDay]} با این بازهٔ زمانی`:"بازهٔ زمانیِ روزهای درس‌خواندنت";
  const maxTxt=maxMinutes<=0?"صفر دقیقه":durLabel(Math.floor(maxMinutes));
  const targetTxt=durLabel(Math.round(targetMinutes));
  const o=document.createElement("div");o.className="modal-bg sched-warn";o.style.zIndex="70";
  o.innerHTML=`<div class="modal" role="dialog" aria-modal="true">
    <div class="modal-icon">!</div>
    <h2>این برنامه جا نمی‌شود</h2>
    <p class="muted">با جلسه‌های ${durLabel(Math.round(+sessionLen||0))}${breakLen>0?` و استراحت ${durLabel(Math.round(+breakLen||0))} بین‌شان`:""}، ${dayNote} فقط ${maxTxt} مطالعهٔ واقعی جا می‌شود؛ نه ${targetTxt} که خواسته‌ای.</p>
    <p class="small muted" style="margin-top:8px">می‌خواهی چطور ادامه بدهیم؟</p>
    <div class="stack" style="margin-top:18px;gap:8px">
      <button class="btn primary" id="sw-auto">خودش تنظیم کند (${targetTxt} در روز)</button>
      <button class="btn" id="sw-edit">برگردم و دستی تغییرش بدهم</button>
      <button class="btn ghost" id="sw-ok">مهم نیست، همینطور ادامه بده</button>
    </div>
    <p class="small muted" style="margin-top:10px">«خودش تنظیم کند» هدف ${targetTxt} در روزت را دست‌نخورده نگه می‌دارد و به‌جایش بازهٔ زمانیِ روزهایی که کم می‌آورند را کمی می‌کِشد.</p>
  </div>`;
  document.body.appendChild(o);
  const done=fn=>{o.remove();if(fn)fn()};
  o.addEventListener("click",e=>{if(e.target===o)done(onEdit)});
  o.querySelector("#sw-ok").onclick=()=>done(onProceed);
  o.querySelector("#sw-auto").onclick=()=>done(()=>onAutoAdjust(extendedAv));
  o.querySelector("#sw-edit").onclick=()=>done(onEdit);
  const f=o.querySelector(".btn.primary");if(f)f.focus();
}
/* Generic "are you sure?" confirmation for buttons that overwrite something the student may not want
   thrown away (e.g. بازسازی هفته discards every not-yet-done session of the week and rebuilds from
   scratch). title/body explain exactly what's about to change; onYes runs only if confirmed. */
function confirmImportant({title,body,confirmLabel,onYes}){
  document.querySelectorAll(".modal-bg.confirm-important").forEach(x=>x.remove());
  const o=document.createElement("div");o.className="modal-bg confirm-important";o.style.zIndex="70";
  o.innerHTML=`<div class="modal" role="dialog" aria-modal="true">
    <div class="modal-icon">!</div>
    <h2>${esc(title)}</h2>
    <p class="muted">${esc(body)}</p>
    <div class="stack" style="margin-top:18px;gap:8px">
      <button class="btn primary" id="ci-yes">${esc(confirmLabel||"بله، مطمئنم")}</button>
      <button class="btn ghost" id="ci-no">انصراف</button>
    </div>
  </div>`;
  document.body.appendChild(o);
  const done=go=>{o.remove();if(go&&onYes)onYes()};
  o.addEventListener("click",e=>{if(e.target===o)done(false)});
  o.querySelector("#ci-yes").onclick=()=>done(true);
  o.querySelector("#ci-no").onclick=()=>done(false);
  o.querySelector(".btn.primary").focus();
}

/* ================= Subscriptions ================= */
/* There is no free trial: a brand-new student can use everything that doesn't need EvonoAI (weekly plan,
   timer, reminders, reports) right away, but EvonoAI itself (chat, report analysis, weekly review) is
   locked until an active subscription exists. */
function subActive(){return !!(S.sub&&S.sub.until>Date.now())}
/* EvonoAI message allowance: every message the student sends (chat, report analysis, weekly review) counts as one.
   Automatic retries and tool rounds inside one answer do not count.
   Each plan's own duration is also its reset period, so a weekly sub gets its 25 messages once for the week,
   a monthly sub gets its 100 messages fresh every 30 days, and the 3-month sub gets its 300 messages once
   for the whole quarter (no mid-plan top-up). */
const MONTH_MS=30*86400000;
const AI_QUOTA={weekly:25,monthly:100,quarter:300};
const PLAN_MS={weekly:7*86400000,monthly:MONTH_MS,quarter:90*86400000};
const PERIOD_LABEL={weekly:"این هفته",monthly:"این ماه",quarter:"این دوره"};
function periodLabel(){return PERIOD_LABEL[S.sub&&S.sub.plan]||"این دوره"}
function subPlan(){return subActive()?(S.sub.plan||"monthly"):null}
function aiQuota(){const p=subPlan();return p&&AI_QUOTA[p]?AI_QUOTA[p]:null}
function aiPeriod(){const pm=PLAN_MS[S.sub.plan]||MONTH_MS;const st=S.sub.start||(S.sub.until-pm);const n=Math.max(0,Math.floor((Date.now()-st)/pm));return{start:st+n*pm,end:Math.min(st+(n+1)*pm,S.sub.until)}}
function aiUsed(){if(!aiQuota())return 0;const u=S.aiUse;return u&&u.start===aiPeriod().start?u.n:0}
/* Messages bought on the "پیام اضافه" card (اشتراک tab) — a running pool on top of the plan's own
   period quota, synced from the backend's own count (see syncSubscription) and spent only once the
   period quota itself is used up (see useAI below), so it never resets with a new period until the
   student actually uses it up. */
function aiExtraLeft(){return Math.max(0,(S.aiExtra||0)-(S.aiExtraUsed||0))}
function aiPeriodLeft(){const q=aiQuota();return q==null?Infinity:Math.max(0,q-aiUsed())}
function aiLeft(){const pl=aiPeriodLeft();return pl===Infinity?Infinity:pl+aiExtraLeft()}
function aiAllowed(){return subActive()&&aiLeft()>0} // no subscription (new or lapsed) => no EvonoAI, no exceptions
function subLapsed(){return !subActive()&&!!S.sub} // subscribed before, not renewed — different message than "never subscribed"
function useAI(){const q=aiQuota();if(!q)return;const st=aiPeriod().start;if(!S.aiUse||S.aiUse.start!==st)S.aiUse={start:st,n:0};
  if(S.aiUse.n<q)S.aiUse.n++;else S.aiExtraUsed=(S.aiExtraUsed||0)+1;
  save();
  const l=aiLeft();if(l===10)toast("فقط ۱۰ پیام EvonoAI تا آخر این دوره باقی مانده");else if(l===0)toast("پیام‌های EvonoAI این دوره تمام شد")}
function faDateMs(ms){const j=d2j(todayD()+Math.round((ms-Date.now())/86400000));return `${fa(j.jd)} ${JM[j.jm-1]}`}
function quotaBar(compact){const q=aiQuota();if(!q)return"";const l=aiLeft();const pct=Math.min(100,Math.round(l/q*100));
  const extra=aiExtraLeft();
  return `<div class="quota ${l===0?"out":l<=10?"low":""}"><div class="q-top"><span><span class="ai-mark">Evono<i>AI</i></span> ${periodLabel()}: <b class="num">${fa(l)}</b> از <span class="num">${fa(q)}</span> پیام باقی مانده${extra>0?` <span class="small muted">(${fa(extra)} پیام اضافه)</span>`:""}</span>${compact?"":`<span class="small muted">شارژ دوباره: ${faDateMs(aiPeriod().end)}</span>`}</div><div class="q-track"><i style="width:${pct}%"></i></div></div>`}
function paywall(){if(subActive()&&aiLeft()<=0){const p=PLANS.find(x=>x.id===subPlan());const q=aiQuota();showModal(`<div class="modal-icon">✦</div><h2>پیام‌های <b class='brand-word'>EvonoAI</b> ${periodLabel()} تمام شد</h2><p class="muted">اشتراک ${p?esc(p.name):""} شامل <b class="num">${fa(q)}</b> پیام با <b class='brand-word'>EvonoAI</b> است و همه را استفاده کرده‌ای. پیام‌هایت <b>${faDateMs(aiPeriod().end)}</b> دوباره شارژ می‌شود.</p><p class="small muted" style="margin-top:8px">برنامهٔ هفته، تایمر، یادآورها و گزارش‌ها بدون محدودیت کار می‌کنند.</p>
  <div class="row" style="justify-content:center;margin-top:20px"><button class="btn primary" data-m="plans">ارتقای اشتراک</button><button class="btn ghost" data-m="close">باشه</button></div>`);return}
  if(S.sub){showModal(`<div class="modal-icon">✦</div><h2>اشتراک شما تمام شده است</h2><p class="muted">برای ادامهٔ گفت‌وگو و تحلیل‌های <b class='brand-word'>EvonoAI</b> باید اشتراکت را تمدید کنی. برنامهٔ هفته، تایمر، یادآورها و گزارش‌ها بدون اشتراک هم کار می‌کنند.</p>
  <div class="row" style="justify-content:center;margin-top:20px"><button class="btn primary" data-m="plans">تمدید اشتراک</button><button class="btn ghost" data-m="close">بعداً</button></div>`);return}
  showModal(`<div class="modal-icon">✦</div><h2><b class='brand-word'>EvonoAI</b> به اشتراک نیاز دارد</h2><p class="muted">برای گفت‌وگو و تحلیل‌های <b class='brand-word'>EvonoAI</b> باید یکی از اشتراک‌ها را تهیه کنی. برنامهٔ هفته، تایمر، یادآورها و گزارش‌ها همین حالا و بدون اشتراک هم در دسترس‌اند.</p>
  <div class="row" style="justify-content:center;margin-top:20px"><button class="btn primary" data-m="plans">دیدن اشتراک‌ها</button><button class="btn ghost" data-m="close">بعداً</button></div>`)}
// Prices shown here are for display only — the amount actually charged always comes from the backend's
// own PLAN_PRICES_TOMAN (backend/src/routes/pay.js), never from this client. Keep these numbers in sync
// with it by hand (see backend/README.md).
const LOGO_WHITE="assets/logo-white.png";
const LOGO_BLACK="assets/logo-black.png";
const LOGO_BLUE="assets/logo-blue.png";
function logoSrc(){const t=(S.profile&&S.profile.theme)||"silver";return t==="blue"?LOGO_BLUE:t==="light"?LOGO_BLACK:LOGO_WHITE}
const PLANS=[
  {id:"weekly",name:"هفتگی",price:"۱۲۰٬۰۰۰",amount:120000,oldPrice:"۱۵۰٬۰۰۰",oldAmount:150000,badge:"٪۲۰ تخفیف",unit:"تومان در هفته",desc:"برای امتحان‌کردن Evono، بدون تعهد",feat:["۲۵ پیام با EvonoAI در هفته","برنامهٔ هفتگی تطبیقی","تایمر جلسه و یادآور","گزارش روزانه و مرور هفتگی"]},
  {id:"monthly",name:"ماهانه",price:"۴۵۰٬۰۰۰",amount:450000,oldPrice:"۶۰۰٬۰۰۰",oldAmount:600000,badge:"٪۲۵ تخفیف",unit:"تومان در ماه",desc:"برای شروع، بدون تعهد طولانی",feat:["۱۰۰ پیام با EvonoAI در هر ماه","برنامهٔ هفتگی تطبیقی","تایمر جلسه و یادآور","گزارش روزانه و مرور هفتگی"]},
  {id:"quarter",name:"سه‌ماهه",price:"۱٬۳۲۵٬۰۰۰",amount:1325000,oldPrice:"۱٬۸۰۰٬۰۰۰",oldAmount:1800000,unit:"تومان در سه ماه",badge:"بهترین ارزش · ٪۲۶ تخفیف",featured:true,desc:"یک فصل کامل برای جمع‌بندی و آمادگی امتحان‌ها",feat:["۳۰۰ پیام با EvonoAI در سه ماه","همهٔ امکانات ماهانه","برنامه‌ریزی فصل امتحان نهایی","تحلیل روند آزمون‌های آزمایشی"]}];
/* The numbers baked into PLANS above are just a fallback for the very first paint (and for if this
   fetch fails) — the real, current price (which an admin can override per-plan from the admin panel,
   see backend/src/routes/admin.js's /plan-prices) is fetched here so the card shown on this page always
   matches what checkout will actually charge (backend/src/routes/pay.js's /quote uses the exact same
   resolver). Same failure-safe pattern as TOPUP/ensureTopupRate below: one fetch, and a failure sets
   `failed` instead of retrying forever, so a flaky network can't freeze this tab again. */
let PLAN_PRICES={data:null,loading:false,failed:false};
function ensurePlanPrices(force){
  if(PLAN_PRICES.data||PLAN_PRICES.loading)return;
  if(PLAN_PRICES.failed&&!force)return;
  PLAN_PRICES.loading=true;PLAN_PRICES.failed=false;
  api("/api/pay/plan-prices").then(r=>{PLAN_PRICES.loading=false;if(r&&r.ok&&r.prices)PLAN_PRICES.data=r.prices;else PLAN_PRICES.failed=true;render()})
    .catch(()=>{PLAN_PRICES.loading=false;PLAN_PRICES.failed=true;render()});
}
function planAmount(p){const live=PLAN_PRICES.data&&PLAN_PRICES.data[p.id];return live>0?live:p.amount}
/* ---- checkout + payment gateway (Zarinpal) ----
   Real flow: bill → POST /api/pay/request → redirect the browser to the Zarinpal URL the backend
   returns → Zarinpal redirects back to backend/src/routes/pay.js's own /api/pay/callback, which
   verifies the payment with Zarinpal itself and only then activates the subscription server-side →
   that route redirects the browser back here with ?payment=success|failed&order=..., which
   handlePaymentReturn() (see boot()) reads and syncSubscription() then pulls the real result from
   GET /api/me. Nothing here ever marks a purchase "successful" on its own. */
/* ---- checkout ----
   The card shows real numbers from the backend, never a client-side guess: base plan price, the
   Zarinpal gateway commission (passed on to the student as its own line, never eaten by Evono — see
   backend/src/lib/pricing.js), and any discount code's effect, all priced by /api/pay/quote so the
   total shown here always matches what /api/pay/request will actually charge. */
const DISCOUNT_ERR_FA={invalid_code:"این کد تخفیف معتبر نیست.",expired:"این کد تخفیف منقضی شده است.",max_uses_reached:"ظرفیت استفادهٔ این کد تخفیف تمام شده است.",unknown_plan:"خطا در بررسی قیمت؛ دوباره امتحان کن.",network_error:"ارتباط با سرور برقرار نشد."};
let CO=null; // {id, codeInput, appliedCode, quote, busy, err}
function showCheckout(id){
  const p=PLANS.find(x=>x.id===id);if(!p)return;
  CO={id,codeInput:"",appliedCode:null,quote:null,busy:true,err:""};
  renderCheckoutModal();loadCheckoutQuote();
}
async function loadCheckoutQuote(){
  const st=CO;if(!st)return;
  st.busy=true;renderCheckoutModal();
  try{
    const q=await api("/api/pay/quote",{method:"POST",body:{plan:st.id,code:st.appliedCode||undefined}});
    if(CO!==st)return; // checkout closed/reopened while this was in flight
    if(q&&q.ok){st.quote=q}else{st.quote=null;st.err=DISCOUNT_ERR_FA[q&&q.error]||"خطا در محاسبهٔ مبلغ."}
  }catch(e){if(CO===st){st.quote=null;st.err=DISCOUNT_ERR_FA.network_error}}
  if(CO===st){st.busy=false;renderCheckoutModal()}
}
async function applyDiscountCode(){
  const st=CO;if(!st)return;
  const raw=(st.codeInput||"").trim();if(!raw)return;
  st.busy=true;st.err="";renderCheckoutModal();
  try{
    const q=await api("/api/pay/quote",{method:"POST",body:{plan:st.id,code:raw}});
    if(CO!==st)return;
    if(q&&q.ok){st.appliedCode=raw.toUpperCase();st.quote=q;st.err=""}
    else{st.err=DISCOUNT_ERR_FA[q&&q.error]||"این کد تخفیف معتبر نیست."}
  }catch(e){if(CO===st)st.err=DISCOUNT_ERR_FA.network_error}
  if(CO===st){st.busy=false;renderCheckoutModal()}
}
function renderCheckoutModal(){
  const st=CO;if(!st)return;
  const p=PLANS.find(x=>x.id===st.id);if(!p)return;
  const queuing=subActive();
  const renewingSame=queuing&&subPlan()===st.id;
  const queueStartAt=queuing?queueSlotStart(subQueue().length):null;
  const q=st.quote;
  const rows=q?`
    <div class="gw-row" style="margin-top:16px"><span class="small muted">اشتراک ${esc(p.name)} Evono</span><span class="num">${fa(q.amountToman)} تومان</span></div>
    ${q.discountToman>0?`<div class="gw-row"><span class="small muted">تخفیف${st.appliedCode?` (${esc(st.appliedCode)})`:""}</span><span class="num" style="color:var(--good)">−${fa(q.discountToman)} تومان</span></div>`:""}
    <div class="gw-row"><span class="small muted">کارمزد درگاه پرداخت</span><span class="num">${fa(q.feeToman)} تومان</span></div>
    <div class="gw-row" style="border-bottom:0;padding-top:14px"><b>مبلغ قابل پرداخت</b><b class="num" style="font-size:1.25rem">${fa(q.totalToman)} تومان</b></div>`
    :`<div class="gw-row" style="margin-top:16px"><span class="small muted">اشتراک ${esc(p.name)} Evono</span><span class="num">${fa(p.amount)} تومان</span></div>
    <div class="gw-row" style="border-bottom:0;padding-top:14px"><b>مبلغ قابل پرداخت</b><b class="num" style="font-size:1.25rem">${st.busy?"…":fa(p.amount)+" تومان"}</b></div>`;
  showModal(`<div class="checkout">
    <h2 style="text-align:center">صورت‌حساب اشتراک ${esc(p.name)}</h2>
    <p class="small muted" style="text-align:center;margin-top:2px">پیش از رفتن به درگاه پرداخت، جزئیات خرید را بررسی کن</p>
    ${queuing?`<div class="note" style="margin-top:14px">اشتراک ${esc((PLANS.find(x=>x.id===subPlan())||{}).name||"")} تو هنوز فعال است${subQueue().length?` و اشتراک‌ دیگری هم در صف داری`:""}. با این خرید، اشتراک ${esc(p.name)} ${renewingSame?"تمدید می‌شود و بدون وقفه":""} از <b>${faDateMs(queueStartAt)}</b> (بعد از اشتراک فعلی و هر اشتراکی که پیش از این در صف داشتی) شروع می‌شود؛ الان چیزی در برنامهٔ فعلی‌ات تغییر نمی‌کند.</div>`:""}
    ${rows}
    <div class="row" style="margin-top:14px;gap:8px;align-items:center">
      ${st.appliedCode?`<div class="cd" style="flex:1;justify-content:space-between"><span>کد <b dir="ltr">${esc(st.appliedCode)}</b> اعمال شد</span><button type="button" class="x-close" data-co="rmcode" aria-label="حذف کد">×</button></div>`
        :`<input type="text" id="co-code" placeholder="کد تخفیف (اختیاری)" value="${esc(st.codeInput)}" style="flex:1" dir="ltr" ${st.busy?"disabled":""}><button class="btn sm" data-co="applycode" ${st.busy?"disabled":""}>اعمال</button>`}
    </div>
    ${st.err?`<p class="small" style="color:var(--crit);margin-top:8px">${esc(st.err)}</p>`:""}
    <div class="row" style="justify-content:center;margin-top:20px"><button class="btn primary" data-co="pay" ${st.busy||!st.quote?"disabled":""}>ادامه و پرداخت</button><button class="btn ghost" data-m="close">انصراف</button></div>
    <p class="small muted" style="margin-top:12px;text-align:center">با ادامه، به درگاه پرداخت زرین‌پال منتقل می‌شوی.</p>
  </div>`,true);
  document.querySelectorAll("[data-co]").forEach(b=>b.onclick=()=>{
    if(b.dataset.co==="pay")buyPlan(st.id,st.appliedCode);
    else if(b.dataset.co==="applycode")applyDiscountCode();
    else if(b.dataset.co==="rmcode"){st.appliedCode=null;st.err="";loadCheckoutQuote()}
  });
  const ci=document.getElementById("co-code");
  if(ci){ci.oninput=()=>{st.codeInput=ci.value};ci.onkeydown=e=>{if(e.key==="Enter"){e.preventDefault();applyDiscountCode()}}}
}
async function buyPlan(id,code){
  const p=PLANS.find(x=>x.id===id);if(!p)return;
  showModal(`<div class="gw-redirect"><div class="gw-spin" aria-hidden="true"></div><h2>در حال اتصال به درگاه پرداخت</h2><p class="muted">اتصال امن به بانک برقرار می‌شود…</p></div>`);
  try{
    const data=await api("/api/pay/request",{method:"POST",body:{plan:id,code:code||undefined}});
    if(!data||!data.redirectUrl)throw new Error("no_redirect");
    location.href=data.redirectUrl;
  }catch(e){
    closeModal();
    showModal(`<div class="modal-icon fail">✕</div><h2>اتصال به درگاه پرداخت ناموفق بود</h2><p class="muted">خطا در ارتباط با سرور پرداخت. مبلغی از حساب تو کسر نشده است؛ کمی بعد دوباره امتحان کن.</p>
      <div class="row" style="justify-content:center;margin-top:20px"><button class="btn primary" data-m="retrybuy" data-id="${id}">تلاش دوباره</button><button class="btn ghost" data-m="close">بعداً</button></div>`);
  }
}
/** After a Zarinpal redirect back (see handlePaymentReturn), the backend already decided whether the
 *  payment succeeded — this just pulls that real result into local state instead of guessing at it. */
async function syncSubscription(){
  try{
    const me=await api("/api/me");
    const sub=me&&me.subscription;
    if(sub&&sub.status==="active"){
      const until=new Date(sub.ends_at).getTime();
      if(until>Date.now()){
        S.sub={plan:sub.plan,start:new Date(sub.starts_at).getTime(),until,queue:(S.sub&&S.sub.queue)||[]};
        S.aiUse=null;S.seenExpiryFor=null;save();
      }
    }
    // extra_ai_messages is the backend's own running total of purchased message top-ups (see
    // backend's addExtraAiMessages, credited after a real payment) — always resynced here so a
    // topup purchase shows up the moment the student is back from Zarinpal, same as a plan purchase.
    const extra=Number(me&&me.extra_ai_messages)||0;
    if(extra!==(S.aiExtra||0)){S.aiExtra=extra;save()}
  }catch(e){}
}
function confettiHTML(n){
  const colors=["#8FD6AE","#E6C27A","#8FB6F2","#F2958B","#DADEE3"];let out="";
  for(let i=0;i<n;i++){
    const left=(Math.random()*100).toFixed(1),dx=(Math.random()*160-80).toFixed(0),dur=(1.5+Math.random()*1.2).toFixed(2),
      delay=(Math.random()*.5).toFixed(2),rot=(360+Math.random()*540).toFixed(0),w=(6+Math.random()*4).toFixed(1),bg=colors[i%colors.length];
    out+=`<i class="confetti${Math.random()<.4?" round":""}" style="left:${left}%;width:${w}px;height:${(w*1.6).toFixed(1)}px;background:${bg};--dx:${dx}px;--dur:${dur}s;--delay:${delay}s;--rot:${rot}deg"></i>`;
  }
  return out;
}
function sparkleHTML(n){
  let out="";
  for(let i=0;i<n;i++){
    const top=(Math.random()*70).toFixed(0),left=(Math.random()*100).toFixed(0),size=(10+Math.random()*10).toFixed(0),delay=(Math.random()*1.8).toFixed(2);
    out+=`<span class="sub-sparkle" style="--top:${top}px;--left:${left}%;--size:${size}px;--delay:${delay}s">✦</span>`;
  }
  return out;
}
function renderPlans(){
  ensurePlanPrices();
  const q=subQueue();
  const nextPlan=q.length?PLANS.find(x=>x.id===q[0]):null;
  return `<div class="stack">
  <section class="card" style="text-align:center;padding:34px 22px"><span class="label">اشتراک Evono</span><h1 style="font-size:1.9rem;margin-top:6px">مشاور تحصیلی همیشه همراه، تا روز کنکور</h1>
    <p class="muted" style="max-width:560px;margin:10px auto 0">${subActive()?`اشتراک ${esc((PLANS.find(x=>x.id===subPlan())||{}).name||"")} تو فعال است.`+(aiQuota()?` ${fa(aiLeft())} از ${fa(aiQuota())} پیام <b class='brand-word'>EvonoAI</b> ${periodLabel()} باقی مانده.`:""):subLapsed()?"اشتراک قبلی‌ات تمام شده است. برای ادامهٔ <b class='brand-word'>EvonoAI</b> یکی از اشتراک‌ها را تمدید کن.":"برنامهٔ هفته، تایمر و گزارش‌ها همین حالا رایگانند؛ برای گفت‌وگو با <b class='brand-word'>EvonoAI</b> یکی از اشتراک‌ها را انتخاب کن."}${nextPlan?` اشتراک بعدی‌ات <b>${esc(nextPlan.name)}</b> است که از <b>${faDateMs(queueSlotStart(0))}</b> شروع می‌شود.${q.length>1?` (و ${fa(q.length-1)} اشتراک دیگر هم پشت‌سرهم بعد از آن در صف است.)`:""}`:""}</p>
    </section>
  <div class="plans">${PLANS.map(p=>{const mine=subActive()&&subPlan()===p.id;const queuedIdx=q.indexOf(p.id);const queued=queuedIdx!==-1;return `<section class="card plan ${p.featured?"featured":""}${mine?" mine":""}">
    ${mine?`<span class="active-sub"><span class="dot" aria-hidden="true"></span><b>اشتراک شما</b></span>`:queued?`<span class="badge ghost">${queuedIdx===0?"برنامهٔ بعدی":"در صف"}</span>`:p.badge?`<span class="badge ${p.featured?"":"ghost sale"}">${esc(p.badge)}</span>`:`<span class="badge ghost">شروع سریع</span>`}
    <div><h2>${esc(p.name)}</h2><p class="small muted">${esc(p.desc)}</p></div>
    <div>${p.oldPrice?`<div class="price-old num">${p.oldPrice} <span>تومان</span></div>`:""}<div class="price num">${fa(planAmount(p))}</div><div class="unit">${esc(p.unit)}</div></div>
    <ul>${p.feat.map(f=>`<li>${esc(f)}</li>`).join("")}</ul>
    ${mine?(subNearExpiry()?`<button class="btn primary" data-buy="${p.id}">تمدید اشتراک</button>`:`<button class="btn" data-tab="profile">مدیریت اشتراک</button>`):queued?`<p class="small muted" style="text-align:center;margin-top:auto;padding-top:9px">از ${faDateMs(queueSlotStart(queuedIdx))} شروع می‌شود</p>`:`<button class="btn ${p.featured?"primary":""}" data-buy="${p.id}">خرید ${esc(p.name)}</button>`}</section>`}).join("")}</div>
  <p class="small muted" style="text-align:center">تخفیف‌های فعلی محدود به مدت‌زمان مشخصی هستند.</p>
  ${renderTopupCard()}
  <section class="card sub-foot">
    <p class="sub-foot-text">پرداخت از طریق درگاه بانکی معتبر انجام می‌شود و اطلاعات کارت تو هرگز نزد Evono ذخیره نمی‌شود.</p>
    <div class="trust-badges">
      <a class="trust-badge" href="https://www.zarinpal.com" target="_blank" rel="noopener noreferrer" aria-label="درگاه پرداخت زرین‌پال" title="درگاه پرداخت زرین‌پال">
        <img class="tb-logo" src="assets/zarinpal-logo.png" alt="زرین‌پال" loading="lazy">
      </a>
      <a class="trust-badge" href="https://trustseal.enamad.ir" target="_blank" rel="noopener noreferrer" aria-label="نماد اعتماد الکترونیکی" title="نماد اعتماد الکترونیکی">
        <svg viewBox="0 0 24 24" width="42" height="42" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m8.5 12.3 2.3 2.3 4.7-4.9"/></svg>
      </a>
    </div>
  </section></div>`;
}

/* ---- پیام اضافه (extra EvonoAI messages) ----
   Only usable by a student who has an ACTIVE subscription and has already used up that period's
   whole message quota — never someone with no subscription, and never someone who still has
   messages left (they'd just be re-buying what they already have). Unit price is Claude Haiku 4.5's
   own real API cost (see backend/src/lib/pricing.js) converted from USD at a rate the backend
   refreshes from the market every few hours (backend/src/lib/fx.js), plus Evono's own margin —
   never a made-up number. */
let TOPUP={n:20,rate:null,loading:false,busy:false,err:"",failed:false};
function topupEligible(){return subActive()&&aiLeft()<=0}
function ensureTopupRate(force){
  if(TOPUP.rate||TOPUP.loading)return;
  if(TOPUP.failed&&!force)return;
  TOPUP.loading=true;TOPUP.failed=false;
  api("/api/pay/topup-rate").then(r=>{TOPUP.loading=false;if(r&&r.ok)TOPUP.rate=r;else TOPUP.failed=true;render()})
    .catch(()=>{TOPUP.loading=false;TOPUP.failed=true;render()});
}
function renderTopupCard(){
  ensureTopupRate();
  const eligible=topupEligible();
  const unit=TOPUP.rate&&TOPUP.rate.unitPriceToman;
  return `<section class="card topup ${eligible?"":"locked"}">
    <div class="card-h"><div><span class="label">پیام اضافه</span><h2 style="margin-top:4px">پیام <b class='brand-word'>EvonoAI</b> بیشتر بخر</h2>
      <p class="small muted" style="margin-top:4px">${eligible
        ?"پیام‌های این دوره‌ات تمام شده؛ تا شارژ دوباره، هر تعداد که بخواهی جداگانه بخر."
        :subActive()
          ?`این کارت فقط وقتی باز می‌شود که پیام‌های اشتراکت تمام شده باشد — الان ${fa(aiLeft())} پیام <b class='brand-word'>EvonoAI</b> دیگر داری.`
          :"این کارت فقط برای کسانی است که اشتراک فعال دارند و پیام‌هایشان تمام شده. ابتدا یکی از اشتراک‌های بالا را بخر."}</p></div></div>
    <div class="topup-row">
      <div class="topup-slider">
        <input type="range" min="1" max="500" step="1" id="topup-range" value="${TOPUP.n}" ${eligible?"":"disabled"} aria-label="تعداد پیام اضافه">
        <div class="topup-scale"><span>۱ پیام</span><span><b class="num" id="topup-count">${fa(TOPUP.n)}</b> پیام</span><span>۵۰۰ پیام</span></div>
      </div>
      <div class="topup-buy">
        <span class="price num" id="topup-price">${unit?fa(TOPUP.n*unit)+" تومان":TOPUP.failed?"—":"…"}</span>
        <span class="price-per">${unit?`${fa(unit)} تومان هر پیام + کارمزد درگاه`:TOPUP.failed?"دریافت قیمت ناموفق بود":"در حال دریافت قیمت…"}</span>
        ${TOPUP.failed&&!unit?`<button class="btn ghost" type="button" data-topup-retry style="margin-top:6px">تلاش دوباره</button>`
          :`<button class="btn primary" id="topup-buy-btn" data-topup-buy ${eligible&&unit&&!TOPUP.busy?"":"disabled"}>خرید ${fa(TOPUP.n)} پیام</button>`}
      </div>
    </div>
    ${TOPUP.err?`<p class="small" style="color:var(--crit);margin-top:10px">${esc(TOPUP.err)}</p>`:""}
  </section>`;
}
async function buyTopup(){
  if(!topupEligible()||TOPUP.busy)return;
  const n=TOPUP.n;
  TOPUP.busy=true;TOPUP.err="";
  showModal(`<div class="gw-redirect"><div class="gw-spin" aria-hidden="true"></div><h2>در حال اتصال به درگاه پرداخت</h2><p class="muted">اتصال امن به بانک برقرار می‌شود…</p></div>`);
  try{
    const data=await api("/api/pay/topup-request",{method:"POST",body:{n}});
    if(!data||!data.redirectUrl)throw new Error("no_redirect");
    location.href=data.redirectUrl;
  }catch(e){
    TOPUP.busy=false;closeModal();
    showModal(`<div class="modal-icon fail">✕</div><h2>اتصال به درگاه پرداخت ناموفق بود</h2><p class="muted">خطا در ارتباط با سرور پرداخت. مبلغی از حساب تو کسر نشده است؛ کمی بعد دوباره امتحان کن.</p>
      <div class="row" style="justify-content:center;margin-top:20px"><button class="btn primary" data-m="close">باشه</button></div>`);
  }
}

/* ================= Week page ================= */
function renderWeek(){
  ensureWeek();const ds=calWeek(WEEK_OFF);const t0=todayIso();const dsC=[...ds].sort();const friThis=isoFromD(todayD()-wdIdx(todayD())+6);
  ds.forEach(d=>{if(d>=t0)planFor(d)});
  const plans=ds.map(d=>S.plans[d]||null);
  const all=plans.filter(Boolean).flatMap(p=>p.tasks);const total=all.reduce((a,t)=>a+t.minutes,0);const fin=all.filter(t=>t.bucket==="final").reduce((a,t)=>a+t.minutes,0);
  const bySub={};all.forEach(t=>{if(t.subjectId)bySub[t.subjectId]=(bySub[t.subjectId]||0)+t.minutes});
  const P=S.prefs||{};const ph=phase();const full=P.weekView==="full";
  const title=WEEK_OFF===0?"برنامهٔ هفتگی | ۷ روز پیش رو":WEEK_OFF===1?"برنامهٔ ۷ روز بعد از آن":"۷ روز گذشته";
  return `<div class="stack no-select">
  <section class="card"><div class="card-h"><div><h2>${title}</h2><p class="small muted">${jLabel(dsC[0])} تا ${jLabel(dsC[6])} | مرتب از شنبه تا جمعه | فاز: ${esc(ph.label)}</p></div>
    <div class="row"><button class="btn sm" data-act="regenweek">بازسازی هفته</button><button class="btn sm primary" data-goto="ai">تغییر با <b class='brand-word'>EvonoAI</b></button></div></div>
    <div class="stats"><div class="stat"><span class="label">کل مطالعه</span><b class="num">${fa(Math.round(total/6)/10)} ساعت</b></div>
      <div class="stat"><span class="label">جلسه‌ها</span><b class="num">${fa(all.length)}</b></div>
      <div class="stat"><span class="label">${S.profile.grade==="10"?"مدرسه":"نهایی"} / کنکور</span><b class="num">${total?fa(Math.round(fin/total*100)):"۰"}٪ / ${total?fa(100-Math.round(fin/total*100)):"۰"}٪</b></div>
      <div class="stat"><span class="label">سبک برنامه</span><span class="small" style="margin-top:6px">جلسهٔ ${durLabel(S.profile.sessionLen)} | خواب ${faStr(S.sleep.bed)} | ${({hard_first:"اول سخت",easy_first:"اول آسان",mixed:"سخت و آسان یکی‌درمیان"})[P.order||"hard_first"]} | تا ${fa(P.maxSubjects||4)} درس در روز</span></div></div>
    <div class="subchips" style="margin-top:14px">${Object.entries(bySub).sort((a,b)=>b[1]-a[1]).map(([id,m])=>`<span>${esc(subName(id))}<b class="num">${durLabel(m)}</b></span>`).join("")}</div>
  </section>
  ${WEEK_OFF===0?seasonBanner(t0):""}${(()=>{const k=ds.findIndex(d=>d>t0&&seasonOf(d)!=="school"&&seasonOf(d)!=="free"&&seasonOf(isoFromD(dFromIso(d)-1))==="school");return k>=0?`<section class="season"><span class="sico">${SEASON[seasonOf(ds[k])].i}</span><div><b>${SEASON[seasonOf(ds[k])].t} از ${WD[wdIdx(dFromIso(ds[k]))]}</b><p class="small muted">از آن روز برنامه‌ها با بازهٔ روزهای بدون مدرسه (${faStr(S.holiday.start)} تا ${faStr(S.holiday.end)}) چیده می‌شوند.</p></div></section>`:""})()}
  ${reviewCard(false)}
  ${studyTips()}
  <div class="wk-bar">
    <div class="seg wk-tabs">${[[-1,"۷ روز گذشته"],[0,"۷ روز پیش رو"],[1,"۷ روز بعد"]].map(([o,l])=>`<label><input type="radio" name="wkoff" ${WEEK_OFF===o?"checked":""} data-wkoff="${o}"><span>${l}</span></label>`).join("")}</div>
    <button class="btn ${full?"primary":""}" data-wkview="1">${full?"◧ نمای کارتی":"▦ دیدن کل هفته در یک صفحه"}</button>
  </div>
  ${full?`<p class="small muted">کل هفته در یک نگاه | جلسه‌های کنکور با کادر خط‌چین مشخص شده‌اند.</p>`:`<div class="wk-nav"><span class="small muted drag-hint">برای جابه‌جایی جلسه‌های نخوندهٔ هر روز، کارت را نگه‌دار و به جای دلخواه بکش.</span><div class="row"><button class="btn" data-wk="1" aria-label="روزهای قبل">→</button><button class="btn" data-wk="-1" aria-label="روزهای بعد">←</button></div></div>`}
  <div class="week ${full?"full":""}" id="weekgrid">${ds.map((d,i)=>{const p=plans[i];const dn=dFromIso(d);const j=d2j(dn);const past=d<t0,isToday=d===t0;
    const tasks=p?p.tasks:[];const mins=tasks.reduce((a,t)=>a+t.minutes,0);
    return `<div class="day ${isToday?"today":""} ${past?"past":""} ${tasks.length?"":"off"}" style="animation-delay:${i*50}ms">
      <div class="day-h"><div class="dtop"><b>${WD[wdIdx(dn)]}</b>${seasonOf(d)!=="school"&&seasonOf(d)!=="free"&&!(isToday&&seasonOf(isoFromD(dn+1))==="school")?`<span class="badge ghost">${SEASON[seasonOf(d)].t}</span>`:""}${isToday?'<span class="badge">امروز</span>':d===isoFromD(todayD()+1)?'<span class="badge ghost">فردا</span>':past?'<span class="badge ghost">گذشته</span>':(WEEK_OFF===0&&d>friThis)?'<span class="badge ghost">هفتهٔ بعد</span>':""}</div>
        <div class="dsub"><span>${fa(j.jd)} ${JM[j.jm-1]}</span><span class="num">${mins?fa(Math.round(mins/6)/10)+" ساعت":"—"}</span></div></div>
      ${full?"":`<div class="sleepmark">☀ <b class="num">${faStr(sleepFor(d).wake)}</b></div>`}
      ${p&&p.change?`<span class="badge" style="align-self:flex-start">تغییر به درخواست تو</span>`:""}
      ${tasks.length?(()=>{const todoIdxs=tasks.map((x,ix)=>x.status==="todo"?ix:-1).filter(ix=>ix!==-1);return tasks.map((t,ti)=>{const pos=todoIdxs.indexOf(ti);return `<div class="wtask ${t.status} ${t.fromChange?"new":""} bk-${t.bucket}"${pos!==-1?` data-drag-id="${t.id}" data-drag-date="${d}"`:""}>
        <div class="wt-top"><span class="num wt-clock">${hm(t.start)}</span><span>${durLabel(t.minutes)}</span></div>
        <b>${esc(taskSubName(t))}</b>${t.lesson?`<span class="wt-lesson">${esc(t.lesson)}</span>`:""}<span class="wt-type">${esc(t.type)}</span>
        <div class="wt-foot">${pillFor(t.bucket)}${t.status==="doing"?'<span class="pill p-good">در حال انجام</span>':""}${t.status==="done"?'<span class="pill p-good">انجام شد</span>':""}${t.status==="missed"?'<span class="pill p-crit">انجام نشد</span>':""}</div>
        ${isToday&&(t.status==="todo")?`<button class="btn sm primary" data-start="${t.id}">شروع ▸</button>`:""}
      </div>`}).join("")})():`<div class="day-empty">${past?"برنامه‌ای ثبت نشده":isToday&&availabilityFor(d).minutes>0?"زمان درس امروز تمام شده؛ فردا ادامه می‌دهیم":!S.availability[wdIdx(dn)].on&&seasonOf(d)==="school"?`روز استراحت<br><button class="btn sm" data-act="opensettings" style="margin-top:8px">روشن کردن ${WD[wdIdx(dn)]}</button>`:"روز استراحت"}</div>`}
      ${p&&p.change&&p.change.cancelled.length&&!full?`<details class="cancelled"><summary>لغو شده (${fa(p.change.cancelled.length)})</summary>${p.change.cancelled.map(t=>`<div class="old"><span>${esc(taskSubName(t))}</span><span class="num">${hm(t.start)}</span></div>`).join("")}<button class="btn sm" style="margin-top:8px" data-restore="${d}">بازگرداندن</button></details>`:""}
      ${full?"":`<div class="sleepmark">☾ <b class="num">${faStr(sleepFor(d).bed)}</b></div>`}
    </div>`}).join("")}</div>
  </div>`;
}

document.addEventListener("focusin",e=>{
  const t=e.target;
  if(t&&(t.tagName==="INPUT"||t.tagName==="TEXTAREA")){
    t.setAttribute("autocomplete","off");
    t.setAttribute("autocorrect","off");
    t.setAttribute("autocapitalize","off");
    t.setAttribute("spellcheck","false");
  }
});

// Make the brand logo a little harder to casually drag or right-click-save — this raises friction,
// it can't make an image the browser has to render literally undownloadable (dev tools/view-source
// always can), but it stops the two easiest, most common ways people lift a logo image. Delegated on
// document since the header re-renders on every render() call, so a listener on the element itself
// would need re-attaching constantly.
document.addEventListener("dragstart",e=>{if(e.target&&e.target.closest&&e.target.closest(".brand-mark"))e.preventDefault()});
document.addEventListener("contextmenu",e=>{if(e.target&&e.target.closest&&e.target.closest(".brand-mark"))e.preventDefault()});

boot();
