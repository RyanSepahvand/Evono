#!/usr/bin/env node
/**
 * Zero-dependency local static server for testing one of the Evono sites without the browser
 * tab/URL bar ever showing "index.html" — it serves index.html as the default document at "/"
 * (so the address bar just reads http://localhost:PORT/) and 301-redirects a direct hit on
 * "/index.html" back to "/", the same way a real static host (Vercel/Netlify/nginx) behaves
 * once deployed.
 *
 * The landing page's own index.html/app.js/styles.css/assets/ live right here next to this file
 * (this project's own root) — that's what "no folder" (no argument) serves, matching www.evono.ir's
 * document root. The student app lives in student-app/ and the admin dashboard in admin-dashboard/,
 * both real subfolders one level down.
 *
 * Also understands /login as a real URL (not just a 404): the student app is a single-page app
 * where the login/OTP screen is just something it renders client-side whenever there's no active
 * session, so serving index.html there mirrors the production rewrite in student-app/vercel.json
 * and student-app/_redirects.
 *
 * Usage:
 *   node serve.js                     # serves the landing page (this folder) on port 5500
 *   node serve.js 5510                # same, on a different port
 *   node serve.js student-app         # serves ./student-app on port 5500 — try /login too
 *   node serve.js student-app 5502
 *   node serve.js admin-dashboard 5501
 */
const http = require("http");
const fs = require("fs");
const path = require("path");

const args = process.argv.slice(2);
let folder = ".";
let port = 5500;
if (args.length === 1 && /^\d+$/.test(args[0])) {
  port = Number(args[0]); // a single numeric argument is a port, not a folder name
} else {
  if (args[0]) folder = args[0];
  if (args[1]) port = Number(args[1]) || 5500;
}

const root = path.resolve(__dirname, folder);
if (!fs.existsSync(path.join(root, "index.html"))) {
  console.error(`No index.html found in ${root}`);
  process.exit(1);
}

const MIME = {
  ".html": "text/html; charset=utf-8",
  ".js": "text/javascript; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".json": "application/json; charset=utf-8",
  ".png": "image/png",
  ".jpg": "image/jpeg",
  ".jpeg": "image/jpeg",
  ".svg": "image/svg+xml",
  ".webp": "image/webp",
  ".ico": "image/x-icon",
  ".woff": "font/woff",
  ".woff2": "font/woff2",
};

http
  .createServer((req, res) => {
    let reqPath = decodeURIComponent(req.url.split("?")[0]);

    // Same behavior a real static host gives you for free at its domain root:
    // a direct hit on /index.html always redirects to / so the address bar
    // never shows the filename, even if someone bookmarks or links it directly.
    if (reqPath === "/index.html") {
      res.writeHead(301, { Location: "/" });
      return res.end();
    }

    // Mirrors the production rewrite in student-app/vercel.json and student-app/_redirects — /login
    // isn't a real file, it's the student app (a single-page app) rendering its login/OTP screen
    // client-side whenever there's no active session. Harmless no-op for the other two sites, which
    // don't have a /login link anywhere.
    if (reqPath === "/login") reqPath = "/index.html";

    if (reqPath.endsWith("/")) reqPath += "index.html"; // /student-app/ -> /student-app/index.html
    const filePath = path.join(root, reqPath);

    // Never serve outside the site folder.
    if (!filePath.startsWith(root)) {
      res.writeHead(403);
      return res.end("Forbidden");
    }

    fs.readFile(filePath, (err, data) => {
      if (err) {
        res.writeHead(404, { "Content-Type": "text/plain; charset=utf-8" });
        return res.end("Not found: " + reqPath);
      }
      const ext = path.extname(filePath).toLowerCase();
      res.writeHead(200, { "Content-Type": MIME[ext] || "application/octet-stream" });
      res.end(data);
    });
  })
  .listen(port, () => {
    console.log(`Serving ${folder === "." ? "the student app (this project's root)" : folder + "/"} at http://localhost:${port}/  (Ctrl+C to stop)`);
  });
